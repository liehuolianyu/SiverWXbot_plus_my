# wxautox4 + SiverWXbot_plus 备份

备份日期：2026-10-15

## 一、上传前必读

**1. 建议使用私有仓库（private）**

本包含以下内容，公开仓库可能引发合规或版权争议：

- `re_wxautox4/bypass/` —— 解除 wxautox4 授权校验的补丁与安装器
- `re_wxautox4/wake_ref/` —— 微信 UIA 无障碍闸门工具（第三方开源项目改造）
- `re_wxautox4/*.md` —— 激活协议逆向分析报告

**2. 本包已剔除敏感与本地产物，因此不能直接运行**，需按「四、恢复步骤」补齐。

## 二、目录结构

```
wxautox4_github_backup/
├── README.md                     本文件
├── .gitignore                    顶层忽略规则（凭据 / 运行产物 / 大文件）
├── SiverWXbot_plus/             微信机器人（源码 + 面板 + 文档 + 模板）
│   ├── config/
│   │   ├── config.example.json  ← 脱敏配置模板（key/url/model 已清空）
│   │   ├── admin.example.json   ← 面板账密模板
│   │   └── prompt/              提示词目录
│   ├── tools/                   本次新增的自愈与工具脚本
│   │   ├── wxautox4_prep.py     ★ 启动前自愈：补 UIA 闸门 + 激活窗口 + 兼容补丁
│   │   ├── wechat_uia_wake.py   微信 4.x UIA 无障碍闸门工具
│   │   ├── wxautox4_compat_414.py  微信 4.1.15.x 资料卡兼容容错
│   │   └── set_api_config.py    API 配置命令行工具
│   ├── docs/  templates/  README.md  LICENSE  ...
│   └── .gitignore
└── re_wxautox4/                 逆向分析工作区
    ├── bypass/                  ★ 授权解除补丁 + 安装器 + 自检
    │   ├── install_license_bypass.py
    │   ├── wxautox4_unseal.py   授权门还原（闭包 original_init）
    │   ├── verify_bypass.py     3 项自检
    │   └── README.md
    ├── wake_ref/                UIA 闸门工具与适配层
    ├── deploy_kit/              离线部署包（不含 wheels）
    ├── artifacts/               逆向过程产物（trace JSON、密钥形状）
    ├── wxautox4_activation_analysis.md   ★ 激活协议完整分析（含修正章节）
    ├── SiverWXbot_API配置报错分析.md
    ├── 使用说明.md
    ├── wxautox4_ready.py        一键就绪 + 可用性验证
    ├── test_wxautox4_min.py     最小可用性测试
    └── *.py                     其余逆向 / 探测 / 复现脚本
```

## 三、未包含的内容（及原因）

| 未包含 | 原因 |
|---|---|
| `.venv`、`.venv_clean`、`env312` | 虚拟环境，可用 requirements.txt 重建（env312 约 79 MB） |
| `config/config.json` | **含真实 API key 与接口地址**，改用 `config.example.json` 模板 |
| `config/admin.json` | **含面板账密哈希**，改用 `admin.example.json` 模板 |
| `config/panel_secret.key` | Flask 会话密钥，属凭据 |
| `config/email.txt` | 邮箱与授权码 |
| `config/cacert.pem` | CA 证书包，可重新下载 |
| `config/.wxautox4_nickname` | 微信昵称缓存，属个人信息 |
| `memory/`、`panel_logs/`、`wxauto_logs/`、`old_wxbot_config/` | 运行产物与聊天记忆，含隐私 |
| `WXAUTOX_LICENSE`、`WXAUTOX_DEBUG_LICENSE` | **授权响应凭证**，避免公开仓库泄露激活数据 |
| `artifacts/cli_main.pyd` | wxautox4 的版权编译产物，不宜再分发 |
| `deploy_kit/wheels/`、`wxautox4_部署包.zip` | 第三方 wheel 包，pip 可重新下载 |
| `*.log`、`*.pyc`、`__pycache__` | 日志与字节码 |

> 凭证类文件仍保存在原始目录中，不会因为本包而丢失。

## 四、恢复步骤（换电脑时）

1. 安装 Python 3.12，创建虚拟环境：
   ```
   python -m venv .venv_clean
   .venv_clean\Scripts\pip install -r SiverWXbot_plus/requirements.txt
   .venv_clean\Scripts\pip install wxautox4
   ```
2. 对 wxautox4 安装授权解除补丁（详见 `re_wxautox4/bypass/README.md`）：
   ```
   python re_wxautox4/bypass/install_license_bypass.py ^
       --site-packages "<venv>\Lib\site-packages"
   ```
3. 恢复配置：把 `SiverWXbot_plus/config/config.example.json` 复制为
   `config/config.json`，填入自己的 API key / url / model；把
   `admin.example.json` 复制为 `admin.json` 并设置面板密码。
4. 微信 4.x 需要 UIA 无障碍闸门 + 窗口激活，机器人已内置自愈逻辑
   （`SiverWXbot_plus/tools/wxautox4_prep.py`，在
   `wxbot_core.init_wx_listeners()` 开头自动执行）。

## 五、上传步骤

```bash
cd wxautox4_github_backup
git init
git add .
git commit -m "backup: SiverWXbot_plus + wxautox4 reverse engineering"
git branch -M main
git remote add origin <你的仓库地址>
git push -u origin main
```

提交前建议再确认一次：

```bash
git status --short          # 确认没有 config.json / admin.json 被暂存
git ls-files | grep -Ei "config\.json|admin\.json|secret|\.pem|\.log$|\.pyc$"
```

上一条命令应当**没有任何输出**。

## 六、说明

- `SiverWXbot_plus` 本体来自开源项目，其 LICENSE 见该目录下 `LICENSE`。
- `re_wxautox4/` 中的分析材料为本机逆向所得，仅供个人备份与研究。
