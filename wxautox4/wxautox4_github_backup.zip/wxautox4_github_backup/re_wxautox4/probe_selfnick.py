# -*- coding: utf-8 -*-
"""验证消息接口 + 尝试从『自己发的消息』里取昵称"""
import importlib.util
import os
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

HERE = r"C:\Users\Administrator\WorkBuddy\2026-10-14-16-19-40\re_wxautox4"
spec = importlib.util.spec_from_file_location(
    "wx_uia_wake", os.path.join(HERE, "wake_ref", "wechat_uia_wake.py"))
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
from wxautox4.uia import uiautomation as auto  # noqa: E402
mod._uia = lambda: auto

spec2 = importlib.util.spec_from_file_location(
    "compat", os.path.join(HERE, "bypass", "wxautox4_compat_414.py"))
compat = importlib.util.module_from_spec(spec2)
spec2.loader.exec_module(compat)
compat.install()

print("wake:", mod.wake().get("ok"))

from wxautox4 import WeChat  # noqa: E402

wx = WeChat()
print("WeChat() ok, nickname =", repr(wx.nickname))

sessions = wx.GetSession()
print("\n会话列表 (%d):" % len(sessions))
for s in sessions:
    print("   ", getattr(s, "name", s))

# 挑「文件传输助手」看消息
target = None
for s in sessions:
    if "文件传输助手" in str(getattr(s, "name", "")):
        target = getattr(s, "name")
        break
print("\n目标会话:", target)

if target:
    chat = wx.ChatWith(target)
    print("ChatWith ->", chat)
    msgs = wx.GetAllMessage()
    print("消息数:", len(msgs))
    for m in msgs[-12:]:
        attr = getattr(m, "attr", None)
        sender = getattr(m, "sender", None)
        ctype = getattr(m, "type", None)
        content = str(getattr(m, "content", ""))[:40]
        print("    attr=%-8r type=%-8r sender=%-14r content=%r" % (attr, ctype, sender, content))
