# -*- coding: utf-8 -*-
"""尝试轻量唤醒微信 UIA 无障碍闸门（可逆）

步骤：
  1. 读/写系统「存在屏幕阅读器」标志 SPI_SETSCREENREADER
  2. 探测微信主窗口的 UIA 类名与子元素数，看 mmui:: 树是否物化
  3. 打印结论；失败则不保留副作用
"""
import ctypes
import ctypes.wintypes as wt
import sys
import time

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

SPI_GETSCREENREADER = 0x0046
SPI_SETSCREENREADER = 0x0047
SPIF_UPDATEINIFILE = 0x01
SPIF_SENDCHANGE = 0x02

u = ctypes.windll.user32


def get_flag():
    v = ctypes.c_int(0)
    u.SystemParametersInfoW(SPI_GETSCREENREADER, 0, ctypes.byref(v), 0)
    return v.value


def set_flag(val):
    return bool(u.SystemParametersInfoW(
        SPI_SETSCREENREADER, 1 if val else 0, None,
        SPIF_UPDATEINIFILE | SPIF_SENDCHANGE))


def probe():
    from comtypes.client import CreateObject, GetModule
    GetModule("UIAutomationCore.dll")
    from comtypes.gen import UIAutomationClient as UIA
    uia = CreateObject(UIA.CUIAutomation)
    root = uia.GetRootElement()
    walker = uia.CreateTreeWalker(uia.RawViewCondition)
    el = walker.GetFirstChildElement(root)
    main = None
    while el:
        try:
            if el.CurrentClassName == "Qt51514QWindowIcon" and el.CurrentName == "微信":
                main = el
                break
        except Exception:
            pass
        el = walker.GetNextSiblingElement(el)
    if main is None:
        return None, None
    # main 自身的 UIA 类名 + 后代里的 mmui 元素数
    n_all = 0
    n_mmui = 0
    stack = [main]
    while stack:
        e = stack.pop()
        c = walker.GetFirstChildElement(e)
        while c:
            n_all += 1
            try:
                if (c.CurrentClassName or "").startswith("mmui::"):
                    n_mmui += 1
            except Exception:
                pass
            if n_all < 400:
                stack.append(c)
            c = walker.GetNextSiblingElement(c)
    return n_all, n_mmui


print("=" * 60)
print("微信 UIA 闸门唤醒尝试")
print("=" * 60)

before = get_flag()
print("[0] SPI_GETSCREENREADER 当前 =", before)

n_all, n_mmui = probe()
print("[1] 唤醒前：UIA 后代 %s 个，其中 mmui:: 元素 %s 个" % (n_all, n_mmui))
if n_mmui and n_mmui > 0:
    print("    闸门已是激活状态")
    raise SystemExit(0)

print("[2] 设置 SPI_SETSCREENREADER = 1 ...")
ok = set_flag(True)
print("    调用返回:", ok, "| 现在读数:", get_flag())

time.sleep(1.5)
n_all, n_mmui = probe()
print("[3] 唤醒后：UIA 后代 %s 个，其中 mmui:: 元素 %s 个" % (n_all, n_mmui))

if n_mmui and n_mmui > 0:
    print("\n结论：闸门已激活，mmui 树已物化 ✔")
else:
    print("\n结论：仅置系统读屏标志不足以让微信重建控件树。")
    print("     该标志通常在微信「启动时」才被读取；需重启微信（或热写 Weixin.dll 闸门字节）。")

print("[4] 恢复系统读屏标志 ->", before)
set_flag(bool(before))
print("    当前 =", get_flag())
