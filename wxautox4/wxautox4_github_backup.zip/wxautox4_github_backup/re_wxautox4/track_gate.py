# -*- coding: utf-8 -*-
"""跟踪闸门字节的生命周期：读 -> 写 -> 读 -> 用 -> 再读"""
import ctypes
import importlib.util
import os
import sys
import time

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fix_uia_gate import probe_mmui  # noqa: E402

HERE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "wake_ref")
spec = importlib.util.spec_from_file_location(
    "wx_uia_wake", os.path.join(HERE, "wechat_uia_wake.py"))
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
from wxautox4.uia import uiautomation as auto  # noqa: E402

mod._uia = lambda: auto


def gate_state():
    wins = mod.wechat_window_handles()
    if not wins:
        return None
    w = wins[0]
    h = mod._open_process(w["pid"])
    if not h:
        return ("OpenProcess失败", w)
    try:
        addr = int(w["dll_base"]) + 0xB135C38
        v = mod._read_process_byte(h, addr)
        return (v, w)
    finally:
        ctypes.windll.kernel32.CloseHandle(h)


print("=" * 60)
r = gate_state()
print("[t0] 闸门字节 =", r[0] if r else "无窗口")
if r and r[0] is not None:
    w = r[1]
    print("     窗口 hwnd=0x%08X pid=%d" % (w["hwnd"], w["pid"]))

print("\n[1] 执行 wake() ...")
out = mod.wake()
print("    ->", {k: out[k] for k in ("ok", "rva", "action", "detail")})

r = gate_state()
print("\n[t1] 闸门字节 =", r[0] if r else "无窗口")

print("\n[2] 立刻构造 WeChat() ...")
from wxautox4 import WeChat
try:
    wx = WeChat()
    print("    成功 ->", wx)
except BaseException as e:
    print("    失败 ->", type(e).__name__, str(e).splitlines()[0])

for t in (5, 15, 30):
    time.sleep(5 if t == 5 else (10 if t == 15 else 15))
    r = gate_state()
    print("[t+%ds] 闸门字节 = %s" % (t, r[0] if r else "无窗口"))
