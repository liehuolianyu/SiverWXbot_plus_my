import wxautox4.ui.main as M
W=M.WeChatMainWnd; f=W.__init__; c=f.__code__
for nm,cell in zip(c.co_freevars, f.__closure__ or ()):
    if nm=="original_init": W.__init__=cell.cell_contents
from wxautox4.wx import WeChat
try:
    WeChat(nickname='x'); print('E2 OK')
except BaseException as e: print('E2:', type(e).__name__, '|', str(e)[:150])
