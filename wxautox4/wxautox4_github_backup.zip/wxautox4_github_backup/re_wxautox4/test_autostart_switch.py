# -*- coding: utf-8 -*-
"""验证 web_server._maybe_autostart_bot()：环境变量开关是否按预期工作。

零副作用：monkeypatch 掉 _spawn_bot_thread，不会真的连微信。
"""
import os
import sys
import time

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
PROJECT = r"C:\Users\Administrator\Documents\ChatGPT\live2D\_wxautox4_probe\SiverWXbot_plus"
sys.path.insert(0, PROJECT)

os.environ.pop('SIVER_AUTOSTART_BOT', None)

print("=" * 62)
print("[1] import web_server（不执行 main，不启动服务）")
import web_server
print("    _maybe_autostart_bot 存在 :", callable(getattr(web_server, '_maybe_autostart_bot', None)))
print("    _spawn_bot_thread 存在    :", callable(getattr(web_server, '_spawn_bot_thread', None)))

calls = []
web_server._spawn_bot_thread = lambda reason: (calls.append(reason), (True, 'mock-ok'))[1]

print("\n[2] 未设环境变量 -> 不应启动")
r = web_server._maybe_autostart_bot()
time.sleep(6.5)
print("    返回值 =", r, "| 调用次数 =", len(calls), "->", "PASS" if (r is False and not calls) else "FAIL")

print("\n[3] SIVER_AUTOSTART_BOT=1 -> 应先返回 True，5s 后启动一次")
os.environ['SIVER_AUTOSTART_BOT'] = '1'
r = web_server._maybe_autostart_bot()
print("    返回值 =", r, "| （等待 6.5s 让工作线程执行）")
time.sleep(6.5)
print("    调用次数 =", len(calls), "| reason =", calls)
ok = (r is True and len(calls) == 1 and calls[0] == '随服务自启动')
print("    ->", "PASS" if ok else "FAIL")

print("\n[4] 大小写/取值兼容")
for v in ('TRUE', 'yes', 'On', '0', 'false'):
    os.environ['SIVER_AUTOSTART_BOT'] = v
    calls.clear()
    r = web_server._maybe_autostart_bot()
    time.sleep(0.2)
    expect = v.lower() in ('1', 'true', 'yes', 'on')
    print("    %-6r -> 返回 %-5s (%s)" % (v, r, "符合预期" if r == expect else "不符!"))

os.environ.pop('SIVER_AUTOSTART_BOT', None)
print("\n" + "=" * 62)
print("结论：自启动开关工作正常 ✔" if ok else "结论：需检查 ✘")
print("=" * 62)
