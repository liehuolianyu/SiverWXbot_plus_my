# -*- coding: utf-8 -*-
import io, json, sys, os, pathlib
LOG=[]
def rec(k,d): LOG.append((k,d))
_o_div = pathlib.PurePath.__truediv__
def f_div(self, other):
    r=_o_div(self, other)
    if any(t in str(r) for t in ("hczvYP","ZlarPG")):
        rec("truediv", {"self":str(self),"other":repr(other),"result":str(r)})
    return r
pathlib.PurePath.__truediv__ = f_div
_o_init = pathlib.PurePath.__init__
def f_init(self,*a,**k):
    try:
        if a and isinstance(a[0],str) and any(t in a[0] for t in ("hczvYP","ZlarPG")):
            rec("PurePath.__init__", {"args":[repr(x) for x in a]})
    except Exception: pass
    return _o_init(self,*a,**k)
pathlib.PurePath.__init__ = f_init
import wxautox4.utils.useful as U
# hardware info
try:
    h=U.ghi()
    rec("ghi", {"type":type(h).__name__, "val":repr(h)[:500]})
except BaseException as e:
    rec("ghi.err", "%s: %s"%(type(e).__name__,e))
import builtins
_bo=builtins.open
def opn(f,*a,**k):
    if any(t in str(f) for t in ("hczvYP","ZlarPG")): rec("open",{"path":str(f),"args":[repr(x) for x in a]})
    return _bo(f,*a,**k)
builtins.open=opn
try:
    from wxautox4.wx import WeChat
    WeChat(nickname="__p__")
    rec("OK","constructed")
except BaseException as e:
    rec("TOPEXC","%s: %s"%(type(e).__name__,e))
json.dump(LOG, io.open("artifacts/div_trace.json","w",encoding="utf-8"), ensure_ascii=False, indent=1, default=str)
for k,d in LOG: print("[%s]"%k, json.dumps(d,ensure_ascii=False)[:400])
