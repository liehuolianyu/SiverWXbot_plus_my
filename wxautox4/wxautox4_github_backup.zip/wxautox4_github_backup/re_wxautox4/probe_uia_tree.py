# -*- coding: utf-8 -*-
"""用 TreeWalker 递归枚举微信主窗口的 UIA 子树"""
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

from comtypes.client import CreateObject, GetModule

GetModule("UIAutomationCore.dll")
from comtypes.gen import UIAutomationClient as UIA

uia = CreateObject(UIA.CUIAutomation)
root = uia.GetRootElement()
walker = uia.CreateTreeWalker(uia.RawViewCondition)

# 定位 Qt 主窗口（root 的儿子里找）
el = walker.GetFirstChildElement(root)
target = None
while el:
    try:
        if el.CurrentClassName == "Qt51514QWindowIcon":
            target = el
            break
    except Exception:
        pass
    el = walker.GetNextSiblingElement(el)

print("main window found:", target is not None)
if target is None:
    raise SystemExit(1)
print("  name=%r pid=%s hwnd=%s" % (target.CurrentName, target.CurrentProcessId,
                                    target.CurrentNativeWindowHandle))

count = 0
stack = [(target, 0)]
lines = []


def dump(e, depth):
    global count
    kids = []
    c = walker.GetFirstChildElement(e)
    while c:
        kids.append(c)
        c = walker.GetNextSiblingElement(c)
    for k in kids:
        count += 1
        try:
            lines.append("%scls=%r name=%r type=%r" % (
                "  " * (depth + 1), k.CurrentClassName,
                (k.CurrentName or "")[:45], k.CurrentLocalizedControlType))
        except Exception as exc:
            lines.append("%s<err %r>" % ("  " * (depth + 1), exc))
        if depth < 6:
            dump(k, depth + 1)


dump(target, 0)
print("total descendants: %d" % count)
for L in lines[:60]:
    print(L)
