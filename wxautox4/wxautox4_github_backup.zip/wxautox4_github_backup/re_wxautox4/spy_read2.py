# -*- coding: utf-8 -*-
import sys, io, os, pathlib
TARGETS = ("hczvYWPCeRiP9bQN", "ZlarPGapI9grhljr")
CANDIDATE = os.environ.get("SPY_CONTENT", "")
class SpyStr(str):
    def _log(self, op, other=None):
        print("[SPY %s] self=%r other=%r" % (op, str.__repr__(self)[:120], repr(other)[:220]))
    def __eq__(self,o): self._log("eq",o); return str.__eq__(self,o)
    def __ne__(self,o): self._log("ne",o); return str.__ne__(self,o)
    def __contains__(self,o): self._log("contains",o); return str.__contains__(self,o)
    def __getitem__(self,i):
        r=str.__getitem__(self,i); self._log("getitem",i)
        return SpyStr(r) if isinstance(r,str) else r
    def split(self,*a,**k): self._log("split",a); return [SpyStr(x) for x in str.split(self,*a,**k)]
    def strip(self,*a): self._log("strip",a); return SpyStr(str.strip(self,*a))
    def replace(self,*a): self._log("replace",a); return SpyStr(str.replace(self,*a))
    def startswith(self,*a): self._log("startswith",a); return str.startswith(self,*a)
    def endswith(self,*a): self._log("endswith",a); return str.endswith(self,*a)
    def upper(self): self._log("upper"); return SpyStr(str.upper(self))
    def lower(self): self._log("lower"); return SpyStr(str.lower(self))
    def encode(self,*a,**k): self._log("encode",a); return str.encode(self,*a,**k)
    def __int__(self): self._log("int"); return str.__int__(self)
class FakeFile:
    def __init__(self,c): self._c=c
    def read(self,*a,**k): print("[SPY] read()"); return SpyStr(self._c)
    def read_text(self,*a,**k): print("[SPY] read_text()"); return SpyStr(self._c)
    def readlines(self): print("[SPY] readlines()"); return [SpyStr(x) for x in self._c.splitlines()]
    def close(self): pass
    def __enter__(self): return self
    def __exit__(self,*a): return False
_oe = pathlib.Path.exists
def f_exists(self):
    if any(t in str(self) for t in TARGETS):
        print("[SPY] exists ->True:", self)
        return True
    return _oe(self)
pathlib.Path.exists=f_exists
_of = pathlib.Path.open
def f_open(self,*a,**k):
    if any(t in str(self) for t in TARGETS):
        print("[SPY] open intercepted:", str(self), a, k)
        return FakeFile(CANDIDATE)
    return _of(self,*a,**k)
pathlib.Path.open=f_open
try:
    from wxautox4.wx import WeChat
    w=WeChat(nickname="__p__")
    print("RESULT: constructed OK")
except BaseException as e:
    print("RESULT RAISED:", type(e).__name__, "|", str(e)[:200])
