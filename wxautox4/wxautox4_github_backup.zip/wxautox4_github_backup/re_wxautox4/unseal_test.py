# -*- coding: utf-8 -*-
import sys, traceback
def unseal():
    import wxautox4.ui.main as M
    W = M.WeChatMainWnd
    f = W.__init__
    code = getattr(f, "__code__", None)
    if code is None: return "no code"
    fv = code.co_freevars or ()
    if "original_init" not in fv: return "not sealed (freevars=%s)" % (fv,)
    orig=None
    for nm, cell in zip(fv, f.__closure__ or ()):
        if nm == "original_init":
            try: orig = cell.cell_contents
            except Exception as e: return "cell err %s" % e
    if not callable(orig): return "orig not callable"
    W.__init__ = orig
    return "UNSEALED"

print("unseal ->", unseal())
import wxautox4.ui.main as M
print("WeChatMainWnd.__init__ now:", M.WeChatMainWnd.__init__)
print("code name now:", M.WeChatMainWnd.__init__.__code__.co_name, "@", M.WeChatMainWnd.__init__.__code__.co_firstlineno)
from wxautox4.wx import WeChat
try:
    w = WeChat(nickname="__probe__")
    print("RESULT: WeChat() OK ->", type(w).__name__)
except BaseException as e:
    print("RESULT RAISED:", type(e).__name__, "|", str(e)[:250])
    print("\n".join(traceback.format_exc().strip().splitlines()[-8:]))
