# -*- coding: utf-8 -*-
"""dry-run 验证 start.bat 的 cmd 解析：把 start 换成 echo，不真的启动服务。"""
import os
import subprocess
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

SRC = r"C:\Users\Administrator\Desktop\SiverWXbot_plus_start.bat"
TMP = os.path.join(os.path.dirname(os.path.abspath(__file__)), "_dryrun_start.bat")

data = open(SRC, "rb").read().decode("ascii")
data = data.replace('start "SiverWXbot_plus"', 'echo [DRYRUN-OK] start "SiverWXbot_plus"')
data = data.replace("timeout /t 3 /nobreak >nul", "rem timeout skipped")
with open(TMP, "wb") as fh:
    fh.write(data.encode("ascii"))

p = subprocess.run(["cmd", "/c", TMP], capture_output=True,
                   encoding="gbk", errors="replace")
print("returncode =", p.returncode)
print("--- stdout ---")
print(p.stdout)
if p.stderr.strip():
    print("--- stderr ---")
    print(p.stderr)

markers = ("不是内部或外部命令", "not recognized", "找不到指定的路径",
           "系统找不到", "cannot find", "syntax")
hits = [m for m in markers if m in p.stdout or m in p.stderr]
print("--- 判定 ---")
print("命中错误标记:", hits if hits else "无")
print("结论:", "解析有错 ✘" if hits else "解析干净 ✔")

try:
    os.remove(TMP)
except Exception:
    pass
