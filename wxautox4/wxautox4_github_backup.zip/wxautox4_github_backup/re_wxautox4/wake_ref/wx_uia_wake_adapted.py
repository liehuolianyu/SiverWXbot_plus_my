# -*- coding: utf-8 -*-
"""适配层：把社区工具 wechat_uia_wake.py 接到本机的 wxautox4 上

原工具 `_uia()` 只尝试 `wxauto4.uia.uiautomation` / `uiautomation`，
而本机装的是 `wxautox4`，因此这里覆盖 `_uia()`。

用法：
    python wx_uia_wake_adapted.py status     # 只读诊断
    python wx_uia_wake_adapted.py wake       # 热激活（写 1 字节，校验失败自动回滚）
    python wx_uia_wake_adapted.py restore    # 清除系统读屏标志
"""
import importlib.util
import os
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "wechat_uia_wake.py")

spec = importlib.util.spec_from_file_location("wx_uia_wake", SRC)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)


def _uia():
    """优先用本机 wxautox4 自带的那份 uiautomation"""
    try:
        from wxautox4.uia import uiautomation as auto
        return auto
    except Exception:
        pass
    try:
        import uiautomation as auto  # type: ignore
        return auto
    except Exception:
        return None


mod._uia = _uia

if __name__ == "__main__":
    raise SystemExit(mod.main(sys.argv[1:]))
