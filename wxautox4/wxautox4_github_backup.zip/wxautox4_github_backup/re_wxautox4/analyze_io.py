# -*- coding: utf-8 -*-
"""Crack the printable armor codec using known (ascii_blob, decoded_bytes) pairs."""
import json, io, os

HERE = os.path.dirname(os.path.abspath(__file__))
D = json.load(io.open(os.path.join(HERE, "artifacts", "raw_io.json"), encoding="utf-8"))

for k in ("wp", "fp", "pu", "pp", "fa", "wa"):
    print("=== %s (%d calls) ===" % (k, len(D[k])))
    for i, c in enumerate(D[k]):
        a = c.get("args", [])
        print("  call%d nargs=%d" % (i, len(a)))
        for j, v in enumerate(a):
            s = str(v)
            print("    arg%d len=%s : %s" % (j, (len(v) // 2 if isinstance(v, str) and all(ch in "0123456789abcdef" for ch in v.lower()) and len(v) % 2 == 0 else len(s)), s[:100]))
        r = c.get("ret")
        rs = str(r)
        print("    ret len=%s : %s" % (len(rs) // 2 if isinstance(r, str) else len(rs), rs[:100]))

print("\n=== HTTP ===")
for h in D["http"]:
    if "json" in h:
        print("REQ", h["url"], "data_len=", len(h["json"]["data"]))
        print("   data:", h["json"]["data"])
    else:
        print("RESP", h["url"], "len=", len(h.get("resp", "")))
        print("   resp:", h.get("resp", "")[:200])
