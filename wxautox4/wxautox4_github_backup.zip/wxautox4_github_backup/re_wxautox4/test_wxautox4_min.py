# -*- coding: utf-8 -*-
"""wxautox4 最小可用性验证（只读：不发送任何消息、不改动会话）

用法：
    <venv>\\Scripts\\python.exe test_wxautox4_min.py

检查项：
    [1] import wxautox4
    [2] 授权门已绕过（WeChat 构造不抛 SystemExit）
    [3] Win32 层能定位微信主窗口
    [4] UIA 无障碍闸门状态  <-- 失败时这里能直接看出根因
    [5] WeChat() 实际构造

前置条件：微信 PC 端已登录并运行。
"""
import ctypes
import ctypes.wintypes as wt
import sys
import traceback

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

PASS, FAIL = [], []


def ok(m):
    PASS.append(m)
    print("  [PASS] %s" % m)


def bad(m):
    FAIL.append(m)
    print("  [FAIL] %s" % m)


def info(m):
    print("  [INFO] %s" % m)


# --------------------------------------------------------------------------
# 3) Win32 层找主窗口
# --------------------------------------------------------------------------
WIN_CLS = "Qt51514QWindowIcon"
WIN_NAME = "微信"
UI_CLS = "mmui::MainWindow"      # wxautox4 期望的 UIA 类名


def find_main_window():
    u = ctypes.windll.user32
    u.GetClassNameW.argtypes = [wt.HWND, wt.LPWSTR, ctypes.c_int]
    u.GetWindowTextW.argtypes = [wt.HWND, wt.LPWSTR, ctypes.c_int]
    u.GetWindowThreadProcessId.argtypes = [wt.HWND, ctypes.POINTER(wt.DWORD)]
    CB = ctypes.WINFUNCTYPE(ctypes.c_bool, wt.HWND, wt.LPARAM)
    hits = []

    def cb(h, l):
        cls = ctypes.create_unicode_buffer(256)
        u.GetClassNameW(h, cls, 256)
        if cls.value != WIN_CLS:
            return True
        t = ctypes.create_unicode_buffer(256)
        u.GetWindowTextW(h, t, 256)
        if t.value != WIN_NAME:
            return True
        pid = wt.DWORD()
        u.GetWindowThreadProcessId(h, ctypes.byref(pid))
        r = wt.RECT()
        u.GetWindowRect(h, ctypes.byref(r))
        hits.append({"hwnd": h, "pid": pid.value, "cls": cls.value, "title": t.value,
                     "visible": bool(u.IsWindowVisible(h)),
                     "minimized": bool(u.IsIconic(h)),
                     "size": (r.right - r.left, r.bottom - r.top)})
        return True

    u.EnumWindows(CB(cb), 0)
    return hits


# --------------------------------------------------------------------------
# 4) UIA 层：目标窗口的 UIA 类名 + 后代里 mmui:: 元素数
# --------------------------------------------------------------------------
def probe_uia(hwnd):
    """权威判据：ControlFromHandle(hwnd) 的类名/子元素（与唤醒工具一致）"""
    auto = _load_uia()
    if auto is None:
        return "uiautomation 不可用", 0, 0
    ctl = auto.ControlFromHandle(hwnd)
    if ctl is None:
        return None, 0, 0
    try:
        ui_cls = ctl.ClassName
    except Exception:
        ui_cls = None
    kids = []
    try:
        kids = ctl.GetChildren()
    except Exception:
        pass
    n_mmui = sum(1 for k in kids
                 if (getattr(k, "ClassName", "") or "").startswith("mmui::"))
    if (ui_cls or "").startswith("mmui::"):
        n_mmui += 1
    return ui_cls, len(kids), n_mmui


def _load_uia():
    try:
        from wxautox4.uia import uiautomation as auto
        return auto
    except Exception:
        return None


def main():
    print("=" * 66)
    print("wxautox4 最小可用性验证（只读）")
    print("=" * 66)

    # 1) 导入
    print("\n[1] 导入 wxautox4")
    try:
        import wxautox4
        print("      module -> %s" % getattr(wxautox4, "__file__", "?"))
        ok("import 成功")
    except Exception as exc:
        bad("import 失败: %r" % (exc,))
        return 1

    # 3) Win32 找窗口（先做，因为 [2] 需要窗口信息才能判断）
    print("\n[3] Win32 层定位微信主窗口")
    try:
        wins = find_main_window()
        if not wins:
            bad("未找到 class=%s title=%s 的顶层窗口（微信没开？）" % (WIN_CLS, WIN_NAME))
            return 1
        w0 = wins[0]
        print("      hwnd=0x%08X pid=%d visible=%s minimized=%s size=%sx%s"
              % (w0["hwnd"], w0["pid"], w0["visible"], w0["minimized"], *w0["size"]))
        ok("找到微信主窗口")
    except Exception as exc:
        bad("枚举窗口失败: %r" % (exc,))
        return 1

    # 4) UIA 闸门
    print("\n[4] UIA 无障碍闸门")
    try:
        ui_cls, n_all, n_mmui = probe_uia(w0["hwnd"])
        print("      目标窗口 UIA 类名 = %r（期望 %r）" % (ui_cls, UI_CLS))
        print("      UIA 后代总数 = %d，其中 mmui:: 元素 = %d" % (n_all, n_mmui))
        if n_mmui > 0:
            ok("闸门已激活，控件树已物化")
        else:
            bad("闸门未激活：UIA 只见 Qt 空壳，%d 个后代 / %d 个 mmui 元素" % (n_all, n_mmui))
            info("这正是 '未找到已登录的客户端主窗口' 的根因")
    except Exception as exc:
        bad("UIA 探测失败: %r" % (exc,))
        traceback.print_exc()

    # 2) 授权门 + 5) 实际构造
    print("\n[2][5] 构造 WeChat()（授权门 + 业务层）")
    try:
        from wxautox4 import WeChat
        try:
            wx = WeChat()
            ok("构造成功 -> %r" % (wx,))
            print("\n      当前会话数: %d" % len(wx.GetSession()))
        except SystemExit:
            bad("[2] 仍被授权门 SystemExit 拦截（补丁未生效）")
        except BaseException as exc:
            msg = str(exc).splitlines()[0] if str(exc) else ""
            if "未授权设备" in msg or "授权" in msg:
                bad("[2] 授权门未绕过: %s" % msg)
            else:
                bad("[5] 授权门已过，但业务层失败: %s" % msg)
    except Exception as exc:
        bad("导入 WeChat 失败: %r" % (exc,))

    print("\n" + "=" * 66)
    print("结果：%s（通过 %d / 失败 %d）"
          % ("全部通过" if not FAIL else "存在失败项", len(PASS), len(FAIL)))
    if FAIL:
        print("说明：见 [4] —— 微信 4.x 的无障碍闸门未激活时，")
        print("      wxautox4 无法建立 UIA 控件树，任何微信自动化都连不上。")
    print("=" * 66)
    return 0 if not FAIL else 1


if __name__ == "__main__":
    raise SystemExit(main())
