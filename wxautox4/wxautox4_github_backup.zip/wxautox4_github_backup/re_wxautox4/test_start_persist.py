# -*- coding: utf-8 -*-
"""只保留 SPI_SETSCREENREADER=1（清掉 QT_ACCESSIBILITY），并测试微信启动存活"""
import subprocess
import sys
import time
import winreg

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

# 1) 清掉 QT_ACCESSIBILITY
try:
    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment", 0,
                        winreg.KEY_SET_VALUE) as k:
        winreg.DeleteValue(k, "QT_ACCESSIBILITY")
    print("[1] QT_ACCESSIBILITY 已删除")
except FileNotFoundError:
    print("[1] QT_ACCESSIBILITY 本就不存在")

import ctypes
v = ctypes.c_int(0)
ctypes.windll.user32.SystemParametersInfoW(0x0046, 0, ctypes.byref(v), 0)
print("    SPI_GETSCREENREADER =", v.value)

EXE = r"C:\Program Files\Tencent\Weixin\Weixin.exe"


def pids():
    import psutil
    return [p.info["pid"] for p in psutil.process_iter(["pid", "name"])
            if p.info["name"] and p.info["name"].lower() == "weixin.exe"]


print("\n[2] 启动前:", pids())
print("    启动微信（DETACHED + BREAKAWAY）...")
try:
    subprocess.Popen([EXE],
                     creationflags=0x00000008 | 0x00000200 | 0x01000000,
                     close_fds=True)
    print("    breakaway ok")
except OSError as e:
    print("    breakaway 失败 %r，退化为 DETACHED" % (e,))
    subprocess.Popen([EXE], creationflags=0x00000008 | 0x00000200, close_fds=True)

print("\n[3] 观察 40 秒：")
last = None
for i in range(20):
    time.sleep(2)
    p = pids()
    if p != last:
        print("    %2ds -> %s" % ((i + 1) * 2, p))
        last = p
    if not p and i > 2:
        break
print("\n最终:", pids())
