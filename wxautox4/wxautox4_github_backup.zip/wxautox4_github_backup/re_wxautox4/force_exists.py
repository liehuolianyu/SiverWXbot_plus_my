# -*- coding: utf-8 -*-
import sys, os, pathlib, traceback
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "bypass"))
import wxautox4_nolicense
TARGET = ("hczvYWPCeRiP9bQN","ZlarPGapI9grhljr")
_oe = pathlib.Path.exists
def fake(self):
    if any(t in str(self) for t in TARGET):
        print("[force-exists]", self); return True
    return _oe(self)
pathlib.Path.exists = fake
_orf = pathlib.Path.open
_ort = pathlib.Path.read_text
_orb = pathlib.Path.read_bytes
def f_open(self,*a,**k):
    if any(t in str(self) for t in TARGET):
        print("[read-open]", self, a, k); return _orf(self,*a,**k)
    return _orf(self,*a,**k)
def f_rt(self,*a,**k):
    if any(t in str(self) for t in TARGET):
        print("[read-text]", self); 
    return _ort(self,*a,**k)
def f_rb(self,*a,**k):
    if any(t in str(self) for t in TARGET):
        print("[read-bytes]", self)
    return _orb(self,*a,**k)
pathlib.Path.open=f_open; pathlib.Path.read_text=f_rt; pathlib.Path.read_bytes=f_rb
try:
    from wxautox4.wx import WeChat
    w=WeChat(nickname="__probe__")
    print("RESULT: constructed OK")
except BaseException as e:
    print("RESULT RAISED:", type(e).__name__, "|", str(e)[:200])
    print("\n".join(traceback.format_exc().strip().splitlines()[-5:]))
