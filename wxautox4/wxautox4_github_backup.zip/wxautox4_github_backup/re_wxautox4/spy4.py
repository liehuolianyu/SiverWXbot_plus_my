# -*- coding: utf-8 -*-
import sys, pathlib, os, io
LOG=[]
def rec(k,d):
    LOG.append((k,d))
for nm in ("exists","is_dir","is_file","open","read_text","read_bytes","iterdir","glob","stat","resolve","absolute"):
    pass
import pathlib as pl
class P(type(pl.Path())):
    pass
# wrap methods on Path class
PATHM=("exists","is_dir","is_file","open","read_text","read_bytes","iterdir","glob","stat","resolve","samefile","is_symlink")
for nm in PATHM:
    o=getattr(pl.Path,nm,None)
    if o is None: continue
    def mk(o,nm):
        def w(self,*a,**k):
            rec("Path."+nm, str(self))
            r=o(self,*a,**k)
            if nm in ("read_text","read_bytes"):
                rec("  ->value", repr(r)[:200])
            return r
        return w
    try: setattr(pl.Path,nm,mk(o,nm))
    except Exception: pass
for nm in ("path.exists","path.isdir","path.isfile","listdir","stat","open","getsize"):
    if not hasattr(os,nm): continue
    o=getattr(os,nm)
    def mk(o,nm):
        def w(*a,**k):
            rec("os."+nm, str(a[:1]))
            return o(*a,**k)
        return w
    setattr(os,nm,mk(o,nm))
import builtins
_bo=builtins.open
def opn(f,*a,**k):
    rec("open", str(f)); return _bo(f,*a,**k)
builtins.open=opn
# unseal
import wxautox4.ui.main as M
W=M.WeChatMainWnd; f=W.__init__; c=f.__code__
for nm,cell in zip(c.co_freevars, f.__closure__ or ()):
    if nm=="original_init": W.__init__=cell.cell_contents
try:
    from wxautox4.wx import WeChat
    WeChat(nickname="__p__")
    rec("RESULT","OK")
except BaseException as e:
    rec("RESULT", "%s: %s"%(type(e).__name__,str(e)[:120]))
for k,d in LOG[-45:]:
    print("[%s] %s" % (k, d))
