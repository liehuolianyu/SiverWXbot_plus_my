# -*- coding: utf-8 -*-
"""激活微信窗口后读取消息，尝试取到自己昵称"""
import ctypes
import ctypes.wintypes as wt
import importlib.util
import os
import sys
import time

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

HERE = r"C:\Users\Administrator\WorkBuddy\2026-10-14-16-19-40\re_wxautox4"
spec = importlib.util.spec_from_file_location(
    "wx_uia_wake", os.path.join(HERE, "wake_ref", "wechat_uia_wake.py"))
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
from wxautox4.uia import uiautomation as auto  # noqa: E402
mod._uia = lambda: auto

spec2 = importlib.util.spec_from_file_location(
    "compat", os.path.join(HERE, "bypass", "wxautox4_compat_414.py"))
compat = importlib.util.module_from_spec(spec2)
spec2.loader.exec_module(compat)
compat.install()

u = ctypes.windll.user32
u.GetClassNameW.argtypes = [wt.HWND, wt.LPWSTR, ctypes.c_int]
u.GetWindowTextW.argtypes = [wt.HWND, wt.LPWSTR, ctypes.c_int]
CB = ctypes.WINFUNCTYPE(ctypes.c_bool, wt.HWND, wt.LPARAM)
st = {"h": 0}


def cb(h, l):
    b = ctypes.create_unicode_buffer(128)
    u.GetClassNameW(h, b, 128)
    if b.value == "Qt51514QWindowIcon":
        t = ctypes.create_unicode_buffer(128)
        u.GetWindowTextW(h, t, 128)
        if t.value == "微信":
            st["h"] = h
            return False
    return True


u.EnumWindows(CB(cb), 0)
hwnd = st["h"]
print("hwnd=0x%08X  当前前台=0x%08X" % (hwnd, u.GetForegroundWindow()))

# 多种激活手段
u.ShowWindow(hwnd, 9)                      # SW_RESTORE
u.SwitchToThisWindow(hwnd, True)
time.sleep(0.5)
u.SetWindowPos(hwnd, -1, 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0040)  # TOPMOST, NOSIZE|NOMOVE|SHOW
time.sleep(0.3)
u.SetWindowPos(hwnd, -2, 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0040)  # NOTOPMOST
u.SetForegroundWindow(hwnd)
time.sleep(1.5)
print("激活后前台=0x%08X" % u.GetForegroundWindow())

print("wake:", mod.wake().get("ok"))
from wxautox4 import WeChat  # noqa: E402
wx = WeChat()
print("nickname =", repr(wx.nickname))

for name in ("测试", "YZ", "文件传输助手"):
    try:
        wx.ChatWith(name)
    except Exception as e:
        print("ChatWith(%s) 失败: %r" % (name, e))
        continue
    time.sleep(1.2)
    try:
        msgs = wx.GetAllMessage()
    except Exception as e:
        print("[%s] GetAllMessage 失败: %r" % (name, e))
        continue
    print("\n[%s] %d 条消息" % (name, len(msgs)))
    for m in msgs[-10:]:
        print("    attr=%-8r sender=%-16r content=%r"
              % (getattr(m, "attr", None), getattr(m, "sender", None),
                 str(getattr(m, "content", ""))[:36]))
