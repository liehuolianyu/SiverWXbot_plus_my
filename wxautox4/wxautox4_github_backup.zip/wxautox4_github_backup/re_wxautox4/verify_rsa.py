# -*- coding: utf-8 -*-
"""Verify the RSA relation observed in the trace and extract the server public key."""
import json
import io
import os

HERE = os.path.dirname(os.path.abspath(__file__))
tr = json.load(io.open(os.path.join(HERE, "artifacts", "cipher_trace.json"), encoding="utf-8"))
events = tr if isinstance(tr, list) else tr.get("events", [])

calls = []
for e in events:
    if e["t"] == "CALL":
        calls.append(("CALL", e["d"]))
    elif e["t"] == "RET":
        calls.append(("RET", e["d"]))
    elif e["t"] == "RETERR":
        calls.append(("RETERR", e["d"]))

# pair up sequential pp->fa and wa
print("=== sequence of crypto calls ===")
seq = [d for k, d in calls if k in ("CALL", "RET", "RETERR") and d.get("fn") in ("pp", "fa", "wa", "cea")]
for d in seq:
    keys = {k: str(v)[:70] for k, v in d.items() if k != "ind"}
    print(keys)

# Reconstruct: pp_out (bytes) should equal PKCS1v15 pad; fa_out (int) should equal RSA(pad)
pp_out = fa_out = None
wa_outs = []
for k, d in calls:
    if k == "RET" and d.get("fn") == "pp" and pp_out is None:
        pp_out = bytes.fromhex(d["ret"][2:])
    if k == "RET" and d.get("fn") == "fa" and fa_out is None:
        fa_out = int(d["ret"])
    if k == "RET" and d.get("fn") == "wa":
        wa_outs.append(bytes.fromhex(d["ret"][2:]))

print("\npp_out len:", len(pp_out) if pp_out else None,
      "head:", pp_out[:8].hex() if pp_out else None)
if pp_out:
    # PKCS#1 v1.5 type 2 block: 00 02 <nonzero padding> 00 <message>
    i = pp_out.find(b"\x00", 2)
    print("padding separator at:", i, "message:", pp_out[i + 1:][:160])

print("\nfa_out bits:", fa_out.bit_length() if fa_out else None)
print("wa_out lens:", [len(x) for x in wa_outs])
if fa_out is not None and wa_outs:
    print("int(wa_out[0]) == fa_out ?", int.from_bytes(wa_outs[0], "big") == fa_out)

# extract modulus: the (e, n) tuple given as key. Find it in CALL args of wa
for k, d in calls:
    if k == "CALL" and d.get("fn") == "wa" and len(d.get("args", [])) == 2:
        print("\nwa key arg:", d["args"][1][:200])

# find full modulus from any CALL arg containing ', '
for k, d in calls:
    if k == "CALL" and d.get("fn") in ("wa", "fa"):
        for a in d.get("args", []):
            if a.startswith("(65537,"):
                n = int(a.split(",")[1].strip().rstrip(")"))
                print("\nPUBLIC KEY (e=65537)")
                print("n bits:", n.bit_length())
                print("n dec:", n)
                print("n hex:", hex(n))
