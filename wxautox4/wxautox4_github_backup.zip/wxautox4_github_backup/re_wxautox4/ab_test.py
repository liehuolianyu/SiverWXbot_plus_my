# -*- coding: utf-8 -*-
import sys, os, traceback
PATCHED = os.environ.get("WB_PATCH") == "1"
if PATCHED:
    sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "bypass"))
    import wxautox4_nolicense
print("### MODE:", "PATCHED" if PATCHED else "VANILLA")
try:
    import wxautox4
    print("import wxautox4 OK")
except BaseException as e:
    print("import wxautox4 ERR", type(e).__name__, e); raise SystemExit
try:
    from wxautox4.wx import WeChat
    print("from .wx import WeChat OK")
except BaseException as e:
    print("import wx ERR", type(e).__name__, e); raise SystemExit
try:
    w = WeChat(nickname="__wb_probe__")
    print("WeChat() constructed OK ->", type(w).__name__)
except BaseException as e:
    print("WeChat() RAISED:", type(e).__name__, "|", str(e)[:300])
    tb = traceback.format_exc()
    print("--- tb tail ---")
    print("\n".join(tb.strip().splitlines()[-6:]))
