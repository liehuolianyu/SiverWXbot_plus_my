# -*- coding: utf-8 -*-
"""完全退出微信并重新启动（让无障碍闸门开关生效）"""
import os
import subprocess
import sys
import time

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

EXE = r"C:\Program Files\Tencent\Weixin\Weixin.exe"
sys.path.insert(0, r"C:\Users\Administrator\WorkBuddy\2026-10-14-16-19-40\re_wxautox4")


def pids():
    import psutil
    return [p.info["pid"] for p in psutil.process_iter(["pid", "name"])
            if p.info["name"] and p.info["name"].lower() == "weixin.exe"]


print("[1] 当前微信进程:", pids())
print("[2] 结束微信进程 ...")
subprocess.run(["taskkill", "/F", "/IM", "Weixin.exe"],
               capture_output=True, text=True)
time.sleep(3)
print("    剩余:", pids())

print("[3] 重新启动微信 ...")
flags = 0x00000008 | 0x00000200 | 0x01000000   # DETACHED | NEW_GROUP | BREAKAWAY
try:
    subprocess.Popen([EXE], creationflags=flags, close_fds=True)
except OSError as e:
    print("    breakaway 失败(%r)，改用普通模式" % (e,))
    subprocess.Popen([EXE], creationflags=0x00000008 | 0x00000200, close_fds=True)

print("[4] 等待微信启动 ...")
for i in range(30):
    time.sleep(2)
    p = pids()
    if p:
        print("    已启动 pid=%s (%.0fs)" % (p, (i + 1) * 2))
        break
else:
    print("    30 秒内未检测到 Weixin.exe 进程")
    raise SystemExit(1)

# 等主窗口出现
import ctypes
import ctypes.wintypes as wt
u = ctypes.windll.user32
u.GetClassNameW.argtypes = [wt.HWND, wt.LPWSTR, ctypes.c_int]
CB = ctypes.WINFUNCTYPE(ctypes.c_bool, wt.HWND, wt.LPARAM)
state = {"hwnd": 0}


def cb(h, l):
    b = ctypes.create_unicode_buffer(128)
    u.GetClassNameW(h, b, 128)
    if b.value != "Qt51514QWindowIcon":
        return True
    t = ctypes.create_unicode_buffer(128)
    u.GetWindowTextW(h, t, 128)
    if t.value == "微信":
        state["hwnd"] = h
        return False
    return True


for i in range(30):
    u.EnumWindows(CB(cb), 0)
    if state["hwnd"]:
        print("[5] 主窗口已出现 hwnd=0x%08X (%.0fs)" % (state["hwnd"], (i + 1) * 2))
        break
    time.sleep(2)
else:
    print("[5] 未等到标题为「微信」的主窗口（可能停在登录二维码界面）")
print("\n完成。请运行 fix_uia_gate.py verify 检查闸门。")
