# -*- coding: utf-8 -*-
import inspect, sys
import wxautox4.ui.main as M
print("=== ui.main 全部非 dunder 属性 ===")
names=[n for n in dir(M) if not n.startswith("__")]
print(len(names))
for n in names:
    o=getattr(M,n)
    kind = "class" if inspect.isclass(o) else ("fn" if callable(o) else type(o).__name__)
    mod=getattr(o,"__module__","")
    if kind in ("class","fn") and not mod.startswith("wxautox4"):
        continue
    print("  %-40s %s" % (n, mod))
print()
print("=== ui.main 中的类及其含 guard/lic 的方法 ===")
for n in names:
    o=getattr(M,n)
    if inspect.isclass(o) and getattr(o,"__module__","").startswith("wxautox4"):
        ms=[m for m in dir(o) if any(k in m.lower() for k in ("guard","lic","auth","init","check"))]
        print("  class",n,"->",ms[:20])
