# -*- coding: utf-8 -*-
import sys, types
import wxautox4.wx as W
from wxautox4.wx import WeChat
TARGETS={"guarded_init","_cnka","nksa","lolic","_seal_wechat_main_init"}
found=[]
seen=set()
def check(obj, where):
    if id(obj) in seen: return
    seen.add(id(obj))
    code=getattr(obj,"__code__",None)
    if code is not None:
        nm=getattr(code,"co_name","")
        if nm in TARGETS:
            found.append((where, nm, getattr(code,"co_filename","").split("site-packages")[-1], code.co_firstlineno))
# module dicts
for name,mod in list(sys.modules.items()):
    if not isinstance(mod, types.ModuleType): continue
    for k,v in list(vars(mod).items()):
        if callable(v): check(v, "%s.%s"%(name,k))
# classes
for name,mod in list(sys.modules.items()):
    if not isinstance(mod, types.ModuleType): continue
    for k,v in list(vars(mod).items()):
        if isinstance(v,type):
            for ck,cv in list(vars(v).items()):
                if callable(cv): check(cv, "%s.%s.%s"%(name,k,ck))
print("found:", len(found))
for f in found: print("  ", f)
print()
print("WeChat.__init__ co:", WeChat.__init__.__code__.co_filename.split("site-packages")[-1], WeChat.__init__.__code__.co_firstlineno)
print("WeChat attrs with func:", [ (k, getattr(getattr(WeChat,k),'__code__',None) and getattr(WeChat,k).__code__.co_name) for k in dir(WeChat) if callable(getattr(WeChat,k,None)) and hasattr(getattr(WeChat,k),'__code__')][:20])
