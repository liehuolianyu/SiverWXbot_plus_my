# SiverWXbot_plus 报错分析：`OpenAIError: Missing credentials`

**结论（一句话）**：`config/config.json` 里默认接口 `api_configs[0]` 的
`key` / `url` / `model` **三个字段全是空字符串**，机器人启动时把空 key 传给
OpenAI 客户端，客户端判定为「无凭证」直接抛错，线程随即退出。

> 跟 wxautox4 授权无关 —— 那个已经解决了。这是**配置未填写**导致的启动期崩溃。

---

## 一、报错链逐层对应（含真实行号）

```
bot_lifecycle.py:450   _thread_body()
  └─ 捕获 BaseException → log("机器人线程异常退出: ...") → 线程结束
web_server.py:1313     _bot_runner()      → WXBot(stop_event=...)
wxbot_core.py:2271     WXBot.__init__     → self.api = self._init_api()
wxbot_core.py:2308     _init_api()        → return OpenAIAPI(self.config)
wxbot_core.py:1365     OpenAIAPI.__init__ → OpenAI(api_key=config.api_key, base_url=config.base_url, ...)
openai/_client.py:276  凭证校验失败 → raise OpenAIError("Missing credentials. ...")
```

关键一行在 `wxbot_core.py:1365`：

```python
self.client = OpenAI(
    api_key=config.api_key,      # ← 这里是空字符串
    base_url=config.base_url,    # ← 这里也是空的
    timeout=180.0,
    max_retries=2,
    ...
)
```

而 `config.api_key` 的来源在 `wxbot_core.py:737-741`：

```python
_cur = self.api_configs[self.api_index] if self.api_configs else {}
self.api_sdk  = _cur.get('sdk', '')
self.api_key  = _cur.get('key', '')      # ← 取自 api_configs[api_index]['key']
self.base_url = _cur.get('url', '')
self.model1   = _cur.get('model', '')
```

对照 `config/config.json` 实际内容：

```json
"api_configs": [
    {
        "sdk": "OpenAI API 格式兼容接口",
        "model": "",          ← 空
        "url": "",            ← 空
        "key": "",            ← 空（就是这个导致报错）
        "fallback_api_index": -1
    },
    { "sdk": "", "model": "", "url": "", "key": "", "fallback_api_index": -1 }
],
"api_index": 0,
```

---

## 二、决定性证据（openai 3.31.0 的真实判定逻辑）

`.venv/Lib/site-packages/openai/_client.py`（第 256-276 行）：

```python
else:
    if api_key is None:
        api_key = os.environ.get("OPENAI_API_KEY")
    ...
    else:
        self.api_key = api_key or ""      # 空字符串 "" 保持为 ""

if admin_api_key is None and provider_runtime is None:
    admin_api_key = os.environ.get("OPENAI_ADMIN_KEY")
self.admin_api_key = ...

if (
    provider_runtime is None
    and _enforce_credentials
    and not self.api_key                  # ← "" 是 falsy，这里成立
    and self._api_key_provider is None
    and workload_identity is None
    and self.admin_api_key is None
):
    raise OpenAIError("Missing credentials. Please pass an `api_key`, ...")
```

因为传进去的是**空字符串而不是 `None`**，SDK 不会回退去读环境变量，
直接判定 `not self.api_key` 为真并抛错。而当前环境里
`OPENAI_API_KEY` / `OPENAI_BASE_URL` / `OPENAI_ADMIN_KEY` **均未设置**，
所以没有任何兜底路径。

### 实测 A/B（本机真实执行结果）

```
=== A) 当前配置原样（url/key/model 全空）
  OpenAIError: Missing credentials. Please pass an `api_key`, `workload_identity`,
  `admin_api_key`, or set the `OPENAI_API_KEY` or `OPENAI_ADMIN_KEY` environment variable.
                                              ↑ 与你的报错完全一致

=== B) 补齐 url + key + model（占位值）
  构造成功 -> OpenAIAPI
  客户端 base_url = 'https://api.deepseek.com/v1/'
  => 启动阶段的 Missing credentials 已被消除
```

---

## 三、为什么是"现在"才报错（升级迁移的静默丢 key 风险）

这不是随机故障，代码里有**两个会静默清掉旧 key 的位置**：

**① `config_defaults.py:409-411` — `normalize()`**

```python
# 已有新格式 api_configs 时，清掉旧版单接口字段
if 'api_configs' in config:
    for _k in ('api_sdk', 'api_key', 'base_url', 'model1', 'model2', 'api_sdk_list'):
        config.pop(_k, None)          # 无条件删除
```

**② `config_defaults.py:438-450` — `migrate()`**

```python
if 'api_sdk' in config:                       # 旧版顶层字段存在
    if 'api_configs' not in config:           # 只有「完全没有」新字段时才搬运
        config['api_configs'] = [
            {'sdk': ..., 'key': config.get('api_key', ''), ...}   # 搬运旧 key
        ]
    for _k in ('api_sdk', 'api_key', 'base_url', 'model1', ...):
        config.pop(_k, None)                  # ← 但无论如何都删旧字段
```

**风险场景**：配置里**同时**存在旧版顶层 `api_key` 和新版 `api_configs`
（哪怕是刚建出来的空接口），那么：

- 「搬运」被跳过（因为 `api_configs` 已存在）
- 「删除」照常执行

→ **旧 key 被删掉，新位置里又没有 → key 彻底丢失。**

本机还留有一次配置快照 `old_wxbot_config/20261014171850/`（内含 `v4.8.0`
版本标记），说明这套配置经历过一次版本迁移。**当前配置与全部历史快照里
都查不到任何 key**，与上述迁移风险的表现一致。

> 无法从现存文件 100% 复原历史（快照是清理之后拍的），但可以确定：
> **当前所有配置文件里都没有 API Key。**

---

## 四、怎么修

### 方案 1：Web 面板（推荐，与项目设计一致）

启动 `web_server`，在接口配置区域（`templates/dashboard.html` 的
`api_configs_container`）填写 SDK / URL / Key / Model，点「测试接口」——
`/test_api_config` 会做完整校验，三项缺任一都会明确报出来：

```
API Key 不能为空 / Base URL 不能为空 / 模型名称不能为空
```

### 方案 2：命令行工具（本次新增，复用项目自身 ConfigStore）

```bat
cd /d <项目目录>

:: 先看当前状态（只读）
.venv_clean\Scripts\python.exe tools\set_api_config.py --check

:: 填写默认接口（api_index=0）
.venv_clean\Scripts\python.exe tools\set_api_config.py ^
    --key sk-你的key ^
    --url https://api.deepseek.com/v1 ^
    --model deepseek-chat

:: 填完顺便测一次真实连通性
.venv_clean\Scripts\python.exe tools\set_api_config.py --check --test
```

用 `--index 1` 可填第 2 个接口。工具走的是项目自己的
`ConfigStore`（同一把路径锁 + 原子写 + `config_defaults.prepare` 规范化），
和面板保存行为一致，不会破坏配置。

### 方案 3：手工改 JSON

编辑 `config/config.json` 的 `api_configs[0]`，把 `url` / `key` / `model` 填上。
**必须先停掉 web_server 和机器人**，否则面板会把内存里的旧配置原子写回、
覆盖你的修改。

> ⚠ 不要试图去填顶层的 `api_key` / `base_url` / `model1` —— 那些是旧版字段，
> 会在 `normalize()` 阶段被删掉，白改。

### 改完之后

`api_configs` 属于「**需重建 API 客户端**」的改动
（`config_apply.py` 的 `API_REBUILD_REASONS`）。`WXBot.api` 是启动时
`_init_api()` 建好的对象，所以：

- 机器人在跑 → 在面板上**停止再启动机器人**（触发 `apply_config()` 重建客户端）
- 或直接**重启 web_server**

---

## 五、顺带发现的 3 个隐患

**1. 启动路径缺少同样的校验**（健壮性缺陷）

面板的 `/test_api_config` 会拦「API Key 不能为空 / Base URL 不能为空 /
模型名称不能为空」，但**启动路径 `_init_api()` 没有任何校验**，
直接用空 key 构造客户端 → 崩。建议给 `_init_api()` 加一层前置校验，
像 `UnconfiguredAPI` 那样降级而不是让整个线程死掉：

```python
def _init_api(self):
    sdk = self.config.api_sdk
    if sdk in OPENAI_SDK_ALIASES:
        if not (self.config.api_key and self.config.base_url and self.config.model1):
            log(level="WARNING", message="接口配置不完整（key/url/model 有空值），"
                                         "已降级为未配置接口，请在面板补齐后重启机器人")
            return UnconfiguredAPI(self.config)
        return OpenAIAPI(self.config)
    ...
```

**2. `url` 为空是第二颗雷**

即使只把 key 填上，`OpenAI(api_key='sk-x', base_url='')` 也**不会报错**，
但 `client.base_url` 会变成 `URL('')` —— 后续请求必然失败，
只是报错信息不再是 Missing credentials 而是别的，更难定位。**三项必须一起填。**

**3. 有两个虚拟环境，别用错**

| 环境 | 状态 | 谁在用 |
|---|---|---|
| `.venv` | Python 3.12.7 + openai 3.31.0 + wxautox4 | 你这次报错的运行路径 |
| `.venv_clean` | 同上，完整 | `start_siverwxbot.ps1` 指向它 |

两者依赖都齐。但**启动脚本用的是 `.venv_clean`**，如果你用 `.venv` 手工跑，
就绕过了启动脚本。建议统一用一个，避免"明明改了配置却像是没生效"的错觉。

---

## 六、排查用速查表

| 现象 | 原因 | 处理 |
|---|---|---|
| `Missing credentials` | `api_configs[i].key` 为空 | 填 key（本报告方案 1/2/3） |
| 填了 key 仍请求失败 | `url` 或 `model` 为空 | 三项一起填 |
| 改完配置没生效 | `api_configs` 需重建客户端 | 停/启机器人或重启 web_server |
| 改完又被还原 | 服务在跑，旧配置被写回 | 先停服务再改，或用面板/工具改 |
| `未找到已登录的客户端主窗口` | 与授权无关，是微信没登录 | 登录微信 PC 端（wxautox4 补丁已放行授权） |

---

*分析基于实际读取的源代码与在本机执行的复现实验，未做推测性结论。*
