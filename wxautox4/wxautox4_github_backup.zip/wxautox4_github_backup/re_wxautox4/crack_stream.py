# -*- coding: utf-8 -*-
"""Locate the plaintext inside the armored blob and characterise the stream.

Known:
  S_resp (423 chars, printable)  -> decodes to a 256-byte RSA block
  b64 of that 256-byte block is 344 chars and IS a substring of the decoded text
So plaintext P (423 chars) contains B (344 chars). 423-344 = 79 chars of wrapper.
"""
import json, io, os
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))
D = json.load(io.open(os.path.join(HERE, "artifacts", "b64_trace.json"), encoding="utf-8"))

S_resp = None
B = None
for k, v in D:
    if k == "RESP" and "activate" in v.get("url", ""):
        S_resp = v["text"]
    if k == "b64.b64encode":
        B = v["ret"]
        if isinstance(B, str) and B.startswith("b'"):
            B = B[2:-1]

print("S len:", len(S_resp), "B len:", len(B))
print("S:", repr(S_resp[:60]))
print("B:", repr(B[:60]))

print("\nS char freq (top15):", Counter(S_resp).most_common(15))
print("distinct in S:", len(set(S_resp)))

# try every offset: assume P[o:o+344] == B, derive delta table
ALPHA = "".join(chr(i) for i in range(33, 127))  # 94 printable


def delta_pairs(off):
    ds = []
    for i in range(len(B)):
        c = S_resp[off + i]
        p = B[i]
        d = (ord(c) - ord(p)) % 94
        ds.append(d)
    return ds


best = []
for off in range(0, len(S_resp) - len(B) + 1):
    ds = delta_pairs(off)
    c = Counter(ds)
    # score: how concentrated (monoalphabetic would be 1 distinct)
    best.append((len(c), c.most_common(1)[0][1], off, c.most_common(6)))

best.sort()
print("\ntop offsets by delta-distinctness:")
for nd, topc, off, mc in best[:8]:
    print("  off=%d distinct_delta=%d top=%s" % (off, nd, mc))

# Also: is S a per-char shift of B with a constant?
if best:
    nd, topc, off, mc = best[0]
    if nd <= 4:
        print("\n*** likely mono-alphabetic at offset", off, "mapping:", mc)

# Check if the wrapper (79 chars) looks like JSON
def try_wrapper(S, B, off):
    pre = S[:off]
    post = S[off + len(B):]
    return pre, post


for off in (0, len(S_resp) - len(B)):
    pre, post = try_wrapper(S_resp, B, off)
    print("\noffset", off, "pre=", repr(pre[:100]), "post=", repr(post[:100]))
