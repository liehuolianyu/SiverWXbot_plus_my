# -*- coding: utf-8 -*-
"""通过 WMI 启动微信（进程挂到 WmiPrvSE 下，不会被本工具的作业对象回收）"""
import sys
import time

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

EXE = r"C:\Program Files\Tencent\Weixin\Weixin.exe"


def pids():
    import psutil
    return [p.info["pid"] for p in psutil.process_iter(["pid", "name"])
            if p.info["name"] and p.info["name"].lower() == "weixin.exe"]


print("启动前:", pids())
import win32com.client

wmi = win32com.client.GetObject("winmgmts:\\\\.\\root\\cimv2:Win32_Process")
res = wmi.Create(EXE)
print("WMI Create ->", res)
time.sleep(5)
print("启动后:", pids())
