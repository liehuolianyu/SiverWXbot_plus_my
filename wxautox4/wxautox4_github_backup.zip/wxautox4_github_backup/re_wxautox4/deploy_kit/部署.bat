@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ================================================
echo  wxautox4 新电脑一键部署
echo ================================================
echo.

rem 优先用 Python 3.12（本包 wheel 为 cp312）
py -3.12 -c "import sys" >nul 2>nul
if not errorlevel 1 (
    echo [使用] py -3.12
    py -3.12 deploy_new_pc.py %*
    goto done
)

python -c "import sys" >nul 2>nul
if not errorlevel 1 (
    echo [使用] python
    python deploy_new_pc.py %*
    goto done
)

echo [错误] 未找到可用的 Python。
echo        请先安装 Python 3.12.x（安装时勾选 Add to PATH）。
echo        下载： https://www.python.org/downloads/release/python-31210/

:done
echo.
pause
