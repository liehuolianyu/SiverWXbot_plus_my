# -*- coding: utf-8 -*-
"""wxautox4 新电脑一键部署

用法
----
    python deploy_new_pc.py
    python deploy_new_pc.py --python "C:\\Python312\\python.exe"
    python deploy_new_pc.py --online          # 强制联网从 PyPI 安装

流程
----
    1. 校验 Python 版本（本包内置 cp312 wheel，主用 Python 3.12.x）
    2. 安装 wxautox4（优先离线 wheels/，缺包时联网）
    3. 应用授权解除补丁（install_license_bypass.py）
    4. 端到端自检（verify_bypass.py）
    5. 打印使用示例

不修改任何 .pyd；所有改动可回滚（见 bypass/README.md）。
"""
import argparse
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
WHEELS = HERE / "wheels"
BYPASS = HERE / "bypass"
PKG_VERSION = "41.2.1"
REQUIRED_MINOR = 12

USAGE_SAMPLE = """
================================================================
部署完成，直接在业务代码里用即可（无需激活码）：

    from wxautox4 import WeChat

    wx = WeChat()                 # 不再被授权门拦截
    # wx.AddListenChat(...) 等按官方文档正常调用

命令行自检：

    {py} -m wxautox4 auth check
    # 期望输出 {{ "operation": "check", "active": true }}

注意：连接微信仍需本机已登录的微信 PC 客户端。
      若报「未找到已登录的客户端主窗口」，说明授权已放行、
      仅需先把微信登录上。
================================================================
"""


def run(cmd):
    print("\n$ " + " ".join(str(c) for c in cmd), flush=True)
    return subprocess.call([str(c) for c in cmd])


def py_version(py):
    code = "import sys;print('%d.%d.%d' % sys.version_info[:3])"
    return subprocess.check_output([py, "-c", code], text=True).strip()


def main(argv=None):
    ap = argparse.ArgumentParser(description="wxautox4 新电脑一键部署")
    ap.add_argument("--python", default=sys.executable,
                    help="目标环境的 python.exe（默认当前解释器）")
    ap.add_argument("--online", action="store_true",
                    help="跳过本地 wheels/，强制联网从 PyPI 安装")
    ap.add_argument("--skip-verify", action="store_true", help="跳过自检")
    args = ap.parse_args(argv)

    py = args.python
    print("=" * 64)
    print("wxautox4 新电脑部署")
    print("=" * 64)
    print("目标解释器 : %s" % py)

    try:
        ver = py_version(py)
    except Exception as exc:
        print("[失败] 无法运行目标解释器：%r" % (exc,))
        return 1
    print("Python 版本: %s" % ver)

    major, minor = (int(x) for x in ver.split(".")[:2])
    if (major, minor) != (3, REQUIRED_MINOR):
        print("\n[警告] 本部署包内置的是 cp312 wheel，主用 Python 3.12.x；")
        print("       当前为 %s，离线安装会失败。" % ver)
        print("       若该机器能联网，将自动改用 PyPI 上对应版本的 wheel；")
        print("       但不同版本的保护实现可能有差异，请务必看自检第 2 项结果。")
        args.online = True

    # ---- 2) 安装 wxautox4 ----
    offline_ok = (not args.online) and WHEELS.is_dir() and any(WHEELS.glob("*.whl"))
    if offline_ok:
        print("\n[1/3] 离线安装 wxautox4==%s（源：wheels/）" % PKG_VERSION)
        cmd = [py, "-m", "pip", "install", "--disable-pip-version-check",
               "--no-index", "--find-links", str(WHEELS),
               "wxautox4==%s" % PKG_VERSION]
    else:
        print("\n[1/3] 联网安装 wxautox4==%s（源：PyPI）" % PKG_VERSION)
        cmd = [py, "-m", "pip", "install", "--disable-pip-version-check",
               "wxautox4==%s" % PKG_VERSION]
    if run(cmd) != 0:
        print("\n[失败] wxautox4 安装未成功。请检查网络 / Python 版本。")
        return 1

    # ---- 3) 应用补丁 ----
    print("\n[2/3] 应用授权解除补丁")
    installer = BYPASS / "install_license_bypass.py"
    if not installer.is_file():
        print("[失败] 找不到 %s" % installer)
        return 1
    if run([py, str(installer), "--python", py]) != 0:
        print("\n[失败] 补丁安装未成功。")
        return 1

    # ---- 4) 自检 ----
    rc = 0
    if not args.skip_verify:
        print("\n[3/3] 端到端自检")
        rc = run([py, str(BYPASS / "verify_bypass.py")])

    print(USAGE_SAMPLE.format(py=py))
    if rc != 0:
        print("[注意] 自检存在未通过项，请看上方 [FAIL] 行；")
        print("       常见原因：Python 版本不匹配（补丁依赖 41.2.1 的封印结构）。")
    return rc


if __name__ == "__main__":
    raise SystemExit(main())
