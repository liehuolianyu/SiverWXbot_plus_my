# -*- coding: utf-8 -*-
"""wxautox4 运行时授权解除（seal 还原方案）

逆向结论（详见 ../wxautox4_activation_analysis.md）
--------------------------------------------------
`wxautox4.ui.main` 在被导入时会执行 `_seal_wechat_main_init()`，把
`WeChatMainWnd.__init__` 整体替换为一个闭包 `guarded_init`：

    def guarded_init(self, *args, **kwargs):
        if not license_check():          # license_check 即编译内部的 _cnka
            print(">>> 未授权设备，获取授权：https://wxauto.org")
            raise SystemExit(1)
        return original_init(self, *args, **kwargs)

`guarded_init` 的闭包里同时保存了两样东西：
    license_check -> _cnka                    授权判定函数
    original_init -> WeChatMainWnd.__init__   未加锁的原始初始化函数

也就是说，**原始实现被原封不动地留在了闭包里**。把类属性还原成
`original_init`，运行时授权门即被彻底移除。

还原之后，原始 `__init__` 自身还有一道很弱的目录检查：
遍历 `%USERPROFILE%\\.wxautox\\`，只要存在一个**以 "hw" 开头**的条目
即视为已授权设备（否则同样 print + SystemExit）。所以本模块同时保证
该目录下存在这样一个标记文件。

用法
----
    import wxautox4_unseal
    wxautox4_unseal.install()

    import wxautox4
    wx = wxautox4.WeChat()      # 不再因授权被 SystemExit 拦截

也可通过 `install_lazy()` 注册导入钩子，在 `wxautox4.ui.main` 加载完成后
自动生效（供 sitecustomize / .pth 使用）。
"""
import os
import sys
from pathlib import Path

__all__ = [
    "MARKER_PREFIX",
    "unseal",
    "ensure_marker",
    "patch_license_api",
    "install",
    "uninstall_marker_hint",
    "install_lazy",
    "status",
]

#: 原始 __init__ 只检查条目标名前缀
MARKER_PREFIX = "hw"
#: 我们写入的标记文件名（与真实授权生成的 hw* 同名规则一致）
MARKER_NAME = "hw" + "0" * 16

_ORIGINAL_INIT_BACKUP = None
_MARKER_CREATED = None


# --------------------------------------------------------------------------
# 1. seal 还原
# --------------------------------------------------------------------------
def _find_original_init(cls):
    """从 guarded_init 的闭包中取出 original_init。"""
    f = cls.__init__
    code = getattr(f, "__code__", None)
    if code is None:
        return None, "no-code"
    freevars = getattr(code, "co_freevars", ()) or ()
    if "original_init" not in freevars:
        return None, "not-sealed"
    for name, cell in zip(freevars, f.__closure__ or ()):
        if name == "original_init":
            try:
                return cell.cell_contents, "ok"
            except ValueError:
                return None, "empty-cell"
    return None, "cell-missing"


def unseal(cls=None):
    """把 WeChatMainWnd.__init__ 还原为未加锁的原始实现。

    Returns
    -------
    bool
        True 表示当前状态为「未加锁」（含本来就未被封印的情况）。
    """
    global _ORIGINAL_INIT_BACKUP

    if cls is None:
        try:
            import wxautox4.ui.main as _main
        except Exception:
            return False
        cls = getattr(_main, "WeChatMainWnd", None)
        if cls is None:
            return False

    original, why = _find_original_init(cls)
    if original is None:
        # not-sealed 说明已经被还原过（或该版本本来就没有封印）
        return why == "not-sealed"

    _ORIGINAL_INIT_BACKUP = cls.__init__
    cls.__init__ = original
    return True


def reseal(cls=None):
    """恢复被封印的 __init__（仅用于自测/回滚）。"""
    global _ORIGINAL_INIT_BACKUP
    if _ORIGINAL_INIT_BACKUP is None:
        return False
    if cls is None:
        try:
            import wxautox4.ui.main as _main
        except Exception:
            return False
        cls = getattr(_main, "WeChatMainWnd", None)
        if cls is None:
            return False
    cls.__init__ = _ORIGINAL_INIT_BACKUP
    _ORIGINAL_INIT_BACKUP = None
    return True


# --------------------------------------------------------------------------
# 2. 设备标记文件
# --------------------------------------------------------------------------
def ensure_marker(directory=None):
    """确保 `~/.wxautox/` 下存在一个以 MARKER_PREFIX 开头的标记文件。"""
    global _MARKER_CREATED
    try:
        d = Path(directory) if directory else (Path.home() / ".wxautox")
        d.mkdir(parents=True, exist_ok=True)
        for entry in d.iterdir():
            if entry.name.startswith(MARKER_PREFIX):
                return True
        marker = d / MARKER_NAME
        marker.write_text("1", encoding="utf-8")
        try:
            os.chmod(marker, 0o600)
        except OSError:
            pass
        _MARKER_CREATED = str(marker)
        return True
    except Exception:
        return False


def uninstall_marker_hint():
    """返回本模块可能创建的标记文件路径，便于用户自行清理。"""
    return _MARKER_CREATED or str(Path.home() / ".wxautox" / MARKER_NAME)


# --------------------------------------------------------------------------
# 3. 授权状态 API 对齐（纯 UX：让 `wxautox4 auth check` 报告为已授权）
# --------------------------------------------------------------------------
_LICENSE_PATCHED = False


def patch_license_api():
    """把 `useful.check_license()` 固定返回 True。

    仅影响「查询授权状态」这类只读接口（CLI 的 `auth check`、外部自检）。
    真正的运行时授权门（WeChatMainWnd.__init__）已由 `unseal()` 处理，
    二者互不依赖。
    """
    global _LICENSE_PATCHED
    if _LICENSE_PATCHED:
        return True
    try:
        import wxautox4.utils.useful as useful
    except Exception:
        return False
    if getattr(useful, "_wxautox4_unseal_license", False):
        _LICENSE_PATCHED = True
        return True
    try:
        useful.check_license = lambda *a, **k: True
        useful._wxautox4_unseal_license = True
    except Exception:
        return False
    # 同步已导入子模块的同名绑定
    for modname, mod in list(sys.modules.items()):
        if not modname.startswith("wxautox4"):
            continue
        if getattr(mod, "check_license", None) is not None:
            try:
                mod.check_license = useful.check_license
            except Exception:
                pass
    _LICENSE_PATCHED = True
    return True


# --------------------------------------------------------------------------
# 4. 组合入口
# --------------------------------------------------------------------------
def install(cls=None, create_marker=True, patch_api=True):
    """一次性完成：标记文件 + seal 还原 (+ 授权状态 API 对齐)。

    Returns
    -------
    dict
        执行结果摘要。
    """
    result = {"marker": None, "unsealed": None, "license_api": None}
    if create_marker:
        result["marker"] = ensure_marker()
    result["unsealed"] = unseal(cls)
    if patch_api:
        try:
            result["license_api"] = patch_license_api()
        except Exception:
            result["license_api"] = False
    return result


def status(cls=None):
    """返回当前补丁状态，便于自检。"""
    if cls is None:
        try:
            import wxautox4.ui.main as _main
        except Exception as exc:
            return {"imported": False, "error": repr(exc)}
        cls = getattr(_main, "WeChatMainWnd", None)
    marker_dir = Path.home() / ".wxautox"
    markers = []
    if marker_dir.exists():
        try:
            markers = [e.name for e in marker_dir.iterdir()
                       if e.name.startswith(MARKER_PREFIX)]
        except Exception:
            markers = []
    return {
        "imported": cls is not None,
        "sealed": _find_original_init(cls)[1] != "not-sealed" if cls else None,
        "markers": markers,
    }


# --------------------------------------------------------------------------
# 5. 惰性导入钩子（供 sitecustomize / .pth 使用，零启动开销）
# --------------------------------------------------------------------------
_TARGETS = {
    # 载入完成后：还原 seal（真正放行 WeChat 构造）
    "wxautox4.ui.main": lambda: install(),
    # 载入完成后：让 auth check 之类的只读查询也报已授权
    "wxautox4.utils.useful": lambda: (ensure_marker(), patch_license_api()),
}


def install_lazy():
    """注册一个 meta_path 钩子，在相关模块载入完成后自动补丁。

    对不使用 wxautox4 的 Python 进程不产生任何副作用或开销。
    """
    import importlib.abc

    # 已经加载过的目标：就地补上
    for name in list(_TARGETS):
        if name in sys.modules:
            try:
                _TARGETS[name]()
            except Exception:
                pass

    class _Loader(importlib.abc.Loader):
        def __init__(self, inner, action):
            self._inner = inner
            self._action = action

        def create_module(self, spec):
            fn = getattr(self._inner, "create_module", None)
            return fn(spec) if fn else None

        def exec_module(self, module):
            self._inner.exec_module(module)
            try:
                self._action()
            except Exception:
                pass

    class _Finder(importlib.abc.MetaPathFinder):
        def find_spec(self, fullname, path=None, target=None):
            action = _TARGETS.get(fullname)
            if action is None:
                return None
            for finder in list(sys.meta_path):
                if finder is self:
                    continue
                find = getattr(finder, "find_spec", None)
                if find is None:
                    continue
                try:
                    spec = find(fullname, path, target)
                except Exception:
                    continue
                if spec is not None and spec.loader is not None \
                        and not isinstance(spec.loader, _Loader):
                    spec.loader = _Loader(spec.loader, action)
                    return spec
            return None

    for f in sys.meta_path:
        if isinstance(f, _Finder):
            return True
    sys.meta_path.insert(0, _Finder())
    return True
