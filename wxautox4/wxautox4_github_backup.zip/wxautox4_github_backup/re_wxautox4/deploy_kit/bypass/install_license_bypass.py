# -*- coding: utf-8 -*-
"""wxautox4 授权解除 —— 一键安装器

把 `wxautox4_unseal.py` 放进目标环境的 site-packages，并在
`wxautox4/ui/__init__.py` 末尾追加一段 bootstrap，使该环境下**任何**
导入 wxautox4 的脚本自动解除授权门（无需改业务代码）。

用法
----
    # 自动探测当前解释器
    python install_license_bypass.py

    # 指定解释器
    python install_license_bypass.py --python "C:\\Program Files\\Python312\\python.exe"

    # 直接指定 site-packages 目录
    python install_license_bypass.py --site-packages "C:\\path\\to\\site-packages"

    # 撤销（移除 bootstrap，保留已存在的 hw* 标记）
    python install_license_bypass.py --uninstall
"""
import argparse
import os
import shutil
import site
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
SHIM_NAME = "wxautox4_unseal.py"
SENTINEL_BEGIN = "# --- wxautox4 license bypass bootstrap (auto-appended) ---"
SENTINEL_END = "# --- end wxautox4 license bypass bootstrap ---"

BOOTSTRAP = """
{begin}
try:
    from wxautox4_unseal import install as _wxautox4_unseal_install
    _wxautox4_unseal_install()
except Exception:
    pass
{end}
""".format(begin=SENTINEL_BEGIN, end=SENTINEL_END)


def resolve_site_packages(python_exe=None, explicit=None):
    if explicit:
        return Path(explicit).resolve()

    if python_exe:
        code = ("import site,sys;"
                "c=[p for p in site.getsitepackages() if p.endswith('site-packages')];"
                "print(c[0] if c else site.getusersitepackages())")
        out = subprocess.check_output([python_exe, "-c", code], text=True)
        return Path(out.strip()).resolve()

    candidates = [p for p in site.getsitepackages() if p.endswith("site-packages")]
    if not candidates:
        candidates = [site.getusersitepackages()]
    return Path(candidates[0]).resolve()


def find_target_init_files(sp_dir: Path):
    """返回需要注入 bootstrap 的包初始化文件。

    - `ui/__init__.py`  : 任何 `wxautox4.ui*` 导入都会先执行它（含 WeChat 构造路径）
    - `cli/__init__.py` : `python -m wxautox4` / `wxautox4` 命令行走这里
    """
    base = sp_dir / "wxautox4"
    out = []
    for rel in (Path("ui") / "__init__.py", Path("cli") / "__init__.py"):
        p = base / rel
        if p.is_file():
            out.append(p)
    return out


def install(sp_dir: Path, create_marker=True):
    report = {"site_packages": str(sp_dir), "shim": None, "bootstrap": [],
              "marker": None, "ok": False}

    targets = find_target_init_files(sp_dir)
    if not targets:
        report["error"] = "未在 %s 找到 wxautox4 包" % sp_dir
        return report

    # 1) 放置补丁模块
    dst = sp_dir / SHIM_NAME
    shutil.copy2(HERE / SHIM_NAME, dst)
    report["shim"] = str(dst)

    # 2) 注入 bootstrap（幂等）
    for path in targets:
        label = "%s/%s" % (path.parent.parent.name, path.parent.name)
        text = path.read_text(encoding="utf-8")
        if SENTINEL_BEGIN in text:
            report["bootstrap"].append("%s: already" % label)
            continue
        if not text.endswith("\n"):
            text += "\n"
        path.write_text(text + BOOTSTRAP, encoding="utf-8")
        report["bootstrap"].append("%s: appended" % label)

    # 3) 设备标记文件
    if create_marker:
        code = ("import sys;sys.path.insert(0,%r);"
                "import wxautox4_unseal as m;print(m.ensure_marker())" % str(sp_dir))
        try:
            out = subprocess.check_output([sys.executable, "-c", code], text=True).strip()
            report["marker"] = (out == "True")
        except Exception as exc:
            report["marker"] = "error: %r" % (exc,)

    report["ok"] = True
    return report


def uninstall(sp_dir: Path, remove_shim=True):
    report = {"site_packages": str(sp_dir), "bootstrap": [], "shim": None}
    targets = find_target_init_files(sp_dir)
    if not targets:
        report["error"] = "未找到 wxautox4 包"
        return report

    for path in targets:
        label = "%s/%s" % (path.parent.parent.name, path.parent.name)
        text = path.read_text(encoding="utf-8")
        if SENTINEL_BEGIN in text:
            head, _, rest = text.partition(SENTINEL_BEGIN)
            _, _, tail = rest.partition(SENTINEL_END)
            path.write_text(head + tail.lstrip("\n"), encoding="utf-8")
            report["bootstrap"].append("%s: removed" % label)
        else:
            report["bootstrap"].append("%s: not-present" % label)

    if remove_shim:
        dst = sp_dir / SHIM_NAME
        if dst.is_file():
            dst.unlink()
            report["shim"] = "removed"
        else:
            report["shim"] = "not-present"

    report["ok"] = True
    return report


def main(argv=None):
    ap = argparse.ArgumentParser(description="wxautox4 授权解除安装器")
    ap.add_argument("--python", help="目标环境的 python.exe（自动解析其 site-packages）")
    ap.add_argument("--site-packages", help="直接指定 site-packages 目录")
    ap.add_argument("--no-marker", action="store_true", help="不创建 hw* 设备标记文件")
    ap.add_argument("--uninstall", action="store_true", help="撤销注入")
    args = ap.parse_args(argv)

    sp = resolve_site_packages(args.python, args.site_packages)
    print("target site-packages:", sp)

    report = uninstall(sp) if args.uninstall else install(sp, not args.no_marker)
    for k, v in report.items():
        if isinstance(v, list):
            print("  %-16s" % k)
            for item in v:
                print("      - %s" % item)
        else:
            print("  %-16s %s" % (k, v))
    return 0 if report.get("ok") else 1


if __name__ == "__main__":
    raise SystemExit(main())
