# -*- coding: utf-8 -*-
import sys, os, traceback
import wxautox4.utils.useful as U
class Marker(Exception): pass
def mk(nm):
    def w(*a,**k):
        print("[HIT]", nm, "args=", a[:2])
        raise Marker("reached "+nm)
    return w
for nm in ("chlc","check_license","authenticate_with_file","authenticate_with_file2","offline_auth","ghi","get_licence_file","debug_license","unregister_license"):
    if hasattr(U,nm):
        setattr(U,nm,mk(nm))
try:
    from wxautox4.wx import WeChat
    WeChat(nickname="__p__")
    print("RESULT: OK")
except Marker as e:
    print("MARKER HIT:", e)
except BaseException as e:
    print("RESULT:", type(e).__name__, "|", str(e)[:150])
