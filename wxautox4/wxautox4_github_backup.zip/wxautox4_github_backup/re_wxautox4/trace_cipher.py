# -*- coding: utf-8 -*-
"""Wrap every obfuscated module-level helper of wxautox4.utils.useful and
record the exact call graph + inputs/outputs during activation."""
import base64
import binascii
import builtins
import functools
import hashlib
import io
import json
import os
import random
import sys
import time
import datetime
import traceback

LOG = []
MAXV = 700


def s(x):
    try:
        if isinstance(x, (bytes, bytearray)):
            return "B:" + bytes(x).hex()
        return repr(x)
    except BaseException:
        return "<unrep>"


def rec(k, d):
    LOG.append({"t": k, "d": d})
    print("[%s] %s" % (k, json.dumps(d, ensure_ascii=False, default=str)[:MAXV]))


# ---- wrap random/time/entropy ----
def wrap_entropy():
    for mod, names in ((random, ("random", "randint", "randrange", "choice", "choices",
                                 "randbytes", "shuffle", "sample", "getrandbits", "seed")),
                       (os, ("urandom", "getpid")),
                       (time, ("time", "time_ns")),
                       (base64, ("b64encode", "b64decode", "urlsafe_b64encode")),
                       (binascii, ("hexlify", "unhexlify"))):
        for n in names:
            if not hasattr(mod, n):
                continue
            orig = getattr(mod, n)

            def mk(orig, n):
                @functools.wraps(orig)
                def w(*a, **k):
                    r = orig(*a, **k)
                    rec("ENTROPY", {"mod": orig.__module__, "fn": n,
                                    "args": [s(x) for x in a], "ret": s(r)[:200]})
                    return r
                return w
            setattr(mod, n, mk(orig, n))


# ---- wrap hashlib new-any ----
def wrap_hash():
    _new = hashlib.new

    def neww(name, data=b"", **k):
        h = _new(name, data, **k)
        chunks = [bytes(data) if data else b""]
        real = h.update

        def update(d):
            chunks.append(bytes(d))
            return real(d)
        h.update = update
        real_hex = h.hexdigest

        def hexd():
            out = real_hex()
            rec("HASH", {"algo": name, "input": s(b"".join(chunks))[:500], "out": out})
            return out
        h.hexdigest = hexd
        return h
    hashlib.new = neww


# ---- wrap module functions ----
CANDIDATES = ["fa", "fp", "pp", "pu", "wp", "wa", "na", "nc", "its", "sti",
              "iacve", "inlec", "nkecl", "nkecl2", "nismce", "kbjd", "jnice",
              "tole", "ghi", "ghi_legacy", "vces", "cea",
              "chlc", "check_license", "authenticate", "authenticate_with_file",
              "authenticate_with_file2", "get_licence_file", "generate_keypair",
              "gcd", "mod_inverse", "miller_rabin", "generate_prime"]


def wrap_module(u):
    depth = {"n": 0}
    for name in CANDIDATES:
        fn = getattr(u, name, None)
        if not callable(fn):
            continue

        def mk(fn, name):
            @functools.wraps(fn)
            def w(*a, **k):
                ind = "  " * depth["n"]
                rec("CALL", {"ind": ind, "fn": name,
                             "args": [s(x) for x in a], "kwargs": {kk: s(vv) for kk, vv in k.items()}})
                depth["n"] += 1
                try:
                    r = fn(*a, **k)
                except BaseException as e:
                    depth["n"] -= 1
                    rec("RETERR", {"ind": ind, "fn": name, "err": "%s: %s" % (type(e).__name__, e)})
                    raise
                depth["n"] -= 1
                rec("RET", {"ind": ind, "fn": name, "ret": s(r)[:400]})
                return r
            return w
        try:
            setattr(u, name, mk(fn, name))
        except BaseException as e:
            print("cannot wrap", name, e)


def main():
    wrap_entropy()
    wrap_hash()
    import wxautox4.utils.useful as u
    wrap_module(u)
    print("### wrapped. calling authenticate(dummy)")
    try:
        r = u.authenticate("TEST-DUMMY-CODE")
        rec("TOP", {"fn": "authenticate", "ret": s(r)})
    except BaseException as e:
        rec("TOP", {"fn": "authenticate", "err": "%s: %s" % (type(e).__name__, e),
                    "tb": traceback.format_exc()[-1500:]})
    out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "artifacts", "cipher_trace.json")
    with io.open(out, "w", encoding="utf-8") as f:
        json.dump(LOG, f, ensure_ascii=False, indent=1, default=str)
    print("### events:", len(LOG))


if __name__ == "__main__":
    main()
