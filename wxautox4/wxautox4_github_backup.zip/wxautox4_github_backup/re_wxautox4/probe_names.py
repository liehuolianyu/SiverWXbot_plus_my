# -*- coding: utf-8 -*-
import importlib, pkgutil, sys
import wxautox4
mods = ["wxautox4", "wxautox4.utils.useful", "wxautox4.ui.main", "wxautox4.cli.main", "wxautox4.wx"]
PAT = ("lic","auth","activ","expire","valid","chlc","chk","verify","nka")
for name in mods:
    try:
        m = importlib.import_module(name)
    except BaseException as e:
        print("[SKIP]", name, type(e).__name__, e); continue
    hits = []
    for n in dir(m):
        if any(p in n.lower() for p in PAT):
            hits.append(n)
    print("==", name, "->", hits)
