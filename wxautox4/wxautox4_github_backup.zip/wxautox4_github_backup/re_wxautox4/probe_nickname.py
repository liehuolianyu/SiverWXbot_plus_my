# -*- coding: utf-8 -*-
"""尝试从界面读取自己的微信昵称：点左下角头像 -> 枚举新出现的文本"""
import ctypes
import ctypes.wintypes as wt
import importlib.util
import os
import sys
import time

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

HERE = r"C:\Users\Administrator\WorkBuddy\2026-10-14-16-19-40\re_wxautox4"
spec = importlib.util.spec_from_file_location(
    "wx_uia_wake", os.path.join(HERE, "wake_ref", "wechat_uia_wake.py"))
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
from wxautox4.uia import uiautomation as auto  # noqa: E402
mod._uia = lambda: auto

out = mod.wake()
print("wake:", out.get("ok"), out.get("action"))

u = ctypes.windll.user32
u.GetClassNameW.argtypes = [wt.HWND, wt.LPWSTR, ctypes.c_int]
u.GetWindowTextW.argtypes = [wt.HWND, wt.LPWSTR, ctypes.c_int]
CB = ctypes.WINFUNCTYPE(ctypes.c_bool, wt.HWND, wt.LPARAM)
st = {"h": 0}


def cb(h, l):
    b = ctypes.create_unicode_buffer(128)
    u.GetClassNameW(h, b, 128)
    if b.value == "Qt51514QWindowIcon":
        t = ctypes.create_unicode_buffer(128)
        u.GetWindowTextW(h, t, 128)
        if t.value == "微信":
            st["h"] = h
            return False
    return True


u.EnumWindows(CB(cb), 0)
hwnd = st["h"]
r = wt.RECT()
u.GetWindowRect(hwnd, ctypes.byref(r))
print("窗口 rect=(%d,%d)-(%d,%d)" % (r.left, r.top, r.right, r.bottom))
w, h = r.right - r.left, r.bottom - r.top


def dump_text(tag):
    ctl = auto.ControlFromHandle(hwnd)
    texts = []

    def walk(c, d):
        if d > 12:
            return
        try:
            kids = c.GetChildren()
        except Exception:
            return
        for k in kids:
            try:
                nm = (k.Name or "").strip()
                cls = k.ClassName or ""
            except Exception:
                continue
            if nm and len(nm) < 40:
                texts.append((cls, nm))
            walk(k, d + 1)

    walk(ctl, 0)
    print("\n[%s] 有文本的元素 (%d):" % (tag, len(texts)))
    for cls, nm in texts[:60]:
        print("    %-34s %r" % (cls, nm))


dump_text("点击前")

# 点左下角头像区域
x, y = r.left + 32, r.bottom - 70
print("\n点击坐标 (%d, %d) ..." % (x, y))
auto.Click(x, y)
time.sleep(2.0)
dump_text("点击后")

# 再点一次（可能是弹出菜单）
auto.Click(x, y - 30)
time.sleep(1.5)
dump_text("再点击后")
