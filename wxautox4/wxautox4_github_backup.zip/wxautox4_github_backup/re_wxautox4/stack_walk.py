# -*- coding: utf-8 -*-
import sys, pathlib, io, json
OUT=[]
_oe = pathlib.Path.exists
def fake(self):
    p=str(self)
    if "_wxautox" in p or ".wxautox" in p:
        f=sys._getframe(1); depth=0
        while f is not None and depth<14:
            g=f.f_globals; cn=f.f_code.co_name
            mod=g.get("__name__")
            fnobj=g.get(cn)
            OUT.append({
                "depth":depth,"mod":mod,"fn":cn,"line":f.f_lineno,
                "fnobj": (("%s.%s"%(getattr(fnobj,"__module__",""),getattr(fnobj,"__qualname__",""))) if callable(fnobj) else None),
                "file": (f.f_code.co_filename or "").split("site-packages")[-1],
            })
            f=f.f_back; depth+=1
    return _oe(self)
pathlib.Path.exists=fake
try:
    from wxautox4.wx import WeChat
    WeChat(nickname="__p__")
except BaseException as e:
    pass
print(json.dumps(OUT, ensure_ascii=False, indent=1)[:4000])
json.dump(OUT, io.open("artifacts/stack_walk.json","w",encoding="utf-8"), ensure_ascii=False, indent=1)
