# -*- coding: utf-8 -*-
import wxautox4.utils.useful as U
print("=== its(i) for i=0..79 ===")
tbl={}
for i in range(0,80):
    try:
        s=U.its(i); tbl[i]=s
    except BaseException as e:
        tbl[i]="ERR:%s"%type(e).__name__
for i in range(0,80):
    print("  %3d -> %r" % (i, tbl[i]))
print()
print("=== its 长度规律 (i=64,4095,4096,65535,65536) ===")
for i in (64,4095,4096,65535,65536,16777215,16777216):
    try: print("  ",i,"->",repr(U.its(i)))
    except BaseException as e: print("  ",i,"ERR",e)
