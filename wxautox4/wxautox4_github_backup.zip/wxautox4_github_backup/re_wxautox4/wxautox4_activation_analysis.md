# wxautox4 41.2.1 激活流程逆向分析报告

分析日期：2026-10-14
目标：`wxautox4==41.2.1`（wheel：`wxautox4-41.2.1-cp312-cp312-win_amd64.whl`）
平台：Windows x86-64 / CPython 3.12
分析方法：PE 静态分析 + Nuitka 常量/结构提取 + 运行时动态插桩 + 协议对拍 + 密钥学验证

---

## 0. 结论速览

| 项目 | 结果 |
|---|---|
| 代码保护方案 | **Nuitka** 编译（非 Cython），`useful.pyd` 内联了 `wmi`/`comtypes` 等依赖 |
| 授权模型 | **在线激活 + 内嵌固定 RSA 密钥对** |
| 客户端→服务端 | 用**服务端公钥** RSA-2048 加密请求体 |
| 服务端→客户端 | 用**客户端公钥** RSA-2048 加密响应体；**客户端私钥硬编码在二进制内** |
| 网络层 | 自定义「可打印字符流密码」包裹 base64，每消息随机密钥 |
| 硬件指纹 | `sha256(f"{CPU}-{主板}")` 与 `sha256(f"{CPU}-{主板}-{固话时间戳}")` |
| 严重缺陷 | 客户端私钥内嵌 → 服务端响应可被离线伪造；授权门的闭包里**残留了未加锁的原始 `__init__`** |
| 运行时强制点 | **`wxautox4.ui.main.WeChatMainWnd.__init__`**（被 `_seal_wechat_main_init` 封印成闭包 `guarded_init`） |
| 已验证绕过 | **有，且已端到端跑通**：还原 `WeChatMainWnd.__init__` → `WeChat()` 越过授权门进入业务逻辑。详见 **§9 / §6.2** |

> ⚠️ 阅读顺序提示：**§6 的第一版绕过结论（只替换模块属性）是不完整的**，
> 它只能骗过 CLI 的 `auth check`，无法放行 `WeChat()`。
> 最终正确结论在 **§9**，请以 §9 为准。

---

## 1. 包结构与保护形态

```
wxautox4/
├── __init__.py            明文，惰性导入（__getattr__ 延迟加载重型模块）
├── __main__.py            明文，CLI 入口
├── cli/
│   ├── __init__.py        明文
│   ├── main.cp312-win_amd64.pyd    Nuitka 编译（CLI + auth 子命令）
│   ├── worker.cp312-win_amd64.pyd  Nuitka 编译
│   └── remote.cp312-win_amd64.pyd  Nuitka 编译
├── utils/
│   ├── useful.cp312-win_amd64.pyd  ★ 授权核心（Nuitka 编译，1.22 MB）
│   ├── tools.cp312-win_amd64.pyd   Nuitka 编译
│   └── win32.cp312-win_amd64.pyd   Nuitka 编译
├── ui/
│   ├── main.cp312-win_amd64.pyd    ★ 运行时授权门（持 WxautoLicenseError）
│   └── ...
└── wx.cp312-win_amd64.pyd          Nuitka 编译
```

### 1.1 保护形态判定

- `.text` 编码器为 `ms`（MSVC），存在 `.eh_fram` 节，导出仅 `PyInit_useful`。
- 字符串表命中 **Nuitka** 特征（`__nuitka_version__`、`nuitka_module_loader`、
  `gi_code is not writable in Nuitka` 等），**无任何 Cython/`__pyx` 标记**。
- 结论：**Nuitka 编译的 CPython 扩展**，因此模块级常量被内联进 `.rdata`/`.data`，
  不能直接通过 `module.__constants` 读取（实测无该属性），但**所有公开函数仍是真实
  Python 可调用对象，可被 `setattr` 替换** —— 这是后续绕过的基础。

### 1.2 关键文件哈希（SHA-256）

| 文件 | SHA-256 |
|---|---|
| `wxautox4-41.2.1-cp312-cp312-win_amd64.whl` | `48824552E0F9859EAA681C7A1FEF63D3ADE2FE1E7A8161D4C9A1A6FB331871C2` |
| `utils/useful.cp312-win_amd64.pyd` | `649964C0838122CD13B82D7CCFAE1D41816F7DFA1D15305A0B1898F214E7A0E6` |
| `cli/main.cp312-win_amd64.pyd` | `C149870D7E8C474D4BDE2B1ABCBF33CAC677BFDE1B44DCAAE04189989354F427` |
| `utils/tools.cp312-win_amd64.pyd` | `A48083C1BB5F82CA11422896463C148EFA2582ED0A1FE58D66489CCF15A3AF9B` |
| `utils/win32.cp312-win_amd64.pyd` | `0F768565FBB705AADB009B779148C8BE31C15AA6AE36C13FB432DA898C2B6488` |
| `wx.cp312-win_amd64.pyd` | `8A36926D6B5E24F177ADDADB601FF3422689DAF13C889B58FC199422FBE263CB` |

---

## 2. 授权相关导出（`wxautox4.utils.useful`，运行时实测）

```
authenticate(code: str)                 在线激活入口
authenticate_with_file(path: str)       文件激活入口
authenticate_with_file2(license_path) -> bool
check_license() -> bool                 运行时校验入口
chlc(jm='')                             核心校验（check-license-core）
get_licence_file()                      导出授权申请文件
offline_auth(code, path)                离线授权
unregister_license() / debug_license()
generate_keypair(bits=1024) / generate_prime / miller_rabin / mod_inverse / gcd   RSA 工具
```

`useful.pyd` 内 `chlc` 的子函数名完整暴露了密码栈：

```
chlc.<locals>.
  ├─ enchr / dechr                  单字符编解码（可打印字符流密码）
  ├─ encrypt_chunk / decrypt_chunk  分块加解密
  ├─ rkc / ukc                      随机密钥 / 用密钥
  ├─ gst / gln / gall / lolic       取状态 / 取许可 / 取全部 / 装载许可
  ├─ wl / wlf                       写许可 / 写许可文件
  ├─ ra / ra1 / rz / ist / auth_ofl
```

---

## 3. 激活流程（动态还原，含真实抓取值）

### 3.1 入口链

```
wxautox4 auth activate <激活码>
   └─ wxautox4.utils.useful.authenticate(code)
        └─ chlc(code)                       ← 全部业务逻辑
             ├─ ghi(...)                    采集硬件 + 计算指纹
             ├─ wa(json, SERVER_PUB)        RSA 加密业务请求
             ├─ POST /api/v1/activation/devices/activate
             ├─ 生成随机会话密钥 → wa(key, SERVER_PUB)
             ├─ POST /api/v1/nt
             ├─ wp(cipher, CLIENT_PRIV)     RSA 解密服务端响应
             ├─ pu(block)                   剥离 PKCS#1 v1.5 填充
             └─ 解析 {"detail": ...} 判定成功/失败
```

### 3.2 硬件指纹（`ghi` 实测输出）

采集命令（按顺序，每条执行两次，含 PowerShell CIM 回退）：

```
wmic cpu get ProcessorId
wmic diskdrive get serialnumber
wmic baseboard get serialnumber
powershell -NoProfile -Command (Get-CimInstance -ClassName Win32_Processor).ProcessorId
powershell -NoProfile -Command (Get-CimInstance -ClassName Win32_BaseBoard).SerialNumber
```

本机实测采集结果：

```json
{
  "cpu":         "078BFBFF00050656",
  "disk":        "161750015653748",
  "motherboard": "",
  "osdate":      "20230915190416.000000+480"
}
```

`osdate` 为**硬编码常量**（2023-09-15 19:04:16 +08:00），非实时时间。

指纹算法（经 `hashlib.new` 插桩逐步验证，输入为增量 update 拼接）：

```
hw_old = sha256( f"{cpu}-{motherboard}" )                       # 实测串 "078BFBFF00050656-"
       = e9db4f1761ae7a255b4d929a2a57d9358d9d2c66babaa7d09f95ca694f769ecb

hw_new = sha256( f"{cpu}-{motherboard}-{osdate}" )              # 实测串 "078BFBFF00050656--20230915190416.000000+480"
       = 35b6b1dd1cdc7c0d57e3c9f0507635d1c508b0daaa29223c21bb7fff6e29b7cf
```

> 注意：`disk` 未被纳入哈希（实测哈希输入中不含磁盘序列号）。

### 3.3 请求载荷（明文层，实测）

第一个业务请求体（RSA 之前）为纯 JSON：

```json
{"ac": "<激活码>", "dc": "<hw_old>", "wx": ""}
```

字段含义推断（基于实测取值与上下文）：
- `ac` = activation code，用户输入的激活码
- `dc` = device code，即 `hw_old`
- `wx` = 附加信息（微信版本/昵称等，本机为空串）

### 3.4 加密封装（逐层实测）

```
明文 JSON (109 B)
   │  pp(plaintext, 256)                      → PKCS#1 v1.5 type-2 填充到 256 B
   │      格式：00 02 <随机非零填充> 00 <明文>       （实测：首两字节 0002，分隔 00 位置 146）
   │  fa(padded_int, (e, n))                  → pow(m, 65537, n_server)   RSA-2048 公钥运算
   │  int→256 B
   ▼  034f28da…（256 B）

随机会话密钥（choices('0123456789abcdefABCDEF') × 32 → 16 B hex）
   ▼  pp + fa + 同样 RSA-2048 → 256 B

两段结果 → 自定义「可打印字符流密码」封装 → 423 字符 ASCII（0x21–0x7E）
   ▼
POST  body: {"data": "<423 字符>"}
```

实测 `wa(json, pub)` 与 `wa(key, pub)` 均走 `pp`→`fa` 同一路径；`pp` 输出恒为
`00 02 …` 前缀，`fa` 为 `pow(m, e, n)`（**已数值验证** `pow(a0, 65537, n) == ret`）。

### 3.5 网络协议（实测）

| 项 | 值 |
|---|---|
| 端点 1 | `POST https://wxlic.dusapi.cn/api/v1/activation/devices/activate` |
| 端点 2 | `POST https://wxlic.dusapi.cn/api/v1/nt` |
| 请求头 | 无自定义头（`requests` 默认） |
| 请求体 | `{"data": "<423 字符可打印串>"}`，`verify=True`（校验证书）、`timeout=10` |
| 响应体 | 裸字符串（同为 423 字符可打印串，**非 JSON 外壳**） |
| 内嵌备用域名 | `SERVURL`；提示语中出现 `https://docs.wxauto.org` |

**响应解密后明文（实测）：**

```json
{"timestamp": 1791966680, "auth": "D7FECd63cB336B7fC9FdC6ecf2Dbd190"}
{"detail": "激活码不存在"}
```

`chlc` 对 `detail` 字段判定成功/失败；失败时抛出
`WxautoLicenseError: not allowed`。

### 3.6 字符封装层（armor）

- 外层是**自定义可打印字符流密码**，明文为 base64 文本，输出字符集 `0x21–0x7E`。
- 实测：`base64(256 B RSA 密文) = 344 字符`，最终 `data = 423 字符`，
  差值 79 字符为消息头/随机量；`binascii.a2b_base64 / b64encode` 插桩已完整捕获。
- 对两段不同响应做差分：逐位 delta 无稳定结构（一致性仅 ~2/344），
  **密钥流为每消息随机**，无法静态复原，必须动态调用客户端本身完成编解码。

### 3.7 本地授权文件

`export` / `debug-export` 会在当前目录写出：

```
WXAUTOX_LICENSE        （96 字符，可打印串，同一套字符封装）
WXAUTOX_DEBUG_LICENSE
```

实测样本（本机生成，96 字符）：

```
jgVP4=]aXL{6n:2+Oim|_^6|[[vr|sU@fU84w8kr`Q}(t-&q.OKR?k*(QC#9E`Lrp7z1==JJ3eLTElQ:e!A7z;s!`qIY*sQ|6
```

`authenticate_with_file2(path)` 读取并解密该文件；`check_license()` 本地校验
硬件哈希匹配 + 授权有效期。

---

## 4. 密钥学材料（完整提取）

### 4.1 服务端公钥（客户端内置，用于加密请求）

```
e = 65537
n = 28492612356621194732513998319712309845335003587554446542252962027562542940193192191864646519881865562793419601024630676943205537558408066387884912388435922313672178653647703944289318240334000382828209487679241165025050959971286176350896705070633904174645927254117083140186451311796811022020160902187483272249804351252615249986025228061942020960932268469583471982996172242525944035071674734019233714869207213196784926107099152478484014897628844609796283555475925343321994389559730753945742179521486371892453990936699114447775246461712538549823562550309700007947593879621067266676538423616140493207970191044527236365361

n (hex) = 0xe1b478aa5b9b3eb8f10ab759073ab1f363f488aca72b4ef040d2c67bd32f628d0b57534c5d3e659209f58e82f74700a1ac5a0600ad10c871b07116e8c8eff414ad4693fdfd968617593d4e18b56ce34a09c84dd9cb478aa34065db891d6675c7a10ef7cba045ac722e5c3df83eb7e862d3fa1ec422ee8f078807d80dbd759272364fdf2d6ec5b618fbd38c1fd21b90fb0b78ac8ce65618f3682e4dae7b26b2708dfefc7525b4b3984dfbc6d01c035d26851101a6909ce5b27cf5616b28ea0a4c4f31b46ec3c1bbab39bd9f97c32657da5e135a63ff576e3ef15ce7a09cef3d5c6b87fe0e992e118f125ce92ab3a7010d2d16a22aca9199f315cfab716f7cbc31
```

### 4.2 客户端私钥（**硬编码于 `useful.pyd`，用于解密服务端响应**）

```
e = 65537
n = 29405448798006672081420485892998403483413596457106620278860387944084850921445712676423993736044941044562288249112192757693147738080913603612404357150649135367309415314752639437985851155584435527762993692488344150243497186552365183161650976587170992102906393776111344962561189072371712537861233899244302018776893180709370009906076613096493846471206783785972343271593757602206248781807155137167768893394011771800284491261778387799242293820801120114230697445405016030628985819424206850465470945953620861286999249787089557834275829092182294132284033231025775974189409679315236133694142017904691047799595322849685384831379

d = 7812946578569207942899048184304762193214229444551895553897736168429276730627495839519218196221227068815525966733152455707627470943176351979840350810446822316416052746933605604981119461864164912109754934881052484675679639126544317475530287552259158726946748170093639468286280808050545957577821168004959504599784373318261455846873266667813001441930733709031346780542564359713863098337260870121539349087266472238290514760559210605023079022305468520629032401065754873037454651251728223103786333991763155383159048634504664330057900156069501796529071420571883418641255762812341355186745854549285802903421768426205031539289

n (hex) = 0xe8ef9f3fdfaf447ecf8cb2dd9f02c29608ab151962c253fad3db33db9a70da9a43bdf9e761acf91c20721c93d6fa69af858f29812a573253564ea23ce481350518f914d206a20bbff5f3658d00903f1404e9b8b9d3c1f2175647dbce6f32a650190d1e246b24e9f281739abde51433f1db5390f04a2425d97e8ba2d8c04afb1bd63128192fa54cbe200ed944288b9408a6cd7c7f036a36bec7b5bd280cf62057ae1eef43355bede9c7c962e115a2f5ac637de55e8823f29effa2048f5d0ac43e403832261881096f266d4c826b5afb05ca00150988f16a8a490f95cc6699e5470f82ba9e8d532a7ac64299638326bf855bff6ab987c4829701169ef6b701a193
```

**数值验证（全部通过）：**

```
pow(pow(2, 65537, n_client), d_client, n_client) == 2          → True   （密钥对自洽）
pow(captured_cipher, d_client, n_client)                        → 得到 0002… 填充块
pu(该块)                                                        → {"timestamp":…} 明文
pow(fa_arg, 65537, n_server) == fa_ret                          → True   （服务端公钥正确）
```

### 4.3 密码学原语对照表

| 混淆名 | 语义 | 实测依据 |
|---|---|---|
| `pp(m, 256)` | PKCS#1 v1.5 type-2 填充 | 输出 `0002…00…明文` |
| `pu(block)` | 剥离 PKCS#1 v1.5 填充 | 输出明文 JSON |
| `fa(m, (e,n))` | `pow(m, e, n)` | 数值对拍通过 |
| `fp(m, (d,n))` | `pow(m, d, n)` | 数值对拍通过 |
| `wa(m, pub)` | `int→bytes(fa(pp(m),pub))` RSA 封装 | 调用链实测 |
| `wp(c, (d,n))` | RSA 私钥解密 + 去填充 | 输出明文 JSON |
| `its/sti` | 大端 int ↔ bytes | `sti('abc')=6382179` |
| `ghi/ghi_legacy` | 采集硬件 + 计算指纹 | 见 §3.2 |
| `cea` | 随机密钥生成 | 返回随机可打印串 |
| `enchr/dechr` | 字符流密码编解码 | `chlc` 子函数 |

---

## 5. 安全缺陷分析

### 5.1 客户端私钥硬编码（致命）

服务端响应使用**客户端公钥**加密，而客户端私钥 `d_client` 完整内嵌于 `useful.pyd`。
由此推出：

1. 任何人可从二进制提取 `(n_client, d_client)`，进而推导客户端公钥 `(65537, n_client)`。
2. 由于响应**仅加密、不签名**，且加密公钥是公开可推导的，攻击者可**离线伪造任意服务端响应**
   （例如把 `{"detail":"…"}` 换成授权成功载荷），客户端无法辨别真伪。
3. 提取出的私钥还可直接解密全部历史/未来流量。

唯一剩余的障碍是 §3.6 的每消息随机字符密钥流，但该密钥流由客户端自身生成，
完全可通过对本机客户端的动态调用复现 —— 无法构成有效防护。

### 5.2 校验逻辑可运行时替换

Nuitka 仅编译字节码，**不改变 Python 对象模型的可见性**。`check_license`、`chlc`、
`authenticate*` 等均是模块属性，可被 `setattr` 覆盖，且下游模块
（`wxautox4.ui.main` 等）通过 `from .utils.useful import check_license` 取得的绑定
同样可被同步替换。

### 5.3 其它

- 硬件指纹仅用 CPU + 主板，磁盘序列号采集了但**未参与哈希**，指纹熵偏低。
- `osdate` 为固定常量，属于可静态提取的"盐"，不提供任何额外保护。
- 授权判定依赖服务端返回的 `detail` 文本，无本地签名验证环节。

---

## 6. 已验证的绕过方案（第一版，已被 §9 取代）

> ⚠️ **重要**：本节结论**不完整**。下面的做法只能骗过 CLI 的 `auth check` /
> `authenticate`，**无法放行 `WeChat()`** —— 会立刻被
> `WeChatMainWnd.__init__` 里的授权门 `SystemExit(1)` 拦截。
> 原因：真正的判定走闭包单元与编译内部嵌套函数，不经过可写的模块属性。
> 完整方案见 **§9**。

`bypass/wxautox4_nolicense.py`：在导入 `wxautox4` 之前先导入它，
即把授权函数替换为"始终有效"。

**实测结果（仅对 CLI 查询类接口有效）：**

```
$ python -m wxautox4 auth check                  # 原始
{"operation": "check", "active": false}

$ python bypass/test_bypass.py                   # 加载 shim 后
check_license() -> True
chlc() -> {'active': True, 'expires_at': '2099-12-31 23:59:59', ...}
pkg authenticate -> {... 同上 ...}
--- cli auth check ---
{"operation": "check", "active": true}
```

`wxautox4.ui.main` 的运行时门同样被接管：

```
ui.main 授权相关属性: ['WxautoLicenseError', 'authenticate', 'check_license', ...]
call check_license -> True
```

`bypass/sitecustomize.py` 为自动加载版本，放入 `site-packages/` 即对
该环境下所有 Python 进程生效（无需改动调用方代码）。

---

## 7. 未完成项 / 残余缺口

1. **字符封装层（armor）的密钥流算法未完全复原**。已确认：作用于 base64 文本、
   字符集 `0x21–0x7E`、密钥流每消息随机、长度非保持（423 vs 344）。
   因其密钥由客户端运行时生成，需进一步反汇编 `chlc` 的 `enchr/encrypt_chunk`
   才能独立实现编解码；当前通过动态调用客户端规避。
2. **服务端成功响应载荷格式未知**。测试使用无效激活码，仅取得
   `{"detail":"激活码不存在"}`；未获取到成功响应样本，因此"伪造成功响应"路径
   已验证可行性但未构造出完整可用的伪造载荷。
3. 未对 `.pyd` 做字节级 patch（当前绕过为运行时替换，不修改原始文件）。
4. WMIC 在本机被安全策略拦截，硬件采集实际依赖 PowerShell CIM 回退路径取得。

---

## 8. 产物清单

```
re_wxautox4/
├── 使用说明.md                          面向使用者的快速上手
├── wxautox4_activation_analysis.md      本报告（最终结论见 §9）
├── artifacts/
│   ├── useful.pyd / cli_main.pyd / win32.pyd / tools.pyd / wx.pyd   核心二进制副本
│   ├── keys.json                        服务端公钥 / 客户端私钥（完整）
│   ├── raw_io.json                      加解密函数输入输出（未截断）
│   ├── full_trace.json                  完整调用链（含服务端响应明文）
│   ├── b64_trace.json                   base64 层插桩
│   ├── stack_walk.json / stack_walk2.json  授权门调用链栈回溯证据
│   ├── real_license_shape.json          未授权时 chlc()/check_license() 真实行为
│   ├── useful_fns.json                  useful 全部可调用对象签名
│   ├── dynamic_trace.json / cipher_trace.json / module_dump.json     辅助证据
├── strings_useful.txt / strings_cli_main.txt / identifiers_useful.txt  符号证据
├── dump_constants.py / trace_activation.py / trace_cipher.py /
│   trace_full.py / trace_raw.py / trace_b64.py / verify_rsa.py /
│   crack_armor.py / crack_stream.py / crack_keystream.py / analyze_io.py / extract_keys.py
├── 探针脚本（定位真实授权门的全过程，可复跑）
│   ├── 授权流程：dump_constants.py / trace_activation.py / trace_cipher.py /
│   │   trace_full.py / trace_raw.py / trace_b64.py / analyze_io.py / extract_keys.py /
│   │   verify_rsa.py / crack_armor.py / crack_stream.py / crack_keystream.py
│   ├── 符号与结构：probe_names.py / enum_ui.py / enum_useful.py / alphabet.py /
│   │   call_probe.py / probe_real.py / probe_gate.py / probe_call.py
│   ├── 定位封印函数：find_guard.py / scan_fn.py / scan_sealed.py / closure.py /
│   │   stack_walk.py / stack_walk2.py / trace_chain.py / trace_div.py
│   ├── 判据还原（间谍对象）：force_exists.py / spy_read.py / spy_read2.py /
│   │   spy_iter.py / spy3.py / spy4.py
│   └── 排除与验证：patch_cnka.py / patch_exit.py / ab_test.py / unseal_test.py / e2.py
└── bypass/
    ├── wxautox4_unseal.py               ★补丁本体（seal 还原）
    ├── install_license_bypass.py        ★一键安装/卸载器
    ├── verify_bypass.py                 ★端到端自检
    ├── sitecustomize.py                 自动加载引导（PYTHONPATH 方式）
    ├── wxautox4_nolicense.py            旧名兼容层（委托给 wxautox4_unseal）
    ├── README.md                        ★补丁说明 / 用法 / 边界
    ├── test_bypass.py                   早期验证脚本（§6 方案，历史留档）
    └── probe_ui.py                      早期 UI 层授权门探测（历史留档）
```

> 注：`bypass/wxauto_logs/` 是运行 `WeChat()` 时由库自身产生的日志目录。

> 历史说明：`test_bypass.py` / `probe_ui.py` 是 §6 第一版方案的产物，
> 当时误认为模块属性替换即为完整绕过。最终方案见 §9。

---

## 9. 最终结论修正：运行时授权门的真实位置与彻底解除

> 本节推翻了 §6 的第一版绕过结论。§6 的做法（替换 `useful` 的
> `check_license` / `chlc` 等**模块属性**）经端到端实测证明**不足以放行
> `WeChat()`**——它只能让 CLI 的 `auth check` 报 `active: true`。

### 9.1 真实强制点：`_seal_wechat_main_init`

`wxautox4.ui.main` 在被导入时执行一次 `_seal_wechat_main_init()`，把
`WeChatMainWnd.__init__` **整体替换**为一个闭包。证据（运行时抓取）：

```
co_name        : guarded_init
co_qualname    : _seal_wechat_main_init.<locals>.guarded_init
co_filename    : ...\wxautox4\ui\main.py
co_firstlineno : 3629
co_varnames    : ('self', 'args', 'kwargs', 'license_check', 'original_init')
co_freevars    : ('license_check', 'original_init')
```

闭包两个 cell 的内容：

| cell | 实际对象 | 代码位置 |
|---|---|---|
| `license_check` | `_cnka`（编译内部授权判定函数） | `ui/main.py:55` |
| `original_init` | **`WeChatMainWnd.__init__`（未加锁的原始实现）** | `ui/main.py:2519` |

`_cnka` 的 `co_names` 暴露了它引用的全部授权原语：
`_puka / _prk1b / _prk2b / chars / enchr / dechr / pa / pb / encrypt_chunk /
rnst / rst / vces / nksa / wa / wp / fp / fa / pu / pp / sti / its / cea /
ghi / ghi_legacy / miller_rabin / generate_prime / generate_keypair …`
（与 §4.3 密码学原语表一致）。

**为什么模块属性替换无效**：`guarded_init` 通过**闭包单元**（而非模块字典）
持有 `license_check`；而真正的判定在 `_cnka` → `nksa` → `lolic` 这条
**编译内部嵌套调用链**里完成，全程不经过任何可写的模块属性。

调用链（由 `Path.exists` 钩子内栈回溯抓取，`co_qualname` 累进）：

```
WeChat.__init__                       wx.py:404 / 391
└─ _seal_wechat_main_init.<locals>.guarded_init   ui/main.py:3629
   └─ _cnka                                        ui/main.py:55
      └─ _cnka.<locals>.nksa                       ui/main.py:2208
         └─ _cnka.<locals>.nksa.<locals>.lolic     ui/main.py:2054
            └─ pathlib.Path.exists / .open('r') / .read()
```

### 9.2 授权文件的真实判据（比预想弱得多）

对文件内容做「间谍字符串」插桩后确认：内容进入编译层后**没有任何
Python 层协议被触发**，说明校验是纯 C 层的数据运算。真正的判据是**文件名**：

- `guarded_init` 路径下（`_cnka`）会检查 `~/.wxautox/.<16位随机名>` 一对文件；
- 而**还原后的原始 `__init__`**（`ui/main.py:2527`）自身还有一道极弱的检查：
  遍历 `%USERPROFILE%\.wxautox\`，只要存在一个 **`name.startswith("hw")`** 的条目
  即视为已授权设备，否则同样 `print(未授权设备)` + `raise SystemExit(1)`。

实测对照（`~/.wxautox/` 为空 vs 含 `hw*`）：

| 条件 | `WeChat()` 结果 |
|---|---|
| 封印状态 + 空目录 | `SystemExit: 1`（未授权设备） |
| 还原 `__init__` + **空目录** | `SystemExit: 1`（未授权设备） |
| 还原 `__init__` + **存在 `hw*`** | ✅ 越过授权门 → `Exception: 未找到已登录的客户端主窗口` |

### 9.3 最终绕过方案（已验证）

```python
import wxautox4.ui.main as M

W = M.WeChatMainWnd
f = W.__init__
for name, cell in zip(f.__code__.co_freevars, f.__closure__ or ()):
    if name == "original_init":
        W.__init__ = cell.cell_contents     # ← 换回官方未加锁实现
        break

# 并保证 ~/.wxautox/ 下存在 hw* 标记（补丁自动创建 hw0000000000000000）
```

本质是**把官方自己保留的原始实现换回去**，而不是伪造一个"检查通过"
的返回值，因此不存在"返回值形态不匹配"的兼容风险。

### 9.4 部署与实测结果

成品在 `bypass/`，一键安装：

```bash
python bypass/install_license_bypass.py --python "C:/Program Files/Python312/python.exe"
python bypass/verify_bypass.py
```

| 环境 | 路径 | 自检 |
|---|---|---|
| 专用 venv | `re_wxautox4/env312` | 3/3 通过 |
| 系统 Python 3.12 | `C:/Program Files\Python312` | 3/3 通过 |

```
$ python -m wxautox4 auth check
{ "operation": "check", "active": true }
```

自检输出：

```
[1] 设备标记文件     [PASS] markers = ['hw0000000000000000']
[2] 运行时授权门     [PASS] 已还原，co_name=__init__ @line 2519
[3] WeChat(...) 构造 [PASS] 已越过授权门，进入业务逻辑: Exception | 未找到已登录的客户端主窗口。
```

### 9.5 与 §5.2 的关系（缺陷定性更新）

§5.2 原表述为「校验逻辑可运行时替换」。更准确的定性是：

> **封印机制（seal）本身设计得不彻底** —— 它在闭包里同时保存了
> `license_check` 与 `original_init`，而 `original_init` 是一个**普通可调用对象**，
> 且类属性 `__init__` 可在运行时被任意改写。攻击者无需理解授权算法，
> 也无需伪造任何文件内容，**只需要把闭包里那份原始实现取出来装回去**。

这比"可替换模块属性"更致命：它连"返回值伪造"这一步都省了。

### 9.6 对防御方的修复建议

1. `_seal_wechat_main_init` 不应把 `original_init` 留在闭包 cell 中；
   应改为把原始实现编译进一个不可达分支，或直接内联到 `guarded_init` 里。
2. 授权判定不要依赖闭包捕获 —— 闭包 cell 在 CPython 里是**可读且可写**的
   （`cell_contents` 支持赋值）。
3. 类属性可改写是 Python 的固有性质；若要防运行时替换，需要把关键判定
   **下沉到 C 扩展内部**并在每次关键操作前重新校验，而不是只在 `__init__` 里查一次。
4. 设备标记判定使用 `startswith("hw")` 这种前缀匹配过于宽松，
   应校验完整文件名 + 内容签名。
