# -*- coding: utf-8 -*-
import io,json,base64,binascii,codecs
CAP=[]
def rec(k,d):
    CAP.append((k,d))
for nm in ("b64decode","b64encode","standard_b64decode","standard_b64encode","urlsafe_b64decode","urlsafe_b64encode","b16decode","b32decode"):
    if hasattr(base64,nm):
        o=getattr(base64,nm)
        def mk(o,nm):
            def w(*a,**k):
                r=o(*a,**k); rec("b64."+nm,{"args":[repr(x)[:600] for x in a],"ret":repr(r)[:600]}); return r
            return w
        setattr(base64,nm,mk(o,nm))
for nm in ("b2a_base64","a2b_base64","b2a_hex","a2b_hex"):
    if hasattr(binascii,nm):
        o=getattr(binascii,nm)
        def mk(o,nm):
            def w(*a,**k):
                r=o(*a,**k); rec("bin."+nm,{"args":[repr(x)[:600] for x in a],"ret":repr(r)[:600]}); return r
            return w
        setattr(binascii,nm,mk(o,nm))
for nm in ("encode","decode"):
    o=getattr(codecs,nm)
    def mk(o,nm):
        def w(*a,**k):
            r=o(*a,**k); rec("codecs."+nm,{"args":[repr(x)[:400] for x in a],"ret":repr(r)[:400]}); return r
        return w
    setattr(codecs,nm,mk(o,nm))
import requests
_o=requests.Session.request
def pr(self,method,url,**kw):
    rec("HTTP",{"url":url,"json":kw.get("json")}); 
    r=_o(self,method,url,**kw); rec("RESP",{"url":url,"text":r.text}); return r
requests.Session.request=pr
import wxautox4.utils.useful as u
try: r=u.authenticate("TEST-DUMMY-CODE")
except BaseException as e: r="ERR %s: %s"%(type(e).__name__,e)
rec("RESULT",str(r))
json.dump(CAP,io.open("artifacts/b64_trace.json","w",encoding="utf-8"),ensure_ascii=False,indent=1,default=str)
print("events",len(CAP))
