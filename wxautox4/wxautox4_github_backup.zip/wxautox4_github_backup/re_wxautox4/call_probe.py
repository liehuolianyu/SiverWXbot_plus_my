# -*- coding: utf-8 -*-
import io, json
import wxautox4.utils.useful as U
OUT={}
def cap(name, fn):
    try:
        r=fn()
        OUT[name]={"ok":True,"type":type(r).__name__,"val":repr(r)[:300]}
    except BaseException as e:
        OUT[name]={"ok":False,"exc":"%s: %s"%(type(e).__name__,e)}
for n in ("jnice","kbjd","tole","cea","nismce","get_licence_file","arg_parser"):
    if hasattr(U,n): cap(n, getattr(U,n))
for arg in (16, 32, None):
    if hasattr(U,"nismce"):
        cap("nismce(%r)"%arg, lambda a=arg: U.nismce(a))
cap("its(b'abc')", lambda: U.its(b"abc"))
cap("sti('abc')", lambda: U.sti("abc"))
cap("chlc('')", lambda: U.chlc(""))
cap("check_license", U.check_license)
json.dump(OUT, io.open("artifacts/call_probe.json","w",encoding="utf-8"), ensure_ascii=False, indent=1, default=str)
print(json.dumps(OUT, ensure_ascii=False, indent=1, default=str)[:3000])
