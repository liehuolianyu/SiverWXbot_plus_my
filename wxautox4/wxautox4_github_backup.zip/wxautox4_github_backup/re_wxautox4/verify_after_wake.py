# -*- coding: utf-8 -*-
"""闸门确认 + WeChat() 带退避重试的可用性验证"""
import ctypes
import ctypes.wintypes as wt
import sys
import time

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

# --- 1) 用 ControlFromHandle 判闸门（与唤醒工具同一判据） ---
from wxautox4.uia import uiautomation as auto


def find_main_hwnd():
    u = ctypes.windll.user32
    u.GetClassNameW.argtypes = [wt.HWND, wt.LPWSTR, ctypes.c_int]
    u.GetWindowTextW.argtypes = [wt.HWND, wt.LPWSTR, ctypes.c_int]
    CB = ctypes.WINFUNCTYPE(ctypes.c_bool, wt.HWND, wt.LPARAM)
    st = {"h": 0}

    def cb(h, l):
        b = ctypes.create_unicode_buffer(128)
        u.GetClassNameW(h, b, 128)
        if b.value == "Qt51514QWindowIcon":
            t = ctypes.create_unicode_buffer(128)
            u.GetWindowTextW(h, t, 128)
            if t.value == "微信":
                st["h"] = h
                return False
        return True

    u.EnumWindows(CB(cb), 0)
    return st["h"]


hwnd = find_main_hwnd()
print("主窗口 hwnd = 0x%08X" % hwnd)

ctl = auto.ControlFromHandle(hwnd)
print("顶层 UIA 类名 :", repr(ctl.ClassName))
kids = ctl.GetChildren()
print("直接子元素数  :", len(kids))
mmui = [k.ClassName for k in kids if (k.ClassName or "").startswith("mmui::")]
print("mmui:: 子元素 : %d 个 -> %s" % (len(mmui), mmui[:6]))
print("闸门状态      :", "已激活 ✔" if mmui or (ctl.ClassName or "").startswith("mmui::") else "未激活 ✘")

# --- 2) WeChat() 退避重试 ---
print("\n" + "=" * 60)
from wxautox4 import WeChat

delays = [0, 1.5, 3.0, 5.0]
for i, d in enumerate(delays, 1):
    if d:
        time.sleep(d)
    try:
        wx = WeChat()
    except BaseException as e:
        msg = str(e).splitlines()[0] if str(e) else repr(e)
        print("第 %d 次: 失败 -> %s: %s" % (i, type(e).__name__, msg))
        continue
    print("第 %d 次: 成功 -> %r" % (i, wx))
    try:
        info = wx.GetMyInfo()
        print("   GetMyInfo   :", info)
    except Exception as e:
        print("   GetMyInfo 失败:", e)
    try:
        ss = wx.GetSession()
        print("   GetSession  : %d 个会话" % len(ss))
        for s in ss[:5]:
            print("       -", getattr(s, "name", s))
    except Exception as e:
        print("   GetSession 失败:", e)
    break
else:
    print("\n四次尝试均失败。")
