# -*- coding: utf-8 -*-
import inspect, io, json
import wxautox4.utils.useful as U
rows=[]
for n in dir(U):
    if n.startswith("__"): continue
    o=getattr(U,n)
    if callable(o):
        sig=None
        try: sig=str(inspect.signature(o))
        except Exception as e: sig="<%s>"%type(e).__name__
        doc=(inspect.getdoc(o) or "").splitlines()
        rows.append({"name":n,"sig":sig,"doc":doc[0][:120] if doc else ""})
print("callables:",len(rows))
for r in rows:
    print("  %-28s %-40s %s" % (r["name"], r["sig"][:40], r["doc"][:70]))
json.dump(rows, io.open("artifacts/useful_fns.json","w",encoding="utf-8"), ensure_ascii=False, indent=1)
