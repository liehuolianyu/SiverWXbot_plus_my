# -*- coding: utf-8 -*-
"""Test whether the armor uses a fixed per-position keystream (Vigenere-style).

If it does, delta1[i] == delta2[i] for two different messages, and the keystream
falls out immediately.
"""
import json, io, os
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))
D = json.load(io.open(os.path.join(HERE, "artifacts", "b64_trace.json"), encoding="utf-8"))

resps, b64s = [], []
for k, v in D:
    if k == "RESP":
        resps.append(v["text"])
    if k in ("b64.b64encode", "b64encode"):
        b = v["ret"]
        if isinstance(b, str) and b.startswith("b'"):
            b = b[2:-1]
        b64s.append(b)
    if k in ("bin.a2b_base64", "b64.b64decode"):
        a = v["args"][0]
        if isinstance(a, str) and a.startswith("b'"):
            a = a[2:-1]
        b64s.append(a)

print("RESPs:", [len(x) for x in resps])
print("B64 candidates lens:", [len(x) for x in b64s])

S1, S2 = resps[0], resps[1]
B1, B2 = b64s[0], b64s[1]
print("B1:", B1[:50])
print("B2:", B2[:50])

ALPHA_LEN = 94


def delta(c, p):
    return (ord(c) - ord(p)) % ALPHA_LEN


for off in (0, 79, 78, 80):
    if off + len(B1) > len(S1) or off + len(B2) > len(S2):
        continue
    d1 = [delta(S1[off + i], B1[i]) for i in range(len(B1))]
    d2 = [delta(S2[off + i], B2[i]) for i in range(len(B2))]
    n = min(len(d1), len(d2))
    same = sum(1 for i in range(n) if d1[i] == d2[i])
    print("\noffset %d: identical delta positions %d/%d" % (off, same, n))
    if same > n * 0.5:
        print("  *** COMMON KEYSTREAM (approx) ***")
        ks = [(d1[i] - d2[i]) % ALPHA_LEN for i in range(n)]
        print("  delta-diff sample:", ks[:40])

# Also: maybe the plaintext is only the 79-char prefix, and base64 is appended clear
print("\n--- check if B appears XOR-shifted with fixed per-position key wrt S tail ---")
tail = S1[79:]
d = [delta(tail[i], B1[i]) for i in range(len(B1))]
c = Counter(d)
print("tail delta distinct:", len(c), c.most_common(5))

# check whether the 79-char head of both messages shares delta structure with anything
print("\nhead1:", repr(S1[:79]))
print("head2:", repr(S2[:79]))
print("head delta distinct:", len(Counter((ord(S1[i]) - ord(S2[i])) % ALPHA_LEN for i in range(79))))
