# -*- coding: utf-8 -*-
import sys, pathlib
CNT={"exists":0,"open":0}
_oe=pathlib.Path.exists; _of=pathlib.Path.open
def fe(self):
    if ".wxautox" in str(self): CNT["exists"]+=1; print("[exists]",self)
    return _oe(self)
def fo(self,*a,**k):
    if ".wxautox" in str(self): CNT["open"]+=1; print("[open]",self,a)
    return _of(self,*a,**k)
pathlib.Path.exists=fe; pathlib.Path.open=fo
# unseal
import wxautox4.ui.main as M
W=M.WeChatMainWnd; f=W.__init__; c=f.__code__
for nm,cell in zip(c.co_freevars, f.__closure__ or ()):
    if nm=="original_init": W.__init__=cell.cell_contents
print("unsealed")
for name in ("chars","enchr","dechr","encrypt_chunk","decrypt_chunk","rnst","rst","pa","pb","_puka","_prk1b","_prk2b","nksa","vces","e"):
    for mod,label in ((M,"ui.main"),):
        if hasattr(mod,name):
            v=getattr(mod,name)
            print("  %s.%s = %s %s" % (label,name,type(v).__name__,repr(v)[:80]))
try:
    from wxautox4.wx import WeChat
    WeChat(nickname="__p__")
    print("RESULT OK")
except BaseException as e:
    print("RESULT:", type(e).__name__, "|", str(e)[:150])
print("CNT:", CNT)
