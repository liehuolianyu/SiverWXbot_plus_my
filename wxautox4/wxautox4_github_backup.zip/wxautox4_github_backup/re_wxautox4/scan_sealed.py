# -*- coding: utf-8 -*-
import sys, types, inspect
import wxautox4
hits=[]
for modname, mod in list(sys.modules.items()):
    if not modname.startswith("wxautox4"): continue
    if not isinstance(mod, types.ModuleType): continue
    for k, v in list(vars(mod).items()):
        if isinstance(v, type) and v.__module__.startswith("wxautox4"):
            for ck, cv in list(vars(v).items()):
                f = cv
                if isinstance(f,(staticmethod,classmethod)): f=f.__func__
                code=getattr(f,"__code__",None)
                if code is None: continue
                fv=getattr(code,"co_freevars",()) or ()
                if "license_check" in fv:
                    hits.append((modname+"."+k, ck, code.co_name, code.co_firstlineno, tuple(fv)))
# also module-level funcs
for modname, mod in list(sys.modules.items()):
    if not modname.startswith("wxautox4") or not isinstance(mod, types.ModuleType): continue
    for k, v in list(vars(mod).items()):
        code=getattr(v,"__code__",None)
        if code and "license_check" in (getattr(code,"co_freevars",()) or ()):
            hits.append((modname, k, code.co_name, code.co_firstlineno, tuple(code.co_freevars)))
print("sealed functions found:", len(hits))
for h in hits: print("  ", h)
