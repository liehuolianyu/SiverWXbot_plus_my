# -*- coding: utf-8 -*-
"""wxautox4 一键就绪 + 可用性验证

背景
----
微信 4.x 上 wxautox4 需要两个外部条件才能连上：

1. **UIA 无障碍闸门**：微信自绘 UI，只有闸门字节为 1 时才把 `mmui::MainWindow`
   等控件暴露给 UI Automation。该字节会被微信定期复位，所以**每次使用前补一次**
   （热写 1 字节，校验失败自动回滚，不重启微信、不改微信文件）。
2. **微信主窗口需要被激活**：窗口在后台时 Qt 会回收消息列表的无障碍节点，
   `GetAllMessage()` 会返回空、资料卡也读不到 → `get_my_info()` 拿到 None。

用法
----
    <venv>\\Scripts\\python.exe wxautox4_ready.py            # 就绪 + 验证
    <venv>\\Scripts\\python.exe wxautox4_ready.py --no-read  # 只验证连接，不读消息
"""
import ctypes
import ctypes.wintypes as wt
import importlib.util
import os
import sys
import time

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

HERE = os.path.dirname(os.path.abspath(__file__))
WAKE_SRC = os.path.join(HERE, "wake_ref", "wechat_uia_wake.py")

WIN_CLS = "Qt51514QWindowIcon"
WIN_NAME = "微信"


# --------------------------------------------------------------------------- #
def load_wake_module():
    spec = importlib.util.spec_from_file_location("wx_uia_wake", WAKE_SRC)
    if spec is None or spec.loader is None:
        return None
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)

    def _uia():
        try:
            from wxautox4.uia import uiautomation as auto
            return auto
        except Exception:
            return None

    mod._uia = _uia
    return mod


def _fg():
    """前台窗口句柄，统一返回 int"""
    try:
        return int(ctypes.windll.user32.GetForegroundWindow() or 0)
    except Exception:
        return 0


def find_main_hwnd():
    u = ctypes.windll.user32
    u.GetClassNameW.argtypes = [wt.HWND, wt.LPWSTR, ctypes.c_int]
    u.GetWindowTextW.argtypes = [wt.HWND, wt.LPWSTR, ctypes.c_int]
    CB = ctypes.WINFUNCTYPE(ctypes.c_bool, wt.HWND, wt.LPARAM)
    st = {"h": 0}

    def cb(h, l):
        b = ctypes.create_unicode_buffer(128)
        u.GetClassNameW(h, b, 128)
        if b.value == WIN_CLS:
            t = ctypes.create_unicode_buffer(128)
            u.GetWindowTextW(h, t, 128)
            if t.value == WIN_NAME:
                st["h"] = h
                return False
        return True

    u.EnumWindows(CB(cb), 0)
    return st["h"]


def activate(hwnd):
    """尽量把微信窗口激活（让 Qt 重建消息列表节点）"""
    u = ctypes.windll.user32
    u.ShowWindow(hwnd, 9)                       # SW_RESTORE
    try:
        u.SwitchToThisWindow(hwnd, True)
    except Exception:
        pass
    time.sleep(0.4)
    u.SetForegroundWindow(hwnd)
    # 备用：短暂置顶再取消，常能抢到前台
    u.SetWindowPos(hwnd, -1, 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0040)
    time.sleep(0.3)
    u.SetWindowPos(hwnd, -2, 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0040)
    time.sleep(1.2)


# --------------------------------------------------------------------------- #
def main():
    do_read = "--no-read" not in sys.argv

    print("=" * 64)
    print("wxautox4 就绪 + 可用性验证")
    print("=" * 64)

    # 1) 补闸门
    wake = load_wake_module()
    if wake is None:
        print("[X] 找不到 %s" % WAKE_SRC)
        return 2
    print("\n[1] UIA 无障碍闸门")
    out = wake.wake()
    print("      ok=%s action=%s rva=%s" % (out.get("ok"), out.get("action"), out.get("rva")))
    if not out.get("ok"):
        print("      detail=%s" % out.get("detail"))
        return 1

    # 2) 激活窗口
    print("\n[2] 激活微信主窗口")
    hwnd = find_main_hwnd()
    if not hwnd:
        print("      未找到微信主窗口")
        return 1
    print("      hwnd=0x%08X -> 激活中 ..." % hwnd)
    activate(hwnd)
    print("      前台窗口=0x%08X" % _fg())

    # 3) 连接
    print("\n[3] 连接微信")
    from wxautox4 import WeChat
    try:
        wx = WeChat()
    except BaseException as e:
        print("      [X] WeChat() 失败: %s: %s" % (type(e).__name__, str(e).splitlines()[0]))
        return 1
    print("      [OK] WeChat() 构造成功")
    print("           我的昵称 = %r" % (getattr(wx, "nickname", None),))
    try:
        print("           在线     = %s" % wx.IsOnline())
    except Exception as e:
        print("           IsOnline 失败: %r" % e)
    try:
        sessions = wx.GetSession()
        names = [getattr(s, "name", str(s)) for s in sessions]
        print("           会话数   = %d -> %s" % (len(names), names[:8]))
    except Exception as e:
        print("           GetSession 失败: %r" % e)
        return 1
    try:
        info = wx.GetMyInfo()
        print("           GetMyInfo= %r" % (info,))
    except Exception as e:
        print("           GetMyInfo 失败: %r" % e)

    # 4) 读一条会话的消息
    if do_read and names:
        target = names[0]
        print("\n[4] 读取会话消息 (%s)" % target)
        try:
            wx.ChatWith(target)
            time.sleep(1.0)
            msgs = wx.GetAllMessage()
            print("      [OK] 读到 %d 条消息" % len(msgs))
            for m in msgs[-5:]:
                print("           attr=%-8r sender=%-12r %r"
                      % (getattr(m, "attr", None), getattr(m, "sender", None),
                         str(getattr(m, "content", ""))[:40]))
        except Exception as e:
            print("      [!] 消息读取异常: %r" % (e,))

    print("\n" + "=" * 64)
    print("结论：wxautox4 可用 ✔")
    print("=" * 64)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
