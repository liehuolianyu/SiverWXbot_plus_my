# -*- coding: utf-8 -*-
import sys, pathlib, os
NAME = os.environ.get("ENTRY_NAME", ".hczvYWPCeRiP9bQN")
P = pathlib.Path
class SpyStr(str):
    def _l(self, op, o=None):
        print("[str.%s] self=%r other=%r" % (op, str.__repr__(self)[:60], repr(o)[:120]))
    def __eq__(self,o): self._l("eq",o); return str.__eq__(self,o)
    def __ne__(self,o): self._l("ne",o); return str.__ne__(self,o)
    def __contains__(self,o): self._l("contains",o); return str.__contains__(self,o)
    def endswith(self,*a): self._l("endswith",a); return str.endswith(self,*a)
    def startswith(self,*a): self._l("startswith",a); return True
    def split(self,*a): self._l("split",a); return [SpyStr(x) for x in str.split(self,*a)]
    def strip(self,*a): self._l("strip",a); return SpyStr(str.strip(self,*a))
    def lower(self): self._l("lower"); return SpyStr(str.lower(self))
    def upper(self): self._l("upper"); return SpyStr(str.upper(self))
    def __getitem__(self,i): self._l("getitem",i); return SpyStr(str.__getitem__(self,i))
class SpyEntry:
    def __init__(self, path): object.__setattr__(self,"_p",path)
    def __str__(self): print("[entry.__str__]"); return str(object.__getattribute__(self,"_p"))
    def __fspath__(self): return str(object.__getattribute__(self,"_p"))
    @property
    def name(self):
        n=object.__getattribute__(self,"_p").name; print("[entry.name] ->",n); return SpyStr(n)
    @property
    def stem(self):
        n=object.__getattribute__(self,"_p").stem; print("[entry.stem] ->",n); return SpyStr(n)
    @property
    def suffix(self):
        n=object.__getattribute__(self,"_p").suffix; print("[entry.suffix] ->",n); return SpyStr(n)
    def __getattr__(self, k):
        print("[entry.getattr]", k)
        v=getattr(object.__getattribute__(self,"_p"), k)
        if callable(v):
            def w(*a,**kw):
                r=v(*a,**kw)
                print("[entry.call] %s(%r) -> %r" % (k, a[:1], repr(r)[:150]))
                return r
            return w
        return v
_oi = P.iterdir
def f_iter(self):
    s=str(self)
    if ".wxautox" in s and s.endswith(".wxautox"):
        print("[iterdir intercepted]", s)
        return iter([SpyEntry(P(s)/NAME)])
    return _oi(self)
P.iterdir=f_iter
# unseal
import wxautox4.ui.main as M
W=M.WeChatMainWnd; f=W.__init__; c=f.__code__
for nm,cell in zip(c.co_freevars, f.__closure__ or ()):
    if nm=="original_init": W.__init__=cell.cell_contents
try:
    from wxautox4.wx import WeChat
    WeChat(nickname="__p__")
    print("RESULT OK")
except BaseException as e:
    print("RESULT:", type(e).__name__, "|", str(e)[:150])
