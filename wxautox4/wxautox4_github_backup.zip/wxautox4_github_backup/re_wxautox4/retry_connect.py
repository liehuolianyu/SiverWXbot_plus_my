# -*- coding: utf-8 -*-
"""每轮先补闸门，再重试 WeChat()，直到成功"""
import importlib.util
import os
import sys
import time

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

HERE = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location(
    "wx_uia_wake", os.path.join(HERE, "wake_ref", "wechat_uia_wake.py"))
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
from wxautox4.uia import uiautomation as auto  # noqa: E402

mod._uia = lambda: auto

from wxautox4 import WeChat  # noqa: E402

OK = None
for attempt in range(1, 7):
    out = mod.wake()
    armed = out.get("ok")
    print("轮次 %d | 补闸门: %s (%s)" % (attempt, armed, out.get("action") or out.get("detail")))
    try:
        wx = WeChat()
        OK = wx
        print("   >> WeChat() 成功 -> %r" % (wx,))
        break
    except BaseException as e:
        msg = str(e).splitlines()[0] if str(e) else repr(e)
        print("   >> 失败: %s: %s" % (type(e).__name__, msg))
    time.sleep(2)

if OK is None:
    print("\n全部失败")
    raise SystemExit(1)

print("\n--- 功能确认 ---")
for label, fn in (("GetMyInfo", lambda: OK.GetMyInfo()),
                  ("GetSession", lambda: "len=%d" % len(OK.GetSession())),
                  ("IsOnline", lambda: OK.IsOnline())):
    try:
        print("  %-12s -> %r" % (label, fn()))
    except Exception as e:
        print("  %-12s -> 失败 %r" % (label, e))
