# -*- coding: utf-8 -*-
import re
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

P = r"C:\Users\Administrator\Documents\ChatGPT\live2D\_wxautox4_probe\SiverWXbot_plus\.venv_clean\Lib\site-packages\wxautox4\ui\main.cp312-win_amd64.pyd"
data = open(P, "rb").read()

key = "\u672a\u627e\u5230\u5df2\u767b\u5f55\u7684\u5ba2\u6237\u7aef\u4e3b\u7a97\u53e3".encode("utf-8")
hits = [m.start() for m in re.finditer(re.escape(key), data)]
print("raw hits:", len(hits))
for h in hits:
    s = max(0, h - 2000)
    e = min(len(data), h + 2000)
    chunk = data[s:e]
    # 逐段解码，容忍非法字节
    txt = chunk.decode("utf-8", "replace")
    parts = re.findall(r"[\u4e00-\u9fff\x20-\x7e]{4,}", txt)
    print("---- around @%d ----" % h)
    for t in parts:
        print("    %s" % t[:130])
