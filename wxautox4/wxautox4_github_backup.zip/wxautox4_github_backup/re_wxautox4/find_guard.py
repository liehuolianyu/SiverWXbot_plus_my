# -*- coding: utf-8 -*-
import importlib, pkgutil, sys
import wxautox4
mods=set()
for m in pkgutil.walk_packages(wxautox4.__path__, "wxautox4."):
    mods.add(m.name)
mods |= {"wxautox4.wx","wxautox4.ui.main","wxautox4.cli.main"}
for name in sorted(mods):
    try: mod=importlib.import_module(name)
    except BaseException: continue
    if hasattr(mod,"guarded_init"):
        print("FOUND guarded_init in", name, "->", getattr(mod,"guarded_init"))
print("--- wx module attrs containing 'guard' ---")
import wxautox4.wx as W
print([n for n in dir(W) if "guard" in n.lower()])
print("--- wxautox4.wx.WeChat has ---")
print([n for n in dir(W.WeChat) if "guard" in n.lower() or "init" in n.lower()])
print("--- WeChat.__init__ module/qualname ---")
print(getattr(W.WeChat.__init__,"__module__",None), getattr(W.WeChat.__init__,"__qualname__",None))
