# -*- coding: utf-8 -*-
import sys, os, importlib, inspect, traceback
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "bypass"))
import wxautox4_nolicense

print("=== 1) 顶层门 ===")
import wxautox4.utils.useful as u
print("check_license ->", u.check_license())
print("chlc ->", u.chlc())

print("=== 2) 未打补丁时 ui.main 导入是否触发 ===")
try:
    m = importlib.import_module("wxautox4.ui.main")
    print("ui.main imported OK; check_license() ->", m.check_license())
except BaseException as e:
    print("ui.main import ERR", type(e).__name__, e)

print("=== 3) 公开发布对象解析 ===")
import wxautox4
for n in ("WeChat","Chat","LoginWnd","WxParam","authenticate"):
    try:
        o = getattr(wxautox4, n)
        print(" ", n, "->", getattr(o,"__module__",type(o).__name__))
    except BaseException as e:
        print(" ", n, "ERR", type(e).__name__, e)

print("=== 4) 逐一调用各模块授权函数 ===")
for modname in ("wxautox4.utils.useful","wxautox4.ui.main"):
    mod = sys.modules.get(modname) or importlib.import_module(modname)
    for fn in ("check_license","chlc","authenticate","authenticate_with_file","authenticate_with_file2","offline_auth"):
        f = getattr(mod, fn, None)
        if f is None: continue
        try:
            print("  %s.%s -> %r" % (modname, fn, f()))
        except BaseException as e:
            print("  %s.%s ERR %s: %s" % (modname, fn, type(e).__name__, e))
