# -*- coding: utf-8 -*-
import sys, os, traceback
HITS=[]
_oe = sys.exit
def fake_exit(*a, **k):
    HITS.append(("sys.exit", a, k))
    f=sys._getframe(1)
    try:
        raise RuntimeError("SUPPRESSED exit from %s:%s" % (f.f_code.co_name, f.f_lineno))
    except RuntimeError:
        tb=sys.exc_info()[2]
        names=[]
        t=tb
        while t and len(names)<8:
            names.append("%s:%s" % (t.tb_frame.f_code.co_qualname, t.tb_lineno)); t=t.tb_next
        HITS.append(("trace", names))
    return None
sys.exit = fake_exit
import builtins
builtins.exit = fake_exit
try:
    from wxautox4.wx import WeChat
    w=WeChat(nickname="__p__")
    print("RESULT: constructed OK ->", type(w).__name__)
except BaseException as e:
    print("RESULT RAISED:", type(e).__name__, "|", str(e)[:250])
    print("\n".join(traceback.format_exc().strip().splitlines()[-6:]))
print("HITS:", HITS[:6])
