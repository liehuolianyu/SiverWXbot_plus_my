# -*- coding: utf-8 -*-
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

import wxautox4.ui.main as M

f = M.WeChatMainWnd.__init__
print("func:", f, "type:", type(f))
c = getattr(f, "__code__", None)
print("co_name:", getattr(c, "co_name", None), "@", getattr(c, "co_firstlineno", None))
print("freevars:", getattr(c, "co_freevars", None))
print("varnames:", getattr(c, "co_varnames", None))
names = getattr(c, "co_names", None) or ()
print("\nco_names (%d):" % len(names))
for n in names:
    print("    ", n)
cs = getattr(c, "co_consts", None) or ()
print("\nco_consts:")
for x in cs:
    if isinstance(x, str):
        print("    str %r" % (x[:140],))
    elif isinstance(x, (int, float, bytes)):
        print("    %s %r" % (type(x).__name__, x))
    elif x is None or x is True or x is False:
        print("    %r" % (x,))
    else:
        print("    %s" % type(x).__name__)
