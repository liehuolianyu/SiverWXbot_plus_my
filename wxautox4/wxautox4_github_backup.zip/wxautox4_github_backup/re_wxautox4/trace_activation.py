# -*- coding: utf-8 -*-
"""Dynamic instrumentation of wxautox4 activation flow.

Hooks: HTTP (requests/urllib), hashing (hashlib), file IO (builtins.open),
process spawn (subprocess/os.popen). Then exercises the license entry points
with a dummy code and records exactly what the code does.
"""
import builtins
import hashlib
import io
import json
import os
import sys
import traceback

LOG = []


def rec(kind, data):
    LOG.append({"t": kind, "d": data})
    try:
        print("[HOOK %s] %s" % (kind, json.dumps(data, ensure_ascii=False, default=str)[:800]))
    except BaseException:
        print("[HOOK %s] <unprintable>" % kind)


# ---------- hook requests ----------
def install_http_hooks():
    try:
        import requests
    except BaseException:
        return
    orig_request = requests.Session.request

    def patched_request(self, method, url, **kw):
        rec("HTTP", {"method": method, "url": url,
                     "params": kw.get("params"),
                     "data": str(kw.get("data"))[:1000],
                     "json": str(kw.get("json"))[:1000],
                     "headers": {k: v for k, v in (kw.get("headers") or {}).items()},
                     "timeout": kw.get("timeout")})
        r = orig_request(self, method, url, **kw)
        body = ""
        try:
            body = r.text[:2000]
        except BaseException:
            pass
        rec("HTTP_RESP", {"url": url, "status": r.status_code, "body": body})
        return r

    requests.Session.request = patched_request

    for name in ("post", "get"):
        ofn = getattr(requests, name)

        def mk(name, ofn):
            def wrapper(*a, **k):
                rec("HTTP_API", {"fn": name, "args": [str(x)[:300] for x in a],
                                 "kwargs": {kk: str(vv)[:500] for kk, vv in k.items()}})
                return ofn(*a, **k)
            return wrapper
        setattr(requests, name, mk(name, ofn))


# ---------- hook hashlib ----------
def install_hash_hooks():
    def mk(cls):
        orig = cls
        class W:
            def __init__(self, data=b"", **kw):
                self._o = orig(data, **kw)
                self._chunks = [bytes(data) if data else b""]
                self._name = orig.__name__

            def update(self, d):
                self._chunks.append(bytes(d))
                return self._o.update(d)

            def hexdigest(self):
                h = self._o.hexdigest()
                rec("HASH", {"algo": self._name,
                             "input_hex": b"".join(self._chunks).hex()[:400],
                             "input_repr": repr(b"".join(self._chunks))[:300],
                             "digest": h})
                return h

            def digest(self):
                return self._o.digest()

            def __getattr__(self, n):
                return getattr(self._o, n)
        return W

    for n in ("md5", "sha1", "sha256", "sha512"):
        if hasattr(hashlib, n):
            setattr(hashlib, n, mk(getattr(hashlib, n)))
    hashlib.new = mk(hashlib.new) if hasattr(hashlib, "new") else None


# ---------- hook file io ----------
def install_file_hooks():
    ofn = builtins.open
    watch = ("license", "wxauto", ".json", ".txt", ".lic")

    def patched(file, mode="r", *a, **k):
        try:
            p = str(file)
        except BaseException:
            p = "?"
        if any(w in p.lower() for w in watch):
            rec("FILE", {"path": p, "mode": mode})
        return ofn(file, mode, *a, **k)
    builtins.open = patched


# ---------- hook subprocess ----------
def install_proc_hooks():
    import subprocess
    op = subprocess.Popen

    class P(op):
        def __init__(self, args, *a, **k):
            rec("PROC", {"args": str(args)[:400]})
            super().__init__(args, *a, **k)
    subprocess.Popen = P
    oa = subprocess.run

    def run(*a, **k):
        rec("PROC", {"args": str(a[0] if a else k.get("args"))[:400]})
        return oa(*a, **k)
    subprocess.run = run


def call(label, fn, *a, **k):
    try:
        r = fn(*a, **k)
        rec("CALL", {"fn": label, "ok": True, "ret": repr(r)[:600]})
        return r
    except BaseException as e:
        rec("CALL", {"fn": label, "ok": False, "err": "%s: %s" % (type(e).__name__, e),
                     "tb": traceback.format_exc()[-600:]})
        return None


def main():
    install_http_hooks()
    install_hash_hooks()
    install_file_hooks()
    install_proc_hooks()

    import wxautox4.utils.useful as u

    print("### module loaded:", u.__name__)

    # --- safe/no-network probes first ---
    call("get_licence_file", u.get_licence_file)
    call("check_license", u.check_license)
    call("chlc()", u.chlc)
    call("kbjd", u.kbjd)
    call("jnice", u.jnice)
    call("tole", u.tole)
    call("cea", u.cea)
    call("iacve('x')", u.iacve, "x")
    call("inlec('x')", u.inlec, "x")
    call("nkecl('x')", u.nkecl, "x")
    call("nkecl2('x')", u.nkecl2, "x")
    call("nismce()", u.nismce)
    call("its(b'abc')", u.its, b"abc")
    call("sti('abc')", u.sti, "abc")
    call("fa('abc',b'key')", u.fa, "abc", b"key")
    call("fp('abc','o')", u.fp, "abc", "o")
    call("pp('abc',b'key')", u.pp, "abc", b"key")
    call("pu('abc')", u.pu, "abc")
    call("wp('data','h')", u.wp, "data", "h")
    call("na('x')", u.na, "x")
    call("nc('a','b')", u.nc, "a", "b")
    call("wa('a','b')", u.wa, "a", "b")
    call("ghi('a','b','c')", u.ghi, "a", "b", "c")
    call("vces('a','b')", u.vces, "a", "b")

    # --- the real activation entry point (dummy code) ---
    call("authenticate('TEST-DUMMY-CODE')", u.authenticate, "TEST-DUMMY-CODE")

    with io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                              "artifacts", "dynamic_trace.json"), "w", encoding="utf-8") as f:
        json.dump(LOG, f, ensure_ascii=False, indent=1, default=str)
    print("### wrote artifacts/dynamic_trace.json, events:", len(LOG))


if __name__ == "__main__":
    main()
