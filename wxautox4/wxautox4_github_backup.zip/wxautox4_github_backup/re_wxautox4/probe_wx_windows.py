# -*- coding: utf-8 -*-
"""枚举所有 Weixin 进程的顶层窗口"""
import ctypes
import ctypes.wintypes as wt
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
import psutil

pids = set()
for p in psutil.process_iter(["pid", "name"]):
    if p.info["name"] and p.info["name"].lower() == "weixin.exe":
        pids.add(p.info["pid"])
print("Weixin pids:", sorted(pids))

u = ctypes.windll.user32
u.GetClassNameW.argtypes = [wt.HWND, wt.LPWSTR, ctypes.c_int]
u.GetWindowTextW.argtypes = [wt.HWND, wt.LPWSTR, ctypes.c_int]
u.GetWindowThreadProcessId.argtypes = [wt.HWND, ctypes.POINTER(wt.DWORD)]
CB = ctypes.WINFUNCTYPE(ctypes.c_bool, wt.HWND, wt.LPARAM)
rows = []


def cb(h, l):
    pid = wt.DWORD()
    u.GetWindowThreadProcessId(h, ctypes.byref(pid))
    if pid.value not in pids:
        return True
    cls = ctypes.create_unicode_buffer(256)
    u.GetClassNameW(h, cls, 256)
    t = ctypes.create_unicode_buffer(256)
    u.GetWindowTextW(h, t, 256)
    r = wt.RECT()
    u.GetWindowRect(h, ctypes.byref(r))
    rows.append((h, pid.value, cls.value, t.value, bool(u.IsWindowVisible(h)),
                 bool(u.IsIconic(h)), (r.right - r.left, r.bottom - r.top)))
    return True


u.EnumWindows(CB(cb), 0)
print("top-level windows of Weixin processes: %d" % len(rows))
for h, pid, cls, title, vis, minz, size in rows:
    print("  0x%08X pid=%-6d vis=%-5s min=%-5s %sx%s  cls=%r title=%r"
          % (h, pid, vis, minz, size[0], size[1], cls, title))
