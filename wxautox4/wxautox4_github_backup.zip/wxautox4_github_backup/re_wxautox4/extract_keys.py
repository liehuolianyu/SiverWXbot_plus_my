# -*- coding: utf-8 -*-
import json, io, os
HERE = os.path.dirname(os.path.abspath(__file__))
D = json.load(io.open(os.path.join(HERE,"artifacts","raw_io.json"),encoding="utf-8"))
out = {}
def parse_int_list(s):
    s = str(s).strip()
    if s.startswith("["): s = s[1:-1]
    return [int(x) for x in s.split(",")]
for c in D["wa"][:1]:
    k = parse_int_list(c["args"][1])
    out["server_public_key"] = {"e": k[0], "n": k[1], "n_bits": k[1].bit_length(), "n_hex": hex(k[1])}
for c in D["wp"][:1]:
    k = parse_int_list(c["args"][1])
    out["client_key"] = {"n": k[0], "d": k[1], "n_bits": k[0].bit_length(), "d_bits": k[1].bit_length(),
                         "n_hex": hex(k[0]), "d_hex": hex(k[1])}
# sanity: does client key behave as RSA? test pow with e=65537
n, d = out["client_key"]["n"], out["client_key"]["d"]
e = 65537
m = 123456789
out["client_key_rsa_selftest_(m**(e*d) == m mod n)"] = (pow(pow(m, e, n), d, n) == m)
json.dump(out, io.open(os.path.join(HERE,"artifacts","keys.json"),"w",encoding="utf-8"), ensure_ascii=False, indent=1)
print(json.dumps({k:(v if not isinstance(v,dict) else {kk:(str(vv)[:60]) for kk,vv in v.items()}) for k,v in out.items()}, ensure_ascii=False, indent=1)[:1500])
