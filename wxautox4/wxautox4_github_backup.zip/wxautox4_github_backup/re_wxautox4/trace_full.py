# -*- coding: utf-8 -*-
import io,json,os,functools
LOG=[]
def rec(k,d):
    LOG.append({"t":k,"d":d})
def s(x):
    try:
        if isinstance(x,(bytes,bytearray)): return "B:"+bytes(x).hex()
        return repr(x)
    except: return "<>"
import requests
_orig=requests.Session.request
def pr(self,method,url,**kw):
    rec("HTTP",{"m":method,"url":url,"json":kw.get("json")})
    r=_orig(self,method,url,**kw)
    rec("RESP",{"url":url,"status":r.status_code,"text":r.text})
    return r
requests.Session.request=pr
# hook hashlib.new for full input
import hashlib
_n=hashlib.new
def nw(name,data=b"",**k):
    h=_n(name,data,**k); ch=[bytes(data) if data else b""]; ru=h.update
    def u(d):
        ch.append(bytes(d)); return ru(d)
    h.update=u; rh=h.hexdigest
    def hx():
        o=rh(); rec("HASH",{"algo":name,"in":s(b"".join(ch)),"out":o}); return o
    h.hexdigest=hx; return h
hashlib.new=nw
import random
for nm in ("random","randint","choice","choices","getrandbits","randbytes","seed","shuffle","sample","randrange"):
    if hasattr(random,nm):
        o=getattr(random,nm)
        def mk(o,nm):
            def w(*a,**k):
                r=o(*a,**k); rec("RND",{"fn":nm,"args":[s(x) for x in a],"ret":s(r)}); return r
            return w
        setattr(random,nm,mk(o,nm))
import wxautox4.utils.useful as u
for nm in ("wa","fa","fp","pp","pu","wp","na","nc","wa","vces","cea","ghi","chlc","its","sti","iacve","inlec","nkecl","nkecl2","nismce"):
    fn=getattr(u,nm,None)
    if callable(fn):
        def mk(fn,nm):
            def w(*a,**k):
                r=fn(*a,**k); rec("FC",{"fn":nm,"args":[s(x) for x in a],"ret":s(r)}); return r
            return w
        try: setattr(u,nm,mk(fn,nm))
        except: pass
try:
    r=u.authenticate("TEST-DUMMY-CODE")
    rec("TOP",{"ret":s(r)})
except BaseException as e:
    rec("TOP",{"err":"%s: %s"%(type(e).__name__,e)})
with io.open(os.path.join("artifacts","full_trace.json"),"w",encoding="utf-8") as f:
    json.dump(LOG,f,ensure_ascii=False,indent=1,default=str)
print("events",len(LOG))
