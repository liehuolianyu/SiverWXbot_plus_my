# -*- coding: utf-8 -*-
"""检查自身与微信进程是否以管理员(elevated)运行"""
import ctypes
import ctypes.wintypes as w
import os
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
TOKEN_QUERY = 0x0008
TokenElevation = 20

k32 = ctypes.windll.kernel32
adv = ctypes.windll.advapi32


def is_elevated(pid):
    h = k32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
    if not h:
        return "OpenProcess failed err=%d" % ctypes.get_last_error()
    try:
        tok = w.HANDLE()
        if not adv.OpenProcessToken(h, TOKEN_QUERY, ctypes.byref(tok)):
            return "OpenProcessToken failed err=%d" % ctypes.get_last_error()
        try:
            val = ctypes.c_int(0)
            ret = ctypes.c_int(0)
            ok = adv.GetTokenInformation(tok, TokenElevation, ctypes.byref(val),
                                         ctypes.sizeof(val), ctypes.byref(ret))
            if not ok:
                return "GetTokenInformation failed err=%d" % ctypes.get_last_error()
            return "ELEVATED" if val.value else "NOT elevated"
        finally:
            k32.CloseHandle(tok)
    finally:
        k32.CloseHandle(h)


import psutil

me = os.getpid()
print("self pid=%d -> %s" % (me, is_elevated(me)))
print("IsUserAnAdmin():", bool(ctypes.windll.shell32.IsUserAnAdmin()))

for p in psutil.process_iter(["pid", "name"]):
    if p.info["name"] and p.info["name"].lower() == "weixin.exe":
        print("Weixin.exe pid=%-6d -> %s" % (p.info["pid"], is_elevated(p.info["pid"])))

print("\nSessionId:")
print("  self :", psutil.Process(me).terminal or "-", "session",
      ctypes.c_ulong(0).value if False else psutil.Process(me).pid)
for p in psutil.process_iter(["pid", "name"]):
    if p.info["name"] and p.info["name"].lower() == "weixin.exe":
        try:
            import win32ts
        except Exception:
            win32ts = None
        break
