# -*- coding: utf-8 -*-
"""端到端集成测试：完全按 SiverWXbot_plus 启动路径走一遍自愈 + 连接。

路径：wxbot_core._load_wxautox4_prep() -> prep.prepare() -> prep.start_watchdog()
      -> WeChat() 构造 -> 读昵称 / 会话 / 消息
"""
import os
import sys
import time

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

PROJECT = r"C:\Users\Administrator\Documents\ChatGPT\live2D\_wxautox4_probe\SiverWXbot_plus"
sys.path.insert(0, PROJECT)

print("=" * 66)
print("[1] 按机器人启动路径加载自愈模块")
import wxbot_core
prep = wxbot_core._load_wxautox4_prep()
print("    _load_wxautox4_prep() ->", prep)
assert prep is not None, "自愈模块加载失败"

print("\n[2] prepare()（补闸门 + 激活窗口 + 兼容补丁）")
out = prep.prepare(log=wxbot_core.log)
for k in ("ok", "compat", "gate_action", "hwnd", "activated", "detail"):
    print("    %-12s = %r" % (k, out.get(k)))

print("\n[3] start_watchdog()")
print("    started =", prep.start_watchdog(interval=60, log=wxbot_core.log))
print("    running =", prep.is_watchdog_running())

print("\n[4] WeChat() 构造（与 init_wx_listeners 同一路径）")
from wxautox4 import WeChat
t0 = time.time()
try:
    wx = WeChat(version='微信')
except Exception:
    wx = WeChat(version='WeChat')
print("    [OK] 构造成功，耗时 %.1fs" % (time.time() - t0))

nick = getattr(wx, "nickname", None)
print("    nickname      = %r" % (nick,))
if not nick:
    cached = prep.get_cached_nickname()
    print("    回退缓存昵称  = %r" % (cached,))
    if cached:
        try:
            wx.nickname = cached
            nick = cached
            print("    已回退赋值 OK")
        except Exception as e:
            print("    回退赋值失败：%r" % (e,))
if nick:
    print("    cache_nickname ->", prep.cache_nickname(nick))
print("    AtMe 模拟      = %r" % ("@" + (nick or ""),))

print("\n[5] 能力探测")
try:
    print("    IsOnline   =", wx.IsOnline())
except Exception as e:
    print("    IsOnline 失败:", repr(e))
try:
    sess = wx.GetSession()
    names = [getattr(s, "name", str(s)) for s in sess]
    print("    GetSession = %d -> %s" % (len(names), names[:8]))
except Exception as e:
    names = []
    print("    GetSession 失败:", repr(e))
try:
    print("    GetMyInfo  = %r" % (wx.GetMyInfo(),))
except Exception as e:
    print("    GetMyInfo 失败:", repr(e))

if names:
    print("\n[6] 读消息（%s）" % names[0])
    try:
        wx.ChatWith(names[0])
        time.sleep(1.0)
        msgs = wx.GetAllMessage()
        print("    读到 %d 条消息" % len(msgs))
        for m in msgs[-3:]:
            print("      attr=%-8r sender=%-14r %r"
                  % (getattr(m, "attr", None), getattr(m, "sender", None),
                     str(getattr(m, "content", ""))[:34]))
    except Exception as e:
        print("    读消息异常:", repr(e))

print("\n[7] 收尾")
prep.stop_watchdog()
print("    watchdog 已停止:", not prep.is_watchdog_running())
print("\n" + "=" * 66)
print("集成测试结论：%s" % ("通过 ✔" if (out.get("ok") and nick) else "需检查"))
print("=" * 66)
