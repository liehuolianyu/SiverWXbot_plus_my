# -*- coding: utf-8 -*-
"""微信 4.x UIA 无障碍闸门 —— 开关工具（全部可逆，不改微信任何文件）

原理：微信 4.x 是自绘 UI，Qt 只在「启动时」检测到无障碍客户端才构建完整控件树
（`mmui::MainWindow` 等）。未激活时 UIA 只能看到 Qt 空壳窗口，
wxautox4 的 `mmui::MainWindow` 校验失败 → 报「未找到已登录的客户端主窗口」。

用法：
    python fix_uia_gate.py status    # 看当前状态（只读）
    python fix_uia_gate.py on        # 打开两个开关（需随后重启微信生效）
    python fix_uia_gate.py off       # 全部还原
    python fix_uia_gate.py verify    # 检查 mmui 树是否已物化

开关明细：
    1) 环境变量 QT_ACCESSIBILITY=1  (用户级持久，Qt 官方认可的强制启用开关)
    2) 系统标志 SPI_SETSCREENREADER=1 (注册表持久；声明"存在屏幕阅读器")
"""
import ctypes
import ctypes.wintypes as wt
import os
import subprocess
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

SPI_GETSCREENREADER = 0x0046
SPI_SETSCREENREADER = 0x0047
SPIF_UPDATEINIFILE = 0x01
SPIF_SENDCHANGE = 0x02
u = ctypes.windll.user32


def get_screenreader():
    v = ctypes.c_int(0)
    u.SystemParametersInfoW(SPI_GETSCREENREADER, 0, ctypes.byref(v), 0)
    return v.value


def set_screenreader(val):
    return bool(u.SystemParametersInfoW(
        SPI_SETSCREENREADER, 1 if val else 0, None,
        SPIF_UPDATEINIFILE | SPIF_SENDCHANGE))


def get_qt_accessibility():
    """读用户级持久环境变量（注册表值，非当前进程）"""
    import winreg
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment") as k:
            for i in range(winreg.QueryInfoKey(k)[1]):
                n, v, _ = winreg.EnumValue(k, i)
                if n.upper() == "QT_ACCESSIBILITY":
                    return v
    except FileNotFoundError:
        pass
    return None


def set_qt_accessibility(val):
    import winreg
    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment", 0,
                        winreg.KEY_SET_VALUE) as k:
        if val is None:
            try:
                winreg.DeleteValue(k, "QT_ACCESSIBILITY")
            except FileNotFoundError:
                pass
        else:
            winreg.SetValueEx(k, "QT_ACCESSIBILITY", 0, winreg.REG_SZ, val)
    # 广播环境变量变更，让新启动的进程看到
    HWND_BROADCAST = 0xFFFF
    WM_SETTINGCHANGE = 0x001A
    u.SendMessageTimeoutW(HWND_BROADCAST, WM_SETTINGCHANGE, 0,
                          ctypes.c_wchar_p("Environment"), 0x0002, 5000,
                          ctypes.byref(ctypes.c_ulong()))


def probe_mmui():
    """返回 (后代总数, mmui:: 元素数)；None 表示没找到微信窗口"""
    from comtypes.client import CreateObject, GetModule
    GetModule("UIAutomationCore.dll")
    from comtypes.gen import UIAutomationClient as UIA
    uia = CreateObject(UIA.CUIAutomation)
    root = uia.GetRootElement()
    walker = uia.CreateTreeWalker(uia.RawViewCondition)
    el = walker.GetFirstChildElement(root)
    target = None
    while el:
        try:
            if el.CurrentClassName == "Qt51514QWindowIcon" and el.CurrentName == "微信":
                target = el
                break
        except Exception:
            pass
        el = walker.GetNextSiblingElement(el)
    if target is None:
        return None
    n_all = n_mmui = 0
    stack = [target]
    while stack:
        e = stack.pop()
        c = walker.GetFirstChildElement(e)
        while c:
            n_all += 1
            try:
                if (c.CurrentClassName or "").startswith("mmui::"):
                    n_mmui += 1
            except Exception:
                pass
            if n_all < 600:
                stack.append(c)
            c = walker.GetNextSiblingElement(c)
    return n_all, n_mmui


def wechat_running():
    import psutil
    return [p.info["pid"] for p in psutil.process_iter(["pid", "name"])
            if p.info["name"] and p.info["name"].lower() == "weixin.exe"]


def cmd_status():
    print("=" * 62)
    print("微信 UIA 闸门状态")
    print("=" * 62)
    print("  QT_ACCESSIBILITY (用户级持久) :", repr(get_qt_accessibility()))
    print("  SPI_GETSCREENREADER (系统标志) :", get_screenreader())
    pids = wechat_running()
    print("  微信进程                      :", pids or "未运行")
    r = probe_mmui()
    if r is None:
        print("  mmui 树                       : 未找到微信主窗口")
        return
    n_all, n_mmui = r
    print("  UIA 后代 / mmui:: 元素        : %d / %d  -> %s"
          % (n_all, n_mmui, "闸门已激活 ✔" if n_mmui else "闸门未激活 ✘"))
    if not n_mmui:
        print("\n  提示：两个开关都打开后，必须【完全退出并重新启动微信】才会生效")
        print("        （闸门状态只在微信启动时读取一次）")


def cmd_on():
    print("开启开关 ...")
    print("  [1] QT_ACCESSIBILITY=1  ->", end=" ")
    set_qt_accessibility("1")
    print(repr(get_qt_accessibility()))
    print("  [2] SPI_SETSCREENREADER ->", end=" ")
    ok = set_screenreader(1)
    print("%s (现在=%s)" % ("ok" if ok else "失败", get_screenreader()))
    print("\n下一步：完全退出微信（托盘右键→退出，不是关窗口）后重新启动。")
    print("然后运行:  python fix_uia_gate.py verify")


def cmd_off():
    print("还原 ...")
    set_qt_accessibility(None)
    set_screenreader(0)
    print("  QT_ACCESSIBILITY          =", repr(get_qt_accessibility()))
    print("  SPI_GETSCREENREADER       =", get_screenreader())


def cmd_verify():
    r = probe_mmui()
    if r is None:
        print("未找到微信主窗口（微信没开？）")
        return 1
    n_all, n_mmui = r
    print("UIA 后代 = %d，mmui:: 元素 = %d" % (n_all, n_mmui))
    if n_mmui:
        print("闸门已激活 ✔  现在可以跑 test_wxautox4_min.py")
        return 0
    print("闸门仍未激活 ✘")
    return 1


if __name__ == "__main__":
    cmd = (sys.argv[1] if len(sys.argv) > 1 else "status").lower()
    fn = {"status": cmd_status, "on": cmd_on, "off": cmd_off, "verify": cmd_verify}.get(cmd)
    if fn is None:
        print(__doc__)
        raise SystemExit(2)
    raise SystemExit(fn() or 0)
