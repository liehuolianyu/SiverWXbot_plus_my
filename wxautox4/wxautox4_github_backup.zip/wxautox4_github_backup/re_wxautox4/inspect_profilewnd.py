# -*- coding: utf-8 -*-
"""调查 ProfileWnd.topui"""
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

import wxautox4.ui.main as M

cls = getattr(M, "ProfileWnd", None)
print("ProfileWnd:", cls)
print("MRO:")
for c in cls.__mro__:
    print("   ", c.__module__, c.__name__)
print("\n类自身属性:")
for n in sorted(vars(cls)):
    if not n.startswith("__"):
        v = vars(cls)[n]
        print("    %-22s %s" % (n, type(v).__name__))
print("\n是否有 topui:", hasattr(cls, "topui"))

# 找相关类
for name in ("WeChatSubWnd", "BaseWnd", "WeChatMainWnd", "ProfileWnd"):
    c = getattr(M, name, None)
    if c is None:
        continue
    print("\n== %s ==" % name)
    print("   topui in vars:", "topui" in vars(c))
    own = [n for n in vars(c) if not n.startswith("__")]
    print("   属性:", own[:40])
