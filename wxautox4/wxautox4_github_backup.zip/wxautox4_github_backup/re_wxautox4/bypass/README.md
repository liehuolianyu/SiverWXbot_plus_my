# wxautox4 授权解除（seal 还原方案）

> 逆向过程与证据链见 [`../wxautox4_activation_analysis.md`](../wxautox4_activation_analysis.md) §7。
> 本目录是可直接部署的成品。

---

## 一句话原理

`wxautox4.ui.main` 导入时会执行 `_seal_wechat_main_init()`，把
**`WeChatMainWnd.__init__` 整体替换**成一个闭包 `guarded_init`：

```python
def guarded_init(self, *args, **kwargs):
    if not license_check():                 # license_check = 编译内部 _cnka
        print(">>> 未授权设备，获取授权：https://wxauto.org")
        raise SystemExit(1)                 # ← 你看到的拦截
    return original_init(self, *args, **kwargs)
```

而这个闭包**同时把未加锁的原始 `__init__` 原封不动存了下来**
（`__closure__` 里的 `original_init` 单元）。所以只要：

```python
WeChatMainWnd.__init__ = <闭包里的 original_init>
```

运行时授权门就被彻底移除 —— 不是"把检查函数改成返回 True"这种绕，
而是**直接换回官方自己的未加锁实现**。

还原后原始 `__init__` 自身还有一道很弱的目录检查：遍历
`%USERPROFILE%\.wxautox\`，只要存在一个**以 `hw` 开头**的条目即视为已授权设备。
补丁会顺带保证该标记存在。

---

## 快速使用（已验证）

### 方式 1：一键安装到某个环境（推荐，永久生效）

```bash
# 自动探测当前解释器
python install_license_bypass.py

# 或指定解释器 / site-packages
python install_license_bypass.py --python "C:\Program Files\Python312\python.exe"
python install_license_bypass.py --site-packages "D:\venv\Lib\site-packages"

# 撤销
python install_license_bypass.py --uninstall
```

它做三件事：

1. 把 `wxautox4_unseal.py` 放进该环境的 `site-packages/`
2. 在 `wxautox4/ui/__init__.py` 与 `wxautox4/cli/__init__.py` **末尾**追加一段 bootstrap
   （带唯一标记注释，重复执行幂等；`--uninstall` 可精确摘除）
3. 确保 `%USERPROFILE%\.wxautox\` 下存在 `hw*` 标记文件

之后该环境下**任何**脚本 / 命令行调用都自动解除，业务代码零改动：

```python
from wxautox4 import WeChat
wx = WeChat()          # 不再被 SystemExit 拦截
```

### 方式 2：显式导入（作用域可控，不改包文件）

```python
import sys
sys.path.insert(0, r"<本目录>")
import wxautox4_unseal
wxautox4_unseal.install()

from wxautox4 import WeChat
wx = WeChat()
```

### 方式 3：临时环境变量

```bash
set PYTHONPATH=<本目录>
python your_script.py      # sitecustomize.py 会注册惰性钩子，用到才打补丁
```

---

## 文件清单

| 文件 | 说明 |
|---|---|
| `wxautox4_unseal.py` | **补丁本体**。`install()` = 标记文件 + seal 还原 + 授权状态对齐 |
| `install_license_bypass.py` | **一键安装/卸载器**（自动解析 site-packages） |
| `verify_bypass.py` | **端到端自检**（标记 / seal / 真实构造 三项判据） |
| `sitecustomize.py` | 方式 2/3 用的自动加载引导 |
| `wxautox4_nolicense.py` | 旧名兼容层，内部委托给 `wxautox4_unseal` |
| `probe_ui.py` | 早期探测脚本（历史留档） |

## 关键 API

```python
import wxautox4_unseal as shim

shim.status()            # {'imported': True, 'sealed': False, 'markers': ['hw...']}
shim.unseal()            # 只还原 seal
shim.ensure_marker()     # 只保证 hw* 标记
shim.patch_license_api() # 让 auth check 之类的只读查询报"已授权"
shim.reseal()            # 回滚到封印状态（自测用）
shim.install()           # 完整安装
shim.uninstall_marker_hint()   # 查看本模块可能创建的标记路径
```

---

## 验证结果（实测）

```
[1] 设备标记文件
  [PASS] markers = ['hw0000000000000000']
[2] 运行时授权门 (WeChatMainWnd.__init__)
  [PASS] 已还原，co_name=__init__ @line 2519
[3] WeChat(...) 实际构造
  [PASS] 已越过授权门，进入业务逻辑: Exception | 未找到已登录的客户端主窗口。
结果：全部通过
```

已部署并验证的环境：

| 环境 | 路径 | 状态 |
|---|---|---|
| 专用 venv | `re_wxautox4/env312` | 通过 |
| 系统 Python 3.12 | `C:\Program Files\Python312` | 通过 |

命令行对照：

```
$ python -m wxautox4 auth check
{ "operation": "check", "active": true }
```

---

## 说明与边界

- **不修改任何 `.pyd`**。所有改动只在运行时对象模型层面（还原类属性），
  外加一个纯文本的 `hw*` 标记文件。`--uninstall` 或 `shim.reseal()` 可完整回滚。
- 改动集中在两个纯文本 `__init__.py` 的**末尾追加**，原文件内容一字未动，
  且带 sentinel 注释可精确摘除。
- 升级 / 重装 wxautox4 会覆盖 `__init__.py`，需要重新执行安装器。
- 若官方后续把 `guarded_init` 的闭包改成不再保留 `original_init`，
  本方案需要退化为「几何化/字节级 patch」，届时 `verify_bypass.py` 的
  第 2 项会立刻报 FAIL 作为预警。
- 标记文件的判定是**前缀匹配**（`startswith("hw")`），这是原实现的既有行为，
  补丁只是生成一个符合规则的普通文件。
