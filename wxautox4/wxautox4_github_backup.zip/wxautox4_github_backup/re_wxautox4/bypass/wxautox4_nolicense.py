# -*- coding: utf-8 -*-
"""兼容层：旧名称 `wxautox4_nolicense` 保留，内部委托给正确实现。

注意
----
早期版本的 `wxautox4_nolicense` 只替换了 `wxautox4.utils.useful` 的
`check_license` / `chlc` 等**模块属性**。后续实测证明：真正的运行时授权门
是 `wxautox4.ui.main.WeChatMainWnd.__init__`（被 `_seal_wechat_main_init`
封印过的闭包 `guarded_init`），它**不经过**这些模块属性，因此那种做法
只能骗过 CLI 的 `auth check`，不能放行 `WeChat()`。

正确做法见 `wxautox4_unseal`。本模块仅为向后兼容而保留。
"""
from wxautox4_unseal import (  # noqa: F401
    MARKER_PREFIX,
    unseal,
    ensure_marker,
    patch_license_api,
    install,
    install_lazy,
    status,
)

__all__ = [
    "MARKER_PREFIX",
    "unseal",
    "ensure_marker",
    "patch_license_api",
    "install",
    "install_lazy",
    "status",
]

# 导入即生效（与旧版行为保持一致）
install()
