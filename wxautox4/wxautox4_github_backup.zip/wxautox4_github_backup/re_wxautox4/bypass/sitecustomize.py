# -*- coding: utf-8 -*-
"""自动加载引导（供 PYTHONPATH / site-packages 使用）。

方式 A（推荐，永久生效）：运行 `install_license_bypass.py`，它会把
    - `wxautox4_unseal.py`  放进 site-packages
    - 一段 bootstrap 追加到 `wxautox4/ui/__init__.py` 与 `wxautox4/cli/__init__.py`
该环境下**任何**导入 wxautox4 的脚本都会自动解除授权门，业务代码零改动。

方式 B（临时，作用于单次运行）：把本目录加入 PYTHONPATH 即可，本文件会在
解释器启动时注册一个惰性导入钩子 —— 只有真正用到 wxautox4 时才打补丁，
对无关进程零开销。
"""
import os
import sys

_here = os.path.dirname(os.path.abspath(__file__))
if _here not in sys.path:
    sys.path.insert(0, _here)

try:
    import wxautox4_unseal

    wxautox4_unseal.install_lazy()
except Exception as exc:  # 绝不能因为补丁失败而影响解释器启动
    sys.stderr.write("[wxautox4 bypass] skipped: %r\n" % (exc,))
