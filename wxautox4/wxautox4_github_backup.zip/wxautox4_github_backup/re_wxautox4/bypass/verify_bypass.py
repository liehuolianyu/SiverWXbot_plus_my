# -*- coding: utf-8 -*-
"""wxautox4 授权解除 —— 端到端自检

    python verify_bypass.py

判据：
  1. `~/.wxautox/` 下存在 hw* 标记文件
  2. `WeChatMainWnd.__init__` 已还原为未加锁实现（未被 seal）
  3. `WeChat(...)` 不再被授权门 SystemExit 拦截
     —— 期望得到「未找到已登录的客户端主窗口」这类**业务**错误
"""
import json
import sys
import traceback

FAIL = 0


def _ok(msg):
    print("  [PASS] %s" % msg)


def _bad(msg):
    global FAIL
    FAIL += 1
    print("  [FAIL] %s" % msg)


def main():
    print("=" * 62)
    print("wxautox4 授权解除自检")
    print("=" * 62)

    # 1) 标记文件
    print("\n[1] 设备标记文件")
    try:
        import wxautox4_unseal as shim
        marker_ok = shim.ensure_marker()
        st = shim.status()
        if marker_ok and st.get("markers"):
            _ok("markers = %s" % st["markers"])
        else:
            _bad("未能创建/找到 hw* 标记文件")
    except Exception as exc:
        _bad("导入 wxautox4_unseal 失败: %r" % (exc,))

    # 2) seal 状态
    print("\n[2] 运行时授权门 (WeChatMainWnd.__init__)")
    try:
        import wxautox4.ui.main as M
        init = M.WeChatMainWnd.__init__
        code = getattr(init, "__code__", None)
        name = getattr(code, "co_name", None)
        if name == "guarded_init":
            _bad("仍处于封印状态（guarded_init）")
        else:
            _ok("已还原，co_name=%s @line %s" % (name, getattr(code, "co_firstlineno", None)))
    except Exception as exc:
        _bad("导入 wxautox4.ui.main 失败: %r" % (exc,))

    # 3) 真实构造
    print("\n[3] WeChat(...) 实际构造")
    try:
        from wxautox4.wx import WeChat
        try:
            w = WeChat(nickname="__verify__")
            _ok("构造成功: %r" % (w,))
        except SystemExit:
            _bad("仍被授权门 SystemExit 拦截")
        except BaseException as exc:
            text = str(exc)
            if "未授权设备" in text:
                _bad("仍返回授权错误: %s" % text[:80])
            else:
                _ok("已越过授权门，进入业务逻辑: %s | %s"
                    % (type(exc).__name__, text.splitlines()[0][:60] if text else ""))
    except Exception as exc:
        _bad("导入 wxautox4.wx 失败: %r" % (exc,))
        traceback.print_exc()

    print("\n" + "=" * 62)
    print("结果：%s" % ("全部通过" if FAIL == 0 else "%d 项未通过" % FAIL))
    print("=" * 62)
    return 1 if FAIL else 0


if __name__ == "__main__":
    raise SystemExit(main())
