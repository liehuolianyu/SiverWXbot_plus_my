# -*- coding: utf-8 -*-
import os, sys, inspect
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import wxautox4_nolicense
import importlib
m = importlib.import_module("wxautox4.ui.main")
names = [n for n in dir(m) if any(k in n.lower() for k in ("lic","auth","check","nka","valid"))]
print("ui.main license-ish attrs:", names)
for n in names:
    o = getattr(m, n)
    try:
        print(" ", n, inspect.signature(o) if callable(o) else repr(o)[:80])
    except Exception as e:
        print(" ", n, "<%s>" % type(o).__name__)
# find the gate the UI calls
import wxautox4.utils.useful as u
print("useful.check_license is patched:", u.check_license())
for cand in ("_check_license","check_license","ensure_license","_ensure_license","verify_license","nka"):
    if hasattr(m, cand):
        try:
            print("call", cand, "->", getattr(m, cand)())
        except Exception as e:
            print("call", cand, "ERR", type(e).__name__, e)
