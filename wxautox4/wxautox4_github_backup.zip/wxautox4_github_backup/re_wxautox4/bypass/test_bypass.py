# -*- coding: utf-8 -*-
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__))))
import wxautox4_nolicense        # installs the patch before anything else
import wxautox4.utils.useful as u
print("check_license() ->", u.check_license())
print("chlc() ->", u.chlc())
import wxautox4
print("pkg authenticate ->", wxautox4.authenticate("ANY"))
from wxautox4.cli import main as cli_main
print("--- cli auth check ---")
sys.argv = ["wxautox4", "auth", "check"]
try:
    cli_main()
except SystemExit as e:
    print("exit", e.code)
