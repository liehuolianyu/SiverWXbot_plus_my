# -*- coding: utf-8 -*-
"""Dump Nuitka-compiled module constants and structure.

Target: wxautox4.utils.useful / wxautox4.cli.main
Purpose: recover embedded string/bytes/int constants (SERVURL, license paths,
         crypto parameters) that are invisible in the raw PE string table.
"""
import io
import json
import os
import sys

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "artifacts")
os.makedirs(OUT, exist_ok=True)

results = {"modules": {}, "errors": []}


def safe(fn, default=None):
    try:
        return fn()
    except BaseException as e:  # noqa
        return "<%s: %s>" % (type(e).__name__, e)


def describe(v):
    t = type(v).__name__
    if isinstance(v, (str, int, float, bool, type(None))):
        return {"t": t, "v": v}
    if isinstance(v, (bytes, bytearray)):
        return {"t": t, "hex": bytes(v).hex(), "len": len(v)}
    if isinstance(v, (list, tuple, set, frozenset)):
        return {"t": t, "n": len(v), "items": [describe(x) for x in list(v)[:200]]}
    if isinstance(v, dict):
        return {"t": t, "n": len(v),
                "items": [[describe(k), describe(x)] for k, x in list(v.items())[:200]]}
    return {"t": t, "repr": safe(lambda: repr(v))}


def dump_module(modname):
    info = {"name": modname, "attrs": [], "constants": None, "funcs": []}
    try:
        mod = __import__(modname, fromlist=["*"])
    except BaseException as e:
        results["errors"].append({"module": modname, "import": "%s: %s" % (type(e).__name__, e)})
        return info

    info["file"] = str(safe(lambda: mod.__file__))

    # Nuitka constant table
    for cname in ("__constants", "__module_constants", "_constants"):
        c = getattr(mod, cname, None)
        if c is not None:
            d = {}
            try:
                items = c.items() if hasattr(c, "items") else []
            except BaseException:
                items = []
            for k, v in list(items):
                d[str(k)] = describe(v)
            info["constants"] = {"attr": cname, "n": len(d), "data": d}
            break

    # full attribute listing
    names = safe(lambda: sorted(dir(mod)), [])
    for n in names:
        obj = safe(lambda: getattr(mod, n))
        entry = {"name": n, "type": type(obj).__name__}
        if isinstance(obj, (str, int, float, bool, bytes, type(None))):
            entry["value"] = describe(obj)
        if callable(obj):
            entry["sig"] = safe(lambda: str(__import__("inspect").signature(obj)))
            entry["qualname"] = str(safe(lambda: obj.__qualname__))
            entry["doc"] = str(safe(lambda: obj.__doc__))[:400]
            info["funcs"].append(entry)
        info["attrs"].append(entry)

    return info


for m in ("wxautox4", "wxautox4.utils.useful", "wxautox4.utils.tools",
          "wxautox4.utils.win32", "wxautox4.cli.main"):
    results["modules"][m] = dump_module(m)

with io.open(os.path.join(OUT, "module_dump.json"), "w", encoding="utf-8") as f:
    json.dump(results, f, ensure_ascii=False, indent=1, default=str)

# console summary
for m, info in results["modules"].items():
    print("=" * 70)
    print("MODULE", m, "file=", info.get("file"))
    c = info.get("constants")
    if c:
        print("  constants attr=%s n=%d" % (c["attr"], c["n"]))
        for k, v in c["data"].items():
            s = json.dumps(v, ensure_ascii=False)[:300]
            print("    %-28s %s" % (k, s))
    else:
        print("  no constant table exposed")
    print("  -- exports --")
    for f in info["funcs"]:
        if not f["name"].startswith("__"):
            print("    %-30s %s" % (f["name"], f.get("sig")))
print("=" * 70)
print("errors:", json.dumps(results["errors"], ensure_ascii=False)[:2000])
