# -*- coding: utf-8 -*-
"""Recover the printable 'armor' codec and the embedded client keypair.

Known from the trace:
  R_json = wa(json_payload, server_pub)   -> 256 bytes (RSA-2048)
  R_key  = wa(aes_key,      server_pub)   -> 256 bytes
  S      = the 'data' string actually posted
Goal: find codec(S) == R_json + R_key  (or similar), and check the client key.
"""
import json
import io
import os
import itertools

HERE = os.path.dirname(os.path.abspath(__file__))
tr = json.load(io.open(os.path.join(HERE, "artifacts", "full_trace.json"), encoding="utf-8"))

http = []
for e in tr:
    if e["t"] == "HTTP":
        http.append(e["d"])
    if e["t"] == "RESP":
        pass

S_act = http[0]["json"]["data"]
S_nt = http[1]["json"]["data"]
print("activate data len:", len(S_act))
print("nt data len:", len(S_nt))
print("activate chars min/max:", min(S_act), max(S_act), ord(min(S_act)), ord(max(S_act)))
print("distinct chars:", len(set(S_act)))

# collect RSA outputs (wa returns)
wa_out = []
for e in tr:
    if e["t"] == "FC" and e["d"].get("fn") == "wa" and "ret" in e["d"]:
        r = e["d"]["ret"]
        if r.startswith("B:"):
            b = bytes.fromhex(r[2:])
            if not wa_out or wa_out[-1] != b:
                wa_out.append(b)
print("unique wa outputs:", [(len(x), x[:8].hex()) for x in wa_out])

# also pp outputs
pp_out = []
for e in tr:
    if e["t"] == "FC" and e["d"].get("fn") == "pp" and "ret" in e["d"]:
        pp_out.append(bytes.fromhex(e["d"]["ret"][2:]))
print("pp outputs:", [(len(x), x[:6].hex()) for x in pp_out])

# print the plaintexts recovered by pu (unpad)
for e in tr:
    if e["t"] == "FC" and e["d"].get("fn") == "pu" and "ret" in e["d"]:
        try:
            print("PU plaintext:", bytes.fromhex(e["d"]["ret"][2:]))
        except Exception as ex:
            print("PU raw:", e["d"]["ret"][:120])

# ---- try to crack armor ----
def try_decodings(S, blob):
    """see if any simple mapping turns S into blob"""
    out = []
    # 1) identity ord mapping
    b = bytes(ord(c) for c in S)
    if b == blob:
        out.append("ord-identity")
    # 2) base94 with alphabet printable 0x21..0x7e
    import math
    def b94dec(s, alpha):
        n = 0
        for ch in s:
            i = alpha.index(ch)
            n = n * len(alpha) + i
        ln = (n.bit_length() + 7) // 8
        return n.to_bytes(ln, "big")
    alpha = "".join(chr(i) for i in range(33, 127))
    try:
        d = b94dec(S, alpha)
        if blob in d or d in blob or len(d) == len(blob):
            out.append(("b94-33-126", len(d), d[:16].hex()))
    except Exception as ex:
        out.append(("b94-33-126-err", str(ex)))
    return out


for name, S in (("activate", S_act), ("nt", S_nt)):
    print("\n---", name, "---")
    for cand in wa_out:
        print("  vs wa(256B):", try_decodings(S, cand))

# ---- client key check ----
for e in tr:
    if e["t"] == "FC" and e["d"].get("fn") in ("fp",) and e["d"].get("args"):
        key = e["d"]["args"][1]
        key = key.strip("()")
        parts = [p.strip() for p in key.split(",")]
        print("\nclient key tuple arity:", len(parts))
        try:
            vals = [int(p) for p in parts]
            print("  bits:", [v.bit_length() for v in vals])
            for i, v in enumerate(vals):
                print("  [%d] %d" % (i, v))
        except Exception as ex:
            print("  parse err:", ex, key[:200])
        break
