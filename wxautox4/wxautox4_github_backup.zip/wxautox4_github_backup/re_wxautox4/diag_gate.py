# -*- coding: utf-8 -*-
"""定位闸门未激活的原因：前台化 / WM_GETOBJECT 握手 / 是否有真实读屏客户端"""
import ctypes
import ctypes.wintypes as wt
import sys
import time

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

sys.path.insert(0, r"C:\Users\Administrator\WorkBuddy\2026-10-14-16-19-40\re_wxautox4")
from fix_uia_gate import probe_mmui  # noqa: E402

print("[0] 当前:", probe_mmui())

# 找主窗口 hwnd
u = ctypes.windll.user32
u.GetClassNameW.argtypes = [wt.HWND, wt.LPWSTR, ctypes.c_int]
u.GetWindowTextW.argtypes = [wt.HWND, wt.LPWSTR, ctypes.c_int]
CB = ctypes.WINFUNCTYPE(ctypes.c_bool, wt.HWND, wt.LPARAM)
state = {"hwnd": 0, "pid": 0}


def cb(h, l):
    b = ctypes.create_unicode_buffer(128)
    u.GetClassNameW(h, b, 128)
    if b.value == "Qt51514QWindowIcon":
        t = ctypes.create_unicode_buffer(128)
        u.GetWindowTextW(h, t, 128)
        if t.value == "微信":
            state["hwnd"] = h
            pid = wt.DWORD()
            u.GetWindowThreadProcessId(h, ctypes.byref(pid))
            state["pid"] = pid.value
            return False
    return True


if not u.EnumWindows(CB(cb), 0) and state["hwnd"] == 0:
    print("未找到微信主窗口")
    raise SystemExit(1)
hwnd = state["hwnd"]
print("[1] 主窗口 hwnd=0x%08X pid=%d" % (hwnd, state["pid"]))

# A. 前台化
print("\n[A] 尝试把微信窗口置前台 ...")
u.ShowWindow(hwnd, 9)                     # SW_RESTORE
u.SetForegroundWindow(hwnd)
time.sleep(1.5)
print("    IsIconic=%s  Foreground=0x%08X" % (bool(u.IsIconic(hwnd)), u.GetForegroundWindow()))
print("    探测:", probe_mmui())

# B. 手工发 WM_GETOBJECT(UiaRootObjectId)
print("\n[B] 手工发 WM_GETOBJECT(lParam=UiaRootObjectId) ...")
WM_GETOBJECT = 0x003D
UiaRootObjectId = -25
r = u.SendMessageW(hwnd, WM_GETOBJECT, 0, UiaRootObjectId)
print("    SendMessage 返回:", r)
time.sleep(1.5)
print("    探测:", probe_mmui())

# C. 是否有真实读屏客户端在跑
print("\n[C] 检查读屏/无障碍客户端进程 ...")
import psutil
want = ("narrator", "nvda", "jaws", "inspect", "accessibility", "zdsr", "reader")
hits = []
for p in psutil.process_iter(["pid", "name"]):
    n = (p.info["name"] or "").lower()
    if any(w in n for w in want):
        hits.append((p.info["pid"], p.info["name"]))
print("    命中:", hits or "无")

# D. 微信自己的无障碍相关注册表/配置
print("\n[D] 系统读屏标志:", end=" ")
v = ctypes.c_int(0)
u.SystemParametersInfoW(0x0046, 0, ctypes.byref(v), 0)
print(v.value)
