# -*- coding: utf-8 -*-
"""枚举当前微信 UIA 树里所有 mmui:: 类名（确认资料卡元素的新名字）"""
import sys
from collections import Counter

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

sys.path.insert(0, r"C:\Users\Administrator\WorkBuddy\2026-10-14-16-19-40\re_wxautox4")
from wxautox4.uia import uiautomation as auto

names = Counter()
examples = {}
total = [0]


def walk(ctrl, depth):
    if depth > 14:
        return
    try:
        kids = ctrl.GetChildren()
    except Exception:
        return
    for k in kids:
        try:
            cls = k.ClassName or ""
            nm = k.Name or ""
        except Exception:
            continue
        total[0] += 1
        if cls:
            names[cls] += 1
            if cls not in examples:
                examples[cls] = nm[:60]
        walk(k, depth + 1)


root = auto.GetRootControl()
# 顶层窗口
for w in root.GetChildren():
    try:
        cls = w.ClassName or ""
        nm = w.Name or ""
    except Exception:
        continue
    print("TOP hwnd=%s cls=%r name=%r" % (w.NativeWindowHandle, cls, nm))
    if cls.startswith("mmui::") or "微信" in nm or "WeChat" in nm:
        names[cls + "  <TOP>"] += 1
        examples[cls + "  <TOP>"] = nm[:60]
        walk(w, 0)

print("\n共遍历元素: %d" % total[0])
print("\n出现的类名（计数 / 示例名称）：")
for cls, cnt in names.most_common(60):
    print("  %-46s %4d   %s" % (cls, cnt, examples.get(cls, "")[:50]))
