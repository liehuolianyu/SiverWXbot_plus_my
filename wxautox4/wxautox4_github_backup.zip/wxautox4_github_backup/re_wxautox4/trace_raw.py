# -*- coding: utf-8 -*-
import io,json,os
CAP={"http":[],"wp":[],"fp":[],"pu":[],"pp":[],"fa":[],"wa":[]}
import requests
_o=requests.Session.request
def pr(self,method,url,**kw):
    CAP["http"].append({"m":method,"url":url,"json":kw.get("json")})
    r=_o(self,method,url,**kw); CAP["http"].append({"url":url,"resp":r.text}); return r
requests.Session.request=pr
import wxautox4.utils.useful as u
for nm in ("wp","fp","pu","pp","fa","wa"):
    fn=getattr(u,nm,None)
    if not callable(fn): continue
    def mk(fn,nm):
        def w(*a,**k):
            try: CAP[nm].append({"args":[ (x.hex() if isinstance(x,(bytes,bytearray)) else x) for x in a]})
            except Exception as e: CAP[nm].append({"err":str(e)})
            r=fn(*a,**k)
            try: CAP[nm][-1]["ret"]= (r.hex() if isinstance(r,(bytes,bytearray)) else r)
            except Exception as e: CAP[nm][-1]["ret"]="<"+str(type(r))+" "+str(e)+">"
            return r
        return w
    try: setattr(u,nm,mk(fn,nm))
    except Exception as e: print("wrap fail",nm,e)
try: res=u.authenticate("TEST-DUMMY-CODE")
except BaseException as e: res="ERR %s: %s"%(type(e).__name__,e)
CAP["result"]=str(res)
json.dump(CAP,io.open("artifacts/raw_io.json","w",encoding="utf-8"),ensure_ascii=False,indent=1,default=str)
print("ok", {k:(len(v) if isinstance(v,list) else v) for k,v in CAP.items()})
