# -*- coding: utf-8 -*-
import io, json, sys, os, functools
LOG=[]
def rec(k,d): LOG.append({"t":k,"d":d})
def s(x):
    try:
        if isinstance(x,(bytes,bytearray)): return "B:"+bytes(x).hex()[:80]
        r=repr(x)
        return r[:160]
    except Exception: return "<>"
import builtins
_bo=builtins.open
def opn(f,*a,**k):
    r=_bo(f,*a,**k); rec("open",{"path":str(f),"mode":(a[0] if a else k.get("mode"))}); return r
builtins.open=opn
import pathlib
for cls in (pathlib.Path,):
    for nm in ("read_text","read_bytes","exists","is_file","open"):
        if hasattr(cls,nm):
            o=getattr(cls,nm)
            def mk(o,nm):
                def w(self,*a,**k):
                    rec("Path."+nm,{"self":str(self)}); return o(self,*a,**k)
                return w
            setattr(cls,nm,mk(o,nm))
import wxautox4.ui.main as M
tgt=["guarded_init"]
print("ui.main has guarded_init:", hasattr(M,"guarded_init"))
for nm in dir(M):
    o=getattr(M,nm)
    if callable(o) and getattr(o,"__module__","").startswith("wxautox4"):
        def mk(o,nm):
            def w(*a,**k):
                rec("CALL",{"m":"ui.main","fn":nm,"args":[s(x) for x in a][:3]})
                try:
                    r=o(*a,**k); rec("RET",{"m":"ui.main","fn":nm,"ret":s(r)}); return r
                except BaseException as e:
                    rec("EXC",{"m":"ui.main","fn":nm,"exc":"%s: %s"%(type(e).__name__,e)}); raise
            return w
        try: setattr(M,nm,mk(o,nm))
        except Exception: pass
import wxautox4.utils.useful as U
for nm in dir(U):
    o=getattr(U,nm)
    if callable(o) and getattr(o,"__module__","").startswith("wxautox4"):
        def mk(o,nm):
            def w(*a,**k):
                rec("CALL",{"m":"useful","fn":nm,"args":[s(x) for x in a][:3]})
                try:
                    r=o(*a,**k); rec("RET",{"m":"useful","fn":nm,"ret":s(r)}); return r
                except BaseException as e:
                    rec("EXC",{"m":"useful","fn":nm,"exc":"%s: %s"%(type(e).__name__,e)}); raise
            return w
        try: setattr(U,nm,mk(o,nm))
        except Exception: pass
import wxautox4
try:
    from wxautox4.wx import WeChat
    w=WeChat(nickname="__probe__")
    rec("OK",{"w":str(w)[:100]})
except BaseException as e:
    rec("TOPEXC",{"exc":"%s: %s"%(type(e).__name__,e)})
json.dump(LOG, io.open("artifacts/chain_trace.json","w",encoding="utf-8"), ensure_ascii=False, indent=1, default=str)
print("events:",len(LOG))
for e in LOG[-60:]:
    print(e["t"], json.dumps(e["d"],ensure_ascii=False)[:200])
