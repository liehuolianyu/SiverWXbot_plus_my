# -*- coding: utf-8 -*-
import io, json, os
OUT = {}
import wxautox4.utils.useful as u
def cap(name, fn):
    try:
        r = fn()
        OUT[name] = {"ok": True, "type": type(r).__name__, "value": (r if isinstance(r,(int,float,bool,str,type(None))) else repr(r)[:400])}
    except BaseException as e:
        OUT[name] = {"ok": False, "exc": "%s: %s" % (type(e).__name__, e)}
cap("check_license", lambda: u.check_license())
cap("chlc", lambda: u.chlc())
cap("debug_license", lambda: u.debug_license())
cap("get_licence_file", lambda: u.get_licence_file())
for k in ("_prk1b","_prk2b","_puka","WXAUTOX_LICENSE","SERVURL","WXAUTOX_LICENSE_PATH"):
    if hasattr(u,k):
        v = getattr(u,k)
        OUT["attr:"+k] = {"type": type(v).__name__, "value": (v if isinstance(v,(int,float,bool,str,type(None))) else repr(v)[:200])}
try:
    import wxautox4.ui.main as m
    OUT["ui_main_has_gate"] = [n for n in dir(m) if "lic" in n.lower() or "auth" in n.lower()]
except BaseException as e:
    OUT["ui_main_has_gate"] = "ERR %s" % e
json.dump(OUT, io.open("artifacts/real_license_shape.json","w",encoding="utf-8"), ensure_ascii=False, indent=1, default=str)
print(json.dumps(OUT, ensure_ascii=False, indent=1, default=str)[:2500])
