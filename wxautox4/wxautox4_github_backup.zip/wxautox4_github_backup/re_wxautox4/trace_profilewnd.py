# -*- coding: utf-8 -*-
"""抓 ProfileWnd.topui 的完整调用栈，并看 ProfileWnd.init 的局部变量名"""
import importlib.util
import os
import sys
import traceback

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

HERE = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location(
    "wx_uia_wake", os.path.join(HERE, "wake_ref", "wechat_uia_wake.py"))
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
from wxautox4.uia import uiautomation as auto  # noqa: E402
mod._uia = lambda: auto

import wxautox4.ui.component as C  # noqa: E402
from wxautox4 import WeChat  # noqa: E402

print("ProfileWnd.init varnames:", getattr(
    getattr(C.ProfileWnd.init, "__code__", None), "co_varnames", None))
print("ProfileWnd._ui_cls_name:", C.ProfileWnd._ui_cls_name)
print("ProfileWnd._win_cls_name:", C.ProfileWnd._win_cls_name)
print("ProfileWnd._win_name:", C.ProfileWnd._win_name)
print()

out = mod.wake()
print("wake:", out.get("ok"), out.get("action"))
try:
    wx = WeChat()
    print("成功", wx)
except BaseException:
    print("--- 完整栈 ---")
    traceback.print_exc()
    tb = sys.exc_info()[2]
    while tb:
        f = tb.tb_frame
        print("[frame] %s:%s in %s" % (f.f_code.co_filename.split("\\")[-1],
                                       tb.tb_lineno, f.f_code.co_name))
        for k, v in list(f.f_locals.items())[:25]:
            if k == "self":
                print("      self = %s" % type(v).__name__)
                continue
            r = repr(v)
            print("      %-16s = %s" % (k, r[:120]))
        tb = tb.tb_next
