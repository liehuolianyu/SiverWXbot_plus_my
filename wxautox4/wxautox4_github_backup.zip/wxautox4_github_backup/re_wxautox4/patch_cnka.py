# -*- coding: utf-8 -*-
import sys, os, traceback
import wxautox4.ui.main as M
cands=[n for n in dir(M) if n in ("_cnka","_seal_wechat_main_init") or "cnka" in n or "seal" in n]
print("candidate attrs:", cands)
for n in cands:
    print("  ", n, type(getattr(M,n)).__name__)
if hasattr(M,"_cnka"):
    try:
        r=M._cnka()
        print("_cnka() ->", type(r).__name__, repr(r)[:300])
    except BaseException as e:
        print("_cnka() RAISED:", type(e).__name__, "|", str(e)[:200])
        print("\n".join(traceback.format_exc().strip().splitlines()[-4:]))
print("=== 现在 patch _cnka 为 True ===")
orig = getattr(M,"_cnka",None)
if orig:
    M._cnka = lambda *a, **k: True
    try:
        from wxautox4.wx import WeChat
        w=WeChat(nickname="__p__")
        print("RESULT: WeChat() constructed OK ->", type(w).__name__)
    except BaseException as e:
        print("RESULT RAISED:", type(e).__name__, "|", str(e)[:200])
        print("\n".join(traceback.format_exc().strip().splitlines()[-4:]))
