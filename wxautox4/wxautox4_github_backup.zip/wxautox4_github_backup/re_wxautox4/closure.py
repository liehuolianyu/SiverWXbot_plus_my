# -*- coding: utf-8 -*-
import wxautox4.ui.main as M
W = M.WeChatMainWnd
init = W.__init__
c = init.__code__
print("func:", init)
print("co_name:", c.co_name, "co_qualname:", getattr(c,"co_qualname",None))
print("co_varnames:", c.co_varnames)
print("co_freevars:", c.co_freevars)
print("co_names:", c.co_names)
print("co_consts:", [repr(x)[:80] for x in c.co_consts])
print("closure len:", None if init.__closure__ is None else len(init.__closure__))
if init.__closure__:
    for nm, cell in zip(c.co_freevars, init.__closure__):
        try: val = cell.cell_contents
        except Exception as e: val = "<%s>" % type(e).__name__
        extra = ""
        if callable(val):
            cc = getattr(val, "__code__", None)
            if cc: extra = " [code: %s @%s]" % (cc.co_name, cc.co_firstlineno)
        print("  cell %-20s %-28s %s%s" % (nm, type(val).__name__, repr(val)[:80], extra))
