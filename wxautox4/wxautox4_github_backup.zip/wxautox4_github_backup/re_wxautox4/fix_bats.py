# -*- coding: utf-8 -*-
"""把三个启动脚本重写为 CRLF 换行 + 纯 ASCII（cmd / PowerShell 5.1 安全）。

背景：工具写文件时用了 LF 换行 + UTF-8 中文注释，cmd.exe 依赖 CR 判定行
边界，LF-only + 多字节字符会把命令切碎（表现为 'ct' / 'rver' 不是内部命令）。
"""
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

START_BAT = r"""@echo off
setlocal
set "PROJECT=C:\Users\Administrator\Documents\ChatGPT\live2D\_wxautox4_probe\SiverWXbot_plus"
set "PYTHON=%PROJECT%\.venv_clean\Scripts\python.exe"
if not exist "%PYTHON%" (
    echo Project environment not found.
    pause
    exit /b 1
)
rem Auto-connect WeChat and start listening right after the service is up.
rem Remove the next line to go back to manual start from the panel.
set "SIVER_AUTOSTART_BOT=1"
start "SiverWXbot_plus" /D "%PROJECT%" "%PYTHON%" "%PROJECT%\web_server.py"
echo SiverWXbot_plus start command sent.
echo Panel: http://127.0.0.1:10001/
timeout /t 3 /nobreak >nul
endlocal
"""

STOP_BAT = r"""@echo off
setlocal
set "PROJECT=C:\Users\Administrator\Documents\ChatGPT\live2D\_wxautox4_probe\SiverWXbot_plus"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PROJECT%\stop_siverwxbot.ps1"
timeout /t 3 /nobreak >nul
endlocal
"""

START_PS1 = r"""$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot

$python = Join-Path $PSScriptRoot '.venv_clean\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $python)) {
    throw "Project virtual environment not found. Create .venv_clean and install requirements.txt first."
}

# Auto-connect WeChat and start listening right after the service is up.
# Remove the next line to go back to manual start from the panel.
$env:SIVER_AUTOSTART_BOT = '1'

& $python web_server.py
"""

TARGETS = {
    r"C:\Users\Administrator\Desktop\SiverWXbot_plus_start.bat": START_BAT,
    r"C:\Users\Administrator\Desktop\SiverWXbot_plus_stop.bat": STOP_BAT,
    (r"C:\Users\Administrator\Documents\ChatGPT\live2D\_wxautox4_probe"
     r"\SiverWXbot_plus\start_siverwxbot.ps1"): START_PS1,
}

for path, text in TARGETS.items():
    body = "\r\n".join(text.strip("\n").split("\n")) + "\r\n"
    data = body.encode("ascii")          # 非 ASCII 直接抛错，确保纯净
    with open(path, "wb") as fh:
        fh.write(data)
    print("wrote %-28s %d bytes" % (path.rsplit("\\", 1)[-1], len(data)))
