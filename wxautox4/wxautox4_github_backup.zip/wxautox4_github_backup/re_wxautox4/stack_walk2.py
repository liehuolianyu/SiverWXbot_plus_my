# -*- coding: utf-8 -*-
import sys, pathlib, io, json
OUT=[]
_oe = pathlib.Path.exists
def fake(self):
    p=str(self)
    if ".wxautox" in p:
        f=sys._getframe(1); depth=0
        while f is not None and depth<10:
            g=f.f_globals; c=f.f_code
            loc=f.f_locals
            entry={"depth":depth,"mod":g.get("__name__"),"qualname":getattr(c,"co_qualname",c.co_name),
                   "line":f.f_lineno,"locals":[k for k in list(loc.keys())[:12]]}
            OUT.append(entry)
            f=f.f_back; depth+=1
    return _oe(self)
pathlib.Path.exists=fake
try:
    from wxautox4.wx import WeChat
    WeChat(nickname="__p__")
except BaseException: pass
for e in OUT:
    print(e["depth"], e["mod"], "::", e["qualname"], "@line", e["line"])
    print("    locals:", e["locals"])
json.dump(OUT, io.open("artifacts/stack_walk2.json","w",encoding="utf-8"), ensure_ascii=False, indent=1)
