# -*- coding: utf-8 -*-
"""set_api_config.py —— 安全地检查 / 填写 wxbot 的 API 接口配置

背景
----
`config/config.json` 里 `api_configs[i].key/url/model` 三个字段任何一个为空，
机器人启动时就会在 `WXBot.__init__ -> _init_api() -> OpenAIAPI()` 处抛
`OpenAIError: Missing credentials`，线程直接退出。

为什么不建议手改 config.json：
  1. 面板 / 机器人在跑时会把内存里的旧配置原子写回，覆盖你的手工修改；
  2. 顶层的旧字段（`api_key` / `base_url` / `model1`）会在 normalize 阶段被
     静默删除（见 config_defaults.normalize），改错位置等于白改。

本脚本复用项目自己的 `ConfigStore`（同一把路径锁 + 原子写 +
`config_defaults.prepare` 规范化），只改 `api_configs[idx]`，与面板行为一致。

用法
----
    # ① 只看当前配置是否完整（只读，不改任何文件）
    python tools/set_api_config.py --check

    # ② 填写第 0 个接口（默认索引 0）
    python tools/set_api_config.py --key sk-xxxx --url https://api.deepseek.com/v1 --model deepseek-chat

    # ③ 填第 1 个接口
    python tools/set_api_config.py --index 1 --key sk-xxxx --url ... --model ...

    # ④ 填完顺便测一次连通性（走项目自身的 OpenAIAPI 路径）
    python tools/set_api_config.py --check --test

注意：改完 `api_configs` 属于「需重建 API 客户端」的改动（见 config_apply.py），
如果机器人当前正在运行，请在面板上停止再启动机器人，或直接重启 web_server。
"""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
CONFIG_PATH = PROJECT_ROOT / "config" / "config.json"

FIELDS = ("sdk", "url", "key", "model")


def _load_module(name):
    """把项目根目录加进 sys.path 后导入（保证能读到 config_store / config_defaults）。"""
    if str(PROJECT_ROOT) not in sys.path:
        sys.path.insert(0, str(PROJECT_ROOT))
    return __import__(name)


def open_store():
    """按 wxbot_core._get_config_store 的方式构造 ConfigStore（行为完全一致）。"""
    config_store = _load_module("config_store")
    config_defaults = _load_module("config_defaults")
    return config_store.ConfigStore(
        str(CONFIG_PATH),
        defaults=config_defaults.DEFAULT_CONFIG,
        normalize=config_defaults.prepare,
    )


def mask(value):
    if not isinstance(value, str) or not value:
        return "(空)"
    if len(value) <= 12:
        return value
    return "%s...%s (len=%d)" % (value[:8], value[-4:], len(value))


def cmd_check(cfg, index):
    configs = cfg.get("api_configs") or []
    print("配置文件 : %s" % CONFIG_PATH)
    print("存在     : %s" % CONFIG_PATH.is_file())
    print("接口总数 : %d" % len(configs))
    print("当前默认 : api_index = %s" % cfg.get("api_index"))
    print()
    ok = True
    for i, item in enumerate(configs):
        if not isinstance(item, dict):
            continue
        mark = "  <== 默认接口" if i == cfg.get("api_index") else ""
        gaps = [f for f in ("sdk", "url", "key", "model") if not str(item.get(f) or "").strip()]
        state = "完整" if not gaps else "缺 " + "/".join(gaps)
        print("[%d] %s%s" % (i, state, mark))
        print("    sdk   : %s" % (item.get("sdk") or "(空)"))
        print("    url   : %s" % mask(item.get("url")))
        print("    key   : %s" % mask(item.get("key")))
        print("    model : %s" % mask(item.get("model")))
        if i == cfg.get("api_index") and gaps:
            ok = False
    print()
    cur = configs[cfg.get("api_index")] if 0 <= cfg.get("api_index", 0) < len(configs) else {}
    if isinstance(cur, dict) and str(cur.get("sdk") or "").strip() and ok:
        print("结论：默认接口配置完整，可以启动机器人。")
        return 0
    print("结论：默认接口配置不完整 —— 机器人启动会在 OpenAIAPI 初始化处抛")
    print("      OpenAIError: Missing credentials。请用本脚本补齐 key / url / model。")
    return 2


def cmd_set(cfg, rev, store, index, sdk, url, key, model):
    configs = cfg.get("api_configs") or []
    if index < 0 or index >= len(configs):
        print("[错误] 接口下标 %d 超出范围（当前共 %d 个）" % (index, len(configs)))
        return 1
    item = dict(configs[index]) if isinstance(configs[index], dict) else {}
    for field, value in (("sdk", sdk), ("url", url), ("key", key), ("model", model)):
        if value is not None:
            value = value.strip()
            if field == "url":
                value = value.rstrip("/")
            item[field] = value
    item.setdefault("fallback_api_index", -1)
    if not str(item.get("sdk") or "").strip():
        item["sdk"] = "OpenAI API 格式兼容接口"

    gaps = [f for f in ("sdk", "url", "key", "model") if not str(item.get(f) or "").strip()]
    print("即将写入 api_configs[%d]：" % index)
    for f in ("sdk", "url", "key", "model"):
        print("    %-6s %s" % (f, mask(item.get(f))))
    if gaps:
        print()
        print("[警告] 仍有字段为空：%s" % "/".join(gaps))
        print("       这些字段为空时机器人依然会在启动阶段抛 Missing credentials。")
        print("       url / model 也是必填（面板的接口测试会提示「Base URL 不能为空」）。")

    new_configs = list(configs)
    new_configs[index] = item
    data, new_rev = store.update({"api_configs": new_configs})
    print()
    print("已写入 : %s" % CONFIG_PATH)
    print("版本号 : %s -> %s" % (rev or "(新建)", new_rev))
    print("生效方式：api_configs 属于「需重建 API 客户端」（config_apply.API_REBUILD_REASONS），")
    print("          机器人正在运行的话，请停止后重新启动机器人，或重启 web_server。")
    return 0


def cmd_test(cfg, index):
    """用项目自身的 OpenAIAPI 路径测一次连通性。"""
    configs = cfg.get("api_configs") or []
    if not (0 <= index < len(configs)):
        print("[错误] 接口下标超出范围")
        return 1
    item = configs[index] if isinstance(configs[index], dict) else {}
    _load_module("config_store")

    class _Tmp:
        pass

    tmp = _Tmp()
    tmp.api_sdk = str(item.get("sdk") or "").strip()
    tmp.api_key = str(item.get("key") or "").strip()
    tmp.base_url = str(item.get("url") or "").strip().rstrip("/")
    tmp.model1 = str(item.get("model") or "").strip()
    tmp.prompt = "你是接口连通性测试助手。请只回复 OK。"

    if not tmp.api_key:
        print("[跳过] key 为空，无法测试")
        return 1
    if not tmp.base_url:
        print("[跳过] url 为空，无法测试")
        return 1
    if not tmp.model1:
        print("[跳过] model 为空，无法测试")
        return 1

    print("正在测试接口（模型 %s）..." % tmp.model1)
    try:
        wxbot_core = _load_module("wxbot_core")
        api = wxbot_core.OpenAIAPI(tmp)
        reply = api.chat("请只回复 OK", stream=False, prompt=tmp.prompt, history=[])
        print("接口返回 : %r" % (str(reply)[:200],))
        return 0
    except Exception as exc:
        print("[失败] %s: %s" % (type(exc).__name__, str(exc)[:300]))
        return 1


def main(argv=None):
    ap = argparse.ArgumentParser(description="检查 / 填写 wxbot API 接口配置")
    ap.add_argument("--check", action="store_true", help="只检查当前配置，不写入")
    ap.add_argument("--index", type=int, default=None, help="接口下标（默认取 api_index）")
    ap.add_argument("--sdk", default=None, help="SDK 名称，默认 OpenAI API 格式兼容接口")
    ap.add_argument("--url", default=None, help="接口地址 Base URL")
    ap.add_argument("--key", default=None, help="API Key")
    ap.add_argument("--model", default=None, help="模型名称")
    ap.add_argument("--test", action="store_true", help="跑一次真实接口连通性测试")
    args = ap.parse_args(argv)

    if not CONFIG_PATH.parent.is_dir():
        print("[错误] 没找到 %s —— 请在项目根目录下运行本脚本。" % CONFIG_PATH)
        return 1

    store = open_store()
    try:
        cfg, rev = store.read()
    except Exception as exc:
        print("[错误] 读取配置失败：%s: %s" % (type(exc).__name__, exc))
        return 1

    index = args.index
    if index is None:
        try:
            index = int(cfg.get("api_index", 0) or 0)
        except (TypeError, ValueError):
            index = 0

    has_writes = any(v is not None for v in (args.sdk, args.url, args.key, args.model))

    if args.check or not has_writes:
        rc = cmd_check(cfg, index)
        if args.test:
            print()
            cmd_test(cfg, index)
        if not has_writes:
            return rc
        print()

    rc = cmd_set(cfg, rev, store, index, args.sdk, args.url, args.key, args.model)
    if rc == 0 and args.test:
        cfg2, _ = store.read()
        print()
        cmd_test(cfg2, index)
    return rc


if __name__ == "__main__":
    raise SystemExit(main())
