# -*- coding: utf-8 -*-
"""wxautox4 × 微信 4.1.15.x 兼容补丁

背景
----
wxautox4 41.2.1 的 `ui.component.ProfileWnd` 是按微信 4.1.13 的资料卡界面写的：
它在 `init()` 里查找 `mmui::ContactProfileMidUi` / `mmui::ContactProfileBottomUi` /
`ContactHeadView` 等元素。实测 `Weixin.dll 4.1.15.13` 里
**`ContactProfileMidUi` / `ContactProfileBottomUi` 已完全不存在**，于是
`init()` 静默失败、`self.topui` 从未被赋值，而 `WeChatMainWnd.__init__` →
`get_my_info()` → `ProfileWnd.info` 会直接读 `self.topui`
→ `AttributeError: 'ProfileWnd' object has no attribute 'topui'`
→ **`WeChat()` 构造直接失败**。

本补丁只做**降级容错**（不改动任何正常路径的行为）：
  * `ProfileWnd.info`  ：读不到资料卡时返回 {}，而不是抛 AttributeError；
  * `WeChatMainWnd.get_my_info` ：整个失败时返回 {}。

代价：在 4.1.15.x 上 `GetMyInfo()` 取不到昵称/微信号（返回 {}）。
如需昵称，请显式赋值：`wx.nickname = "<你的微信昵称>"`。
"""
from __future__ import annotations

__all__ = ["install", "is_installed"]

_FLAG_PROFILE = "_wxautox4_compat_profile_info"
_FLAG_GMI = "_wxautox4_compat_get_my_info"


def install():
    """安装兼容补丁（幂等）。返回各子项结果摘要。"""
    res = {}

    # 1) ProfileWnd.info 容错
    try:
        from wxautox4.ui import component as C
        cls = getattr(C, "ProfileWnd", None)
        prop = getattr(cls, "info", None) if cls is not None else None
        if cls is None:
            res["profile_info"] = "no-ProfileWnd"
        elif getattr(cls, _FLAG_PROFILE, False):
            res["profile_info"] = "already"
        elif not isinstance(prop, property) or prop.fget is None:
            res["profile_info"] = "unexpected-info-type:%r" % type(prop).__name__
        else:
            original = prop.fget

            def _safe_info(self, _orig=original):
                try:
                    return _orig(self)
                except Exception:
                    return {}

            cls.info = property(_safe_info, prop.fset, prop.fdel, prop.__doc__)
            setattr(cls, _FLAG_PROFILE, True)
            res["profile_info"] = True
    except Exception as exc:
        res["profile_info"] = "error:%r" % (exc,)

    # 2) WeChatMainWnd.get_my_info 容错
    try:
        from wxautox4.ui import main as M
        cls = getattr(M, "WeChatMainWnd", None)
        if cls is None:
            res["get_my_info"] = "no-WeChatMainWnd"
        elif getattr(cls, _FLAG_GMI, False):
            res["get_my_info"] = "already"
        else:
            original = cls.get_my_info

            def _safe_get_my_info(self, *a, _orig=original, **k):
                try:
                    return _orig(self, *a, **k) or {}
                except Exception:
                    return {}

            cls.get_my_info = _safe_get_my_info
            setattr(cls, _FLAG_GMI, True)
            res["get_my_info"] = True
    except Exception as exc:
        res["get_my_info"] = "error:%r" % (exc,)

    return res


def is_installed():
    try:
        from wxautox4.ui import component as C
        from wxautox4.ui import main as M
    except Exception:
        return False
    return (getattr(C.ProfileWnd, _FLAG_PROFILE, False)
            and getattr(M.WeChatMainWnd, _FLAG_GMI, False))


if __name__ == "__main__":
    import json
    import sys
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    print(json.dumps(install(), ensure_ascii=False, indent=2))
