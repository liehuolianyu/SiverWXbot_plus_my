# -*- coding: utf-8 -*-
"""SiverWXbot_plus × wxautox4 启动前自愈模块

为什么需要它
------------
微信 4.x 是自绘 UI，wxautox4 想连上必须同时满足两件事：

1. **UIA 无障碍闸门为 1**：否则 `WM_GETOBJECT` 只返回 Qt 空壳窗口，
   控件树里没有 `mmui::MainWindow`，wxautox4 报「未找到已登录的客户端主窗口」。
   该闸门字节会被微信定期复位，所以**每次连接前补一次**（热写 1 字节，
   校验失败自动回滚；不重启微信、不改微信任何文件）。
2. **微信主窗口处于激活状态**：窗口在后台时 Qt 会回收消息列表 / 资料卡的
   无障碍节点，`GetAllMessage()` 返回空、`get_my_info()` 拿到 `None`。

另有一个次要问题：wxautox4 41.2.1 的 `ProfileWnd` 是按微信 4.1.13 界面写的，
在 4.1.15.x 上会抛 `'ProfileWnd' object has no attribute 'topui'` 导致
`WeChat()` 构造失败 —— 由随附的 `wxautox4_compat_414.py` 降级容错兜住。

本模块把上述三件事收敛成一个 `prepare()`，在 `WeChat()` 构造**之前**调用即可，
任何一步失败都只记日志、不抛异常（绝不因为自愈失败而阻断机器人启动）。

对外 API
--------
    prepare(log=None)                      # 补闸门 + 激活窗口 + 装兼容补丁
    start_watchdog(interval=60, log=None)  # 后台守护：闸门掉了自动补
    stop_watchdog()                        # 停止守护线程
    get_cached_nickname() / cache_nickname(name)   # 昵称兜底缓存
    status()                               # 只读自检

命令行
------
    python tools/wxautox4_prep.py           # 执行一次 prepare 并打印结果
    python tools/wxautox4_prep.py status    # 只读自检
"""
from __future__ import annotations

import ctypes
import ctypes.wintypes as wt
import importlib.util
import os
import sys
import threading
import time

__all__ = [
    "prepare",
    "start_watchdog",
    "stop_watchdog",
    "get_cached_nickname",
    "cache_nickname",
    "status",
]

HERE = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(HERE)
GATE_SRC = os.path.join(HERE, "wechat_uia_wake.py")
COMPAT_SRC = os.path.join(HERE, "wxautox4_compat_414.py")
NICK_CACHE = os.path.join(PROJECT_ROOT, "config", ".wxautox4_nickname")

WIN_CLS = "Qt51514QWindowIcon"
WIN_NAME = "微信"

_gate_mod = None
_gate_lock = threading.Lock()
_watch_stop = threading.Event()
_watch_thread = None
_nickname = None


# --------------------------------------------------------------------------- #
# 日志
# --------------------------------------------------------------------------- #
def _default_log(message, level="INFO"):
    print("[wxautox4_prep][%s] %s" % (level, message), flush=True)


def _make_log(log):
    """把任意可调用对象规整成 log(message, level=...)。

    SiverWXbot_plus 的 logger.log 签名是 ``log(level=..., message=...)``；
    这里做一次适配，调用方传什么都不至于让自愈流程崩掉。
    """
    if log is None:
        return _default_log

    def _emit(message, level="INFO"):
        try:
            log(level=level, message=message)
        except TypeError:
            try:
                log(message)
            except Exception:
                _default_log(message, level)
        except Exception:
            _default_log(message, level)

    return _emit


# --------------------------------------------------------------------------- #
# 闸门工具加载（含 wxauto4 -> wxautox4 适配）
# --------------------------------------------------------------------------- #
def _uia():
    """优先用本机 wxautox4 自带的那份 uiautomation。"""
    try:
        from wxautox4.uia import uiautomation as auto  # type: ignore

        return auto
    except Exception:
        pass
    try:
        import uiautomation as auto  # type: ignore

        return auto
    except Exception:
        return None


def load_gate(log=None):
    """加载社区闸门工具并注入本机适配层。失败返回 None。"""
    global _gate_mod
    with _gate_lock:
        if _gate_mod is not None:
            return _gate_mod
        if not os.path.isfile(GATE_SRC):
            if log:
                log("闸门工具缺失：%s" % GATE_SRC, "ERROR")
            return None
        try:
            spec = importlib.util.spec_from_file_location(
                "_siver_wx_uia_wake", GATE_SRC
            )
            if spec is None or spec.loader is None:
                return None
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            mod._uia = _uia          # 关键适配：原工具只认 wxauto4
            _gate_mod = mod
            return mod
        except Exception as exc:
            if log:
                log("闸门工具加载失败：%r" % (exc,), "ERROR")
            return None


# --------------------------------------------------------------------------- #
# 微信主窗口：定位 + 激活
# --------------------------------------------------------------------------- #
def find_main_hwnd():
    """按 Win32 类名 + 标题定位微信主窗口，找不到返回 0。"""
    u = ctypes.windll.user32
    u.GetClassNameW.argtypes = [wt.HWND, wt.LPWSTR, ctypes.c_int]
    u.GetWindowTextW.argtypes = [wt.HWND, wt.LPWSTR, ctypes.c_int]
    CB = ctypes.WINFUNCTYPE(ctypes.c_bool, wt.HWND, wt.LPARAM)
    st = {"h": 0, "best": 0, "best_area": -1}

    def cb(h, l):
        b = ctypes.create_unicode_buffer(128)
        u.GetClassNameW(h, b, 128)
        if b.value != WIN_CLS:
            return True
        t = ctypes.create_unicode_buffer(128)
        u.GetWindowTextW(h, t, 128)
        if t.value != WIN_NAME:
            return True
        if not u.IsWindowVisible(h):
            return True
        st["h"] = h
        rect = wt.RECT()
        if u.GetWindowRect(h, ctypes.byref(rect)):
            area = (rect.right - rect.left) * (rect.bottom - rect.top)
            if area > st["best_area"]:
                st["best_area"] = area
                st["best"] = h
        return True

    u.EnumWindows(CB(cb), 0)
    return st["best"] or st["h"]


def is_foreground(hwnd):
    try:
        return int(ctypes.windll.user32.GetForegroundWindow() or 0) == int(hwnd)
    except Exception:
        return False


def activate(hwnd):
    """尽量把微信窗口拉到前台 —— 这是消息列表节点物化的前提。"""
    if not hwnd:
        return False
    u = ctypes.windll.user32
    try:
        if u.IsIconic(hwnd):
            u.ShowWindow(hwnd, 9)          # SW_RESTORE
        try:
            u.SwitchToThisWindow(hwnd, True)
        except Exception:
            pass
        time.sleep(0.35)
        u.SetForegroundWindow(hwnd)
        # 备用：短暂置顶再撤销，通常能抢到前台
        u.SetWindowPos(hwnd, -1, 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0040)
        time.sleep(0.25)
        u.SetWindowPos(hwnd, -2, 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0040)
        time.sleep(0.8)
    except Exception:
        pass
    return is_foreground(hwnd)


# --------------------------------------------------------------------------- #
# 兼容补丁（微信 4.1.15.x）
# --------------------------------------------------------------------------- #
def install_compat(log=None):
    """安装 wxautox4 × 4.1.15.x 降级容错补丁（幂等）。"""
    try:
        if not os.path.isfile(COMPAT_SRC):
            if log:
                log("兼容补丁缺失：%s" % COMPAT_SRC, "WARNING")
            return None
        spec = importlib.util.spec_from_file_location(
            "_siver_wxautox4_compat", COMPAT_SRC
        )
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod.install()
    except Exception as exc:
        if log:
            log("兼容补丁安装失败：%r" % (exc,), "WARNING")
        return None


# --------------------------------------------------------------------------- #
# 昵称兜底缓存
# --------------------------------------------------------------------------- #
def get_cached_nickname():
    global _nickname
    if _nickname:
        return _nickname
    try:
        with open(NICK_CACHE, "r", encoding="utf-8") as fh:
            _nickname = fh.read().strip() or None
    except Exception:
        _nickname = None
    return _nickname


def cache_nickname(name):
    global _nickname
    if not name:
        return False
    _nickname = str(name)
    try:
        os.makedirs(os.path.dirname(NICK_CACHE), exist_ok=True)
        with open(NICK_CACHE, "w", encoding="utf-8") as fh:
            fh.write(_nickname)
        return True
    except Exception:
        return False


# --------------------------------------------------------------------------- #
# 闸门
# --------------------------------------------------------------------------- #
def ensure_gate(log=None):
    """补一次 UIA 闸门。返回 gate 工具的结构化结果，失败返回 None。

    若闸门已物化（action == 'already'），几乎零开销直接返回。
    """
    mod = load_gate(log)
    if mod is None:
        return None
    try:
        return mod.wake(log=(log or _default_log))
    except TypeError:
        # 原工具 wake 的 log 形参可能要求单参可调用
        try:
            return mod.wake()
        except Exception as exc:
            if log:
                log("闸门热激活异常：%r" % (exc,), "WARNING")
            return None
    except Exception as exc:
        if log:
            log("闸门热激活异常：%r" % (exc,), "WARNING")
        return None


def gate_ok(hwnd=None):
    """只读：当前闸门是否物化（mmui:: 控件树是否已存在）。"""
    mod = load_gate()
    if mod is None:
        return None
    try:
        if hwnd is None:
            wins = mod.wechat_window_handles()
            if not wins:
                return False
            hwnd = int(wins[0]["hwnd"])
        return bool(mod.mmui_present(int(hwnd), timeout=0.6))
    except Exception:
        return None


# --------------------------------------------------------------------------- #
# 主入口
# --------------------------------------------------------------------------- #
def prepare(log=None, activate_window=True, strict=False):
    """启动前自愈：装兼容补丁 -> 补闸门 -> 激活窗口。

    :param log: 日志回调，兼容 ``log(level=..., message=...)`` 或 ``log(msg)``
    :param activate_window: 是否把微信窗口拉到前台（读消息/资料卡需要）
    :param strict: True 时闸门失败会抛异常；默认 False，只记日志
    :return: ``{ok, compat, gate, gate_action, hwnd, activated, detail}``
    """
    log = _make_log(log)
    result = {
        "ok": False,
        "compat": None,
        "gate": None,
        "gate_action": None,
        "hwnd": 0,
        "activated": False,
        "detail": "",
    }

    # 0) 兼容补丁（必须在 import wxautox4.ui 之后、构造 WeChat 之前）
    result["compat"] = install_compat(log)

    # 1) 定位微信主窗口
    hwnd = find_main_hwnd()
    result["hwnd"] = hwnd
    if not hwnd:
        result["detail"] = "未找到微信主窗口（微信是否已启动并登录？）"
        log(result["detail"], "WARNING")
        if strict:
            raise RuntimeError(result["detail"])
        return result

    # 2) 补闸门（带窗口提示，直接作用到这个窗口）
    gate = ensure_gate(log)
    result["gate"] = gate
    if gate:
        result["gate_action"] = gate.get("action")
        if gate.get("ok"):
            log("UIA 闸门就绪（action=%s, rva=%s）"
                % (gate.get("action"), gate.get("rva")))
        else:
            result["detail"] = "闸门未就绪：%s" % gate.get("detail")
            log(result["detail"], "WARNING")
    else:
        result["detail"] = "闸门工具不可用"
        log(result["detail"], "WARNING")

    ok_gate = bool(gate and gate.get("ok"))
    if not ok_gate and strict:
        raise RuntimeError(result["detail"] or "闸门未就绪")

    # 3) 激活窗口（让 Qt 重建消息列表 / 资料卡节点）
    # 说明：SetForegroundWindow 常被 Windows 前台锁定策略拒绝（本进程非前台进程），
    # 但 wxautox4 构造时自己会 Show() 主窗口，所以这里失败只是「未确认」而非故障，
    # 故降为 DEBUG，避免每次启动都刷 WARNING 误导。
    if activate_window:
        result["activated"] = activate(hwnd)
        log("微信主窗口 hwnd=0x%08X 激活请求已发出（前台确认=%s）"
            % (hwnd, result["activated"]), "DEBUG")

    result["ok"] = ok_gate
    return result


# --------------------------------------------------------------------------- #
# 后台守护：闸门被微信复位时自动补
# --------------------------------------------------------------------------- #
def start_watchdog(interval=60, log=None, activate_window=False):
    """启动后台守护线程：定期确认闸门仍物化，掉了就补。

    闸门字节在**没有 UIA 客户端查询**时会被微信复位；只要仍有客户端在查询，
    实测可长期保持。守护线程既做检测本身也是一种持续查询。

    :return: True 表示本次新建了线程；False 表示已在运行或缺前置条件
    """
    global _watch_thread
    with _gate_lock:
        if _watch_thread is not None and _watch_thread.is_alive():
            return False

    if load_gate(_make_log(log)) is None:
        return False

    log = _make_log(log)
    _watch_stop.clear()

    def _loop():
        while not _watch_stop.wait(interval):
            try:
                hwnd = find_main_hwnd()
                if not hwnd:
                    continue
                if gate_ok(hwnd):
                    continue
                log("检测到闸门已复位，正在补写 ...", "WARNING")
                out = ensure_gate(log)
                if out and out.get("ok"):
                    if activate_window:
                        activate(hwnd)
                    log("闸门已补回（action=%s）" % out.get("action"))
                else:
                    log("闸门补写未成功：%s"
                        % ((out or {}).get("detail", "未知")), "ERROR")
            except Exception as exc:
                log("守护线程异常（已忽略，继续守护）：%r" % (exc,), "WARNING")

    t = threading.Thread(target=_loop, name="wxautox4-gate-watchdog", daemon=True)
    t.start()
    with _gate_lock:
        _watch_thread = t
    log("闸门守护线程已启动（间隔 %ss）" % interval)
    return True


def stop_watchdog():
    """停止守护线程（幂等）。"""
    global _watch_thread
    _watch_stop.set()
    t = _watch_thread
    if t is not None and t.is_alive():
        t.join(timeout=5)
    with _gate_lock:
        _watch_thread = None


def is_watchdog_running():
    t = _watch_thread
    return bool(t is not None and t.is_alive())


# --------------------------------------------------------------------------- #
# 自检
# --------------------------------------------------------------------------- #
def status():
    """只读自检，返回结构化结果。"""
    hwnd = find_main_hwnd()
    return {
        "gate_module": os.path.isfile(GATE_SRC),
        "compat_module": os.path.isfile(COMPAT_SRC),
        "hwnd": hwnd,
        "hwnd_hex": ("0x%08X" % hwnd) if hwnd else None,
        "foreground": is_foreground(hwnd) if hwnd else False,
        "gate_present": gate_ok(hwnd) if hwnd else False,
        "watchdog": is_watchdog_running(),
        "cached_nickname": get_cached_nickname(),
    }


def main(argv=None):
    argv = list(argv if argv is not None else sys.argv[1:])
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

    if argv and argv[0] == "status":
        import json
        print(json.dumps(status(), ensure_ascii=False, indent=2))
        return 0

    print("=" * 60)
    print("SiverWXbot_plus × wxautox4 启动前自愈")
    print("=" * 60)
    out = prepare()
    for k, v in out.items():
        print("  %-13s = %r" % (k, v))
    print("-" * 60)
    print("结论：%s" % ("就绪 ✔" if out["ok"] else "未就绪 ✘"))
    return 0 if out["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
