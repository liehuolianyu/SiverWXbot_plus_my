$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot

$python = Join-Path $PSScriptRoot '.venv_clean\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $python)) {
    throw "Project virtual environment not found. Create .venv_clean and install requirements.txt first."
}

# Auto-connect WeChat and start listening right after the service is up.
# Remove the next line to go back to manual start from the panel.
$env:SIVER_AUTOSTART_BOT = '1'

& $python web_server.py
