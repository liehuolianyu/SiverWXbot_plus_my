$ErrorActionPreference = 'Stop'
$project = [IO.Path]::GetFullPath($PSScriptRoot)
$processes = @(Get-CimInstance Win32_Process -Filter "Name = 'python.exe'" | Where-Object {
    $_.CommandLine -and $_.CommandLine.Contains($project) -and $_.CommandLine -match 'web_server\.py'
})

if ($processes.Count -eq 0) {
    Write-Host 'SiverWXbot_plus is not running.'
    exit 0
}

$ids = @($processes | Select-Object -ExpandProperty ProcessId)
$ids | ForEach-Object { Stop-Process -Id $_ -Force }
Write-Host ('Stopped SiverWXbot_plus process(es): ' + ($ids -join ', '))
